#' Solve a Guarded Tie-Aware Weighted Problem
#'
#' @param problem A sealed `postrank_tie_problem`.
#' @param backend NULL, `"highs"` or `"gurobi"`. Resolution follows the existing
#'   explicit argument, option, then Gurobi rule; no backend fallback occurs.
#' @param control Named time, thread, seed, gap and tolerance controls, or a
#'   `postrank_control` declaring `strategy = "label_mip"`. Nonempty staged
#'   engine controls are unsupported in this mode.
#' @param strategy `"label_mip"` only. When omitted, an explicit strategy in
#'   control is respected and checked; otherwise label-MIP is used.
#' @return A distinct `postrank_tie_fit` list. A grade is released only after
#'   independent rounded-primal, full-profile guard and direct-loss validation.
#'   Bounds use `R0 + raw_bound / M`. Solver status, absolute risk gap,
#'   scale/offset and numerical limitations are retained.
#' @details This first mode supports weighted at-most-G with declared or
#'   exact-law full active-profile equality. It does not run the legacy staged
#'   engine, minimax refinement, q protection, exact-G, baselines, reports or
#'   Monte Carlo guarantees. Different optima can yield different grade counts
#'   and funding mappings. One validated incumbent is not a uniqueness claim.
#'   Scientific declarations are not verified by an optimizer, and solver
#'   reported optimality remains subject to floating-point tolerances.
#' @seealso [postrank_tie_problem()], [postrank_tie_evaluate()],
#'   [validate_postrank_tie_solution()], [postrank_tie_capabilities()]
#' @concept tie-aware
#' @export
postrank_tie_solve <- function(problem, backend = NULL, control = list(), strategy = "label_mip") {
  .pr_validate_tie_problem(problem)
  if (missing(strategy) && !is.null(control$strategy)) strategy <- control$strategy
  # The shared control normalizer fills in staged defaults even for label-MIP.
  # Reject user-requested staged options before that normalization, while
  # accepting the default record carried by a typed postrank_control object.
  engine <- control$engine
  unused_engine <- is.null(engine) || !length(engine) ||
    (inherits(control, "postrank_control") && identical(engine, .pr_engine_options(list())))
  cc <- .pr_core_control(control, strategy)
  .pr_assert(identical(cc$strategy, "label_mip") && unused_engine,
    "tie-aware mode supports label_mip only; staged engine controls are unsupported",
    "unsupported_tie_strategy")
  resolved <- .pr_resolve_backend(backend)
  raw <- .pr_with_backend(resolved, switch(resolved$name,
    highs = .pr_tie_backend_highs(problem, cc$core),
    gurobi = .pr_tie_backend_gurobi(problem, cc$core)))
  raw$engine <- list(strategy = "label_mip", loss = "tie_aware_v1",
    guard = "full_active_profile", staged_supported = FALSE)
  fit <- .pr_tie_normalize_solver_result(problem, raw, cc$core)
  fit$capabilities <- postrank_tie_capabilities()
  fit$control <- cc$core
  .pr_fit_annotate(fit, resolved)
}

#' Inspect the Initial Tie-Aware Capability Boundary
#'
#' @return A fixed capability record for the opt-in `postrank_tie_*` domain.
#'   Unsupported features fail closed through distinct classes and dedicated
#'   entry points. This record is not scientific or numerical certification.
#' @details Legacy 0.9 constructors, schemas, hashes, cached data, diagnostics
#'   and default analysis behavior retain their original meanings. The new
#'   mode never silently upgrades a legacy artifact or treats finite sampled
#'   equality as proof of almost-sure profile identity.
#' @concept tie-aware
#' @export
postrank_tie_capabilities <- function() {
  list(loss = "tie_aware_v1", input_domain = "tie-aware-input-0.1",
    joint_draws = TRUE, exact_finite_laws = TRUE,
    weighted_at_most_G = TRUE, full_active_profile_guard = TRUE,
    label_mip = TRUE, backends = c("gurobi", "highs"),
    staged = FALSE, criterionwise_inputs = FALSE, typed_coefficients = FALSE,
    q = FALSE, minimax = FALSE, exact_G = FALSE,
    legacy_baselines_reports_plots = FALSE, mc_diagnostics = FALSE,
    uniform_iid_bounds = FALSE, regret = FALSE, protection_envelopes = FALSE,
    numerical_certification = FALSE,
    equality_evidence = c("structural_declaration_checked_against_retained_draws",
      "all_positive_mass_exact_states"))
}
