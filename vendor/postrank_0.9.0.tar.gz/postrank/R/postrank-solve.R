#' Solve a Common-Grade Problem with a Selected Backend
#'
#' @param problem A postrank_problem.
#' @param backend `NULL` (default) or `"gurobi"`/`"highs"`. `NULL` resolves to
#'   `getOption("postrank.backend")` when set, otherwise to Gurobi. The resolved
#'   name and how it was chosen (`"explicit"`, `"option"` or `"default"`) are
#'   recorded in `fit$backend$name` and `fit$backend$resolution`. An unavailable
#'   backend is an error naming both remedies; a failed or timed-out solve is
#'   never retried with another backend.
#'   The backend is never switched or substituted automatically.
#' @param control Named time/thread/seed/gap/tolerance controls. The element
#'   \code{engine} holds staged-engine options (see Details).
#' @param strategy `NULL` (default: `control$strategy`, else `"staged"`),
#'   `"staged"` or `"label_mip"`. An explicit value wins over `control$strategy`.
#' @return A postrank_fit; only independently validated incumbents have grades.
#'   \code{fit$engine} records the strategy and, for the staged engine, what
#'   each stage did.
#' @details
#' \code{strategy = "label_mip"} passes the integer-label model built by
#' \code{\link{postrank_problem}} to the selected backend unchanged (the 0.0.1
#' behavior).
#'
#' \code{strategy = "staged"} solves the same problem in three stages, using
#' \code{control$time_limit} seconds as the budget of the engine stages
#' (problem checks, the final independent validation and hashing add time):
#' \enumerate{
#'   \item Incumbents: dynamic programming over contiguous partitions of several
#'     priority orders (weighted and criterion-wise orders; Lagrangian
#'     reweighting for protection rows; convex combinations of the criterion
#'     terms for minimax), followed by single-entity local search that keeps the
#'     grade-count and protection rows feasible.
#'   \item Lower bound: a linear relaxation over the pair variables with
#'     asymmetry rows and lazily added triangle inequalities of strict weak
#'     orders, solved by the selected backend. Instead of the grade-count rows
#'     it uses the range of the number of disclosed pairs that the grade count
#'     implies (added when an LP solution violates it), so its optimum is a
#'     lower bound for every grade-count mode (bound source
#'     \code{engine_lp_relaxation_bound}).
#'   \item Only if the gap is not closed and the problem is small enough
#'     (\code{engine$mip}, \code{engine$mip_max_n}): the label MIP strengthened
#'     with the asymmetry rows and the separated triangle rows (valid
#'     inequalities on the same columns). Gurobi receives the incumbent as a MIP
#'     start.
#' }
#' Either way, the released grade is the independently validated incumbent, its
#' risk is the upper bound, and the reported lower bound is a solver-reported
#' bound, not a numerical certificate. For large problems whose relaxation does
#' not close within the time limit the status is \code{feasible_not_certified}
#' (or \code{time_limit}) and \code{fit$objective$risk_absolute_gap} reports
#' the remaining gap in risk units.
#'
#' For a minimax problem built with \code{minimax_refine = "weighted"} (the
#' default of \code{\link{postrank_problem}}), a second stage minimizes the
#' ORIGINAL weighted risk among actions whose selected criterion risks do not
#' exceed the stage-1 minimax value. If weights include zero, a third stage
#' minimizes uniform criterion risk under both the primary caps and a separate
#' cap on that original weighted optimum. No weight perturbation is used.
#' Centered coefficients and positive objective/cap scaling preserve small
#' nonzero weights; the public objectives and bounds retain their original
#' risk units.
#'
#' Stage 1 gets three quarters of \code{control$time_limit}. Refinement shares
#' the remaining budget (at least one second in total after stage 1). With zero
#' weights, stage 2 initially gets half that remainder and stage 3 gets what is
#' left. A seeded heuristic fallback shares its stage's deadline and never
#' grants an extra budget. Validation, construction and hashing add overhead.
#' The final primary status and lower bound come from stage 1, checked against
#' the released action's risk. Candidate actions that breach the primary caps
#' or worsen the original weighted objective beyond machine rounding are kept
#' out. Skipped or uncertified refinement is reported as a warning, except when
#' stage 1 has no validated action.
#'
#' \code{fit$minimax_refine} records the stages, budgets, scaled optimization
#' gaps and actual released relation. \code{lexicographic_certified} requires
#' primary and original weighted certification for that action;
#' \code{pareto_certified} additionally requires the zero-weight third stage
#' when applicable. Each conclusion is subject to recorded gap controls and
#' numerical tolerances, not an exact numerical certificate.
#' \code{fit$backend$options} continues to hold stage 1's options.
#'
#' Engine options in \code{control$engine} (defaults in parentheses):
#' \code{local_search_passes} (20), \code{local_search_starts} (5),
#' \code{max_cut_rounds} (60), \code{cuts_per_round} (NULL, meaning
#' \code{max(200, 10 n)}), \code{lp_time_share} (0.5, the share of the remaining
#' time given to the relaxation when the MIP stage may follow), \code{mip}
#' (\code{"auto"}, \code{"always"} or \code{"never"}) and \code{mip_max_n} (200,
#' the largest n for which \code{"auto"} runs the MIP stage).
#'
#' When the MIP stage cannot run (\code{mip = "never"}, or \code{"auto"} with n
#' above \code{mip_max_n}), no later stage needs the time, so the relaxation gets
#' the remaining time less a reserve for the incumbent candidates built from the
#' order of its solution and for the final validation (never less than
#' \code{lp_time_share} of it). The reserve is the largest of 1 second, 1% of
#' \code{time_limit} and twice the time the incumbent stage took.
#' \code{fit$engine$stages$lp} records the budget in seconds
#' (\code{time_budget}) and the rule that set it (\code{time_budget_rule}:
#' \code{"lp_time_share"} or \code{"remaining_less_reserve"}).
#' @examples
#' draws <- read_postrank_draws(system.file("examples", "synthetic-iid.json",
#'   package = "postrank", mustWork = TRUE))
#' pairwise <- postrank_pairwise(draws)
#' weights <- c(need_A = .6, need_B = .4)
#' problem <- postrank_problem(pairwise, weights, tau = .25, G_max = 3L)
#' if (requireNamespace("highs", quietly = TRUE)) {
#'   fit <- postrank_solve(problem, backend = "highs",
#'     control = list(time_limit = 10, threads = 1L, seed = 1304L))
#'   print(fit$status$normalized)
#'   print(fit$grade)
#'   print(fit$objective$risk_absolute_gap)
#' }
#' @concept decision
#' @export
postrank_solve <- function(problem, backend = NULL, control = list(), strategy = NULL) {
  resolved <- .pr_resolve_backend(backend)
  cc <- .pr_core_control(control, strategy)
  fit <- .pr_with_backend(resolved, .pr_solve_core(problem, resolved$name, cc$core, cc$strategy))
  .pr_fit_annotate(fit, resolved)
}

# Unchanged 0.0.1.9002 body, moved behind the public adapter (freeze manifest: moved_from postrank_solve).
.pr_solve_core <- function(problem, backend = c("gurobi", "highs"), control = list(),
                           strategy = c("staged", "label_mip")) {
  .pr_validate_problem(problem); backend <- match.arg(backend); strategy <- match.arg(strategy)
  control <- .pr_control(control); started <- proc.time()[["elapsed"]]
  refine <- identical(problem$settings$objective, "minimax") && identical(problem$settings$minimax_refine, "weighted")
  # With the minimax second stage, stage 1 gets three quarters of the budget.
  control1 <- control; if (refine) control1$time_limit <- .pr_minimax_stage1_share * control$time_limit
  fit <- .pr_normalize_solver_result(problem, .pr_solve_raw(problem, backend, control1, strategy), control1)
  if (identical(problem$settings$objective, "minimax")) {
    if (refine)
      fit <- .pr_minimax_refine(problem, fit, backend, control, strategy, started)
    else fit$minimax_refine <- list(mode = if (is.null(problem$settings$minimax_refine)) "none_legacy_problem" else "none", applied = FALSE)
  }
  fit
}

# One raw solve of one problem. seed_grades are feasible-candidate grades: the
# staged engine evaluates them with its own candidates; for the label MIP the
# first one becomes a Gurobi MIP start (HiGHS takes no start).
.pr_solve_raw <- function(problem, backend, control, strategy, seed_grades = list()) {
  if (identical(strategy, "staged")) return(.pr_engine_staged(problem, backend, control, seed_grades = seed_grades))
  out <- switch(backend,
    gurobi = .pr_backend_gurobi(problem, control, start = if (length(seed_grades)) .pr_engine_primal(problem, seed_grades[[1L]]) else NULL),
    highs = .pr_backend_highs(problem, control))
  out$engine <- list(strategy = "label_mip")
  out
}
