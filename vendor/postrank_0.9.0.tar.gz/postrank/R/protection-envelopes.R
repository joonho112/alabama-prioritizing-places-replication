.pr_make_protection_envelope <- function(problem,bounds,mode) {
  public_q <- problem$settings$q
  epsilon <- bounds$epsilon[names(public_q)]
  thresholds <- if(mode=="inner")public_q-epsilon else public_q+epsilon
  encoding <- problem$settings
  if(!is.null(encoding$exact_G))encoding$G_max <- encoding$exact_G
  base <- .pr_weighted_model(problem$pairwise,encoding)
  base <- .pr_add_exact_grades(base,problem$pairwise,problem$settings)
  # These are signed internal thresholds, not new values of the public q API.
  protected <- problem$settings;protected$q <- thresholds
  base <- .pr_add_protection(base,problem$pairwise,protected)
  out <- problem;out$problem_identity <- NULL
  out$model <- base$model;out$index <- base$index;out$pair_map <- base$pair_map
  out$protection_envelope <- list(mode=mode,public_q=public_q,epsilon=epsilon,
    thresholds=thresholds,coefficient_bound_identity=bounds$bound_identity)
  out$problem_identity <- .pr_identity(out)
  .pr_validate_problem(out)
  out
}

.pr_validate_protection_envelopes <- function(envelopes) {
  .pr_assert(inherits(envelopes,"postrank_protection_envelopes")&&identical(envelopes$schema_version,"0.1.0"),
    "expected current postrank_protection_envelopes","invalid_protection_envelopes")
  content <- envelopes;content$envelope_identity <- NULL
  .pr_assert(identical(.pr_identity(content),envelopes$envelope_identity),
    "protection envelopes changed after construction","stale_protection_envelopes")
  .pr_validate_iid_bounds(envelopes$bounds)
  for(name in c("public_problem","inner_problem","outer_problem")) .pr_validate_problem(envelopes[[name]])
  .pr_assert(identical(envelopes$inner_problem$protection_envelope$mode,"inner")&&
    identical(envelopes$outer_problem$protection_envelope$mode,"outer")&&
    identical(envelopes$input_identity,envelopes$public_problem$input_identity)&&
    identical(envelopes$bounds$input_identity,envelopes$input_identity)&&
    identical(envelopes$inner_problem$input_identity,envelopes$input_identity)&&
    identical(envelopes$outer_problem$input_identity,envelopes$input_identity),
    "envelope modes or input identities disagree","invalid_protection_envelopes")
  invisible(TRUE)
}

#' Construct Unclipped Inner and Outer Protection Problems
#' @param problem A public weighted postrank_problem with nonempty q budgets.
#' @param bounds Matching postrank_iid_bounds reference calculation.
#' @return Original public problem and two internal linear problems using signed
#'   q minus/plus epsilon thresholds. No numerical safety certificate is issued.
#' @concept reference
#' @export
postrank_protection_envelopes <- function(problem,bounds) {
  .pr_validate_problem(problem);.pr_validate_iid_bounds(bounds)
  .pr_assert(identical(problem$settings$objective,"weighted"),
    "protection envelopes currently support weighted risk only","unsupported_envelope_objective")
  .pr_assert(is.null(problem$protection_envelope),
    "construct envelopes from the original public problem, not an existing envelope","nested_protection_envelope")
  .pr_assert(!is.null(problem$settings$q)&&length(problem$settings$q)>0L,
    "protection envelopes require public q budgets","missing_protection")
  .pr_assert(identical(problem$input_identity,bounds$input_identity),
    "coefficient bounds and problem have different input identity","bound_input_mismatch")
  .pr_assert(identical(names(bounds$epsilon),problem$pairwise$criterion_ids),
    "coefficient bounds must retain every declared criterion in order","bound_criterion_mismatch")
  inner <- .pr_make_protection_envelope(problem,bounds,"inner")
  outer <- .pr_make_protection_envelope(problem,bounds,"outer")
  out <- c(list(schema_version="0.1.0",input_identity=problem$input_identity,
    public_problem_identity=problem$problem_identity,coefficient_bound_identity=bounds$bound_identity,
    public_problem=problem,public_q=problem$settings$q,bounds=bounds,
    inner_problem=inner,outer_problem=outer,
    thresholds=list(inner=inner$protection_envelope$thresholds,outer=outer$protection_envelope$thresholds),
    status="diagnostic_only",interpretation=paste(
      "Inner and outer are empirical linear problems under signed, unclipped q minus/plus epsilon thresholds.",
      "The set inclusions and E5 require the simultaneous coefficient event and valid numerical feasibility/bounds; no certificate is issued.")),
    .pr_guarantee_status("diagnostic_only",reason="Envelope construction does not verify statistical assumptions or numerical enclosure."))
  class(out) <- c("postrank_protection_envelopes","list")
  out$envelope_identity <- .pr_identity(out)
  .pr_validate_protection_envelopes(out)
  out
}

.pr_protection_attempt <- function(problem,backend,control,solver) {
  started <- proc.time()[["elapsed"]]
  fit <- NULL;error <- NULL;warnings <- character()
  tryCatch(withCallingHandlers({fit <- solver(problem,backend=backend,control=control)},warning=function(w) {
    warnings <<- c(warnings,conditionMessage(w));invokeRestart("muffleWarning")
  }),error=function(e) {
    error <<- list(message=conditionMessage(e),class=class(e),
      code=if(is.null(e$code))NULL else e$code,details=if(is.null(e$details))NULL else e$details)
  })
  list(problem_identity=problem$problem_identity,mode=problem$protection_envelope$mode,
    requested_backend=backend,requested_control=control,
    actual_backend=if(is.null(fit))NULL else fit$backend,
    actual_seed=if(is.null(fit))NA_real_ else if(!is.null(fit$backend$options$Seed))fit$backend$options$Seed else
      if(!is.null(fit$backend$options$random_seed))fit$backend$options$random_seed else NA_real_,
    status=if(is.null(fit))NULL else fit$status,error=error,
    warnings=unique(c(warnings,if(is.null(fit))character() else fit$warnings)),
    incumbent_validated=if(is.null(fit))FALSE else isTRUE(fit$incumbent_validated),
    elapsed_wall_seconds=proc.time()[["elapsed"]]-started,fit=fit)
}

.pr_envelope_fit_matches <- function(fit,problem) {
  .pr_assert(inherits(fit,"postrank_fit"),"envelope solver did not return a postrank_fit","invalid_envelope_fit")
  .pr_validate_problem(fit$problem)
  .pr_assert(identical(fit$problem_identity,problem$problem_identity)&&
    identical(fit$problem$problem_identity,problem$problem_identity)&&
    identical(fit$settings,problem$settings)&&identical(fit$input_identity,problem$input_identity),
    "envelope fit does not match the attempted whole problem","envelope_fit_mismatch")
  invisible(TRUE)
}

.pr_run_protection_analysis <- function(envelopes,backend,control,solver=postrank_solve) {
  .pr_validate_protection_envelopes(envelopes)
  .pr_assert(is.character(backend)&&is.null(dim(backend))&&length(backend)==1L&&
    !is.na(backend)&&backend%in%c("gurobi","highs"),
    "an explicit gurobi or highs backend is required","invalid_backend")
  control <- .pr_control(control)
  # Both attempts are retained, even when the first errors or is infeasible.
  attempts <- list(inner=.pr_protection_attempt(envelopes$inner_problem,backend,control,solver),
                  outer=.pr_protection_attempt(envelopes$outer_problem,backend,control,solver))
  inner <- attempts$inner$fit;outer <- attempts$outer$fit
  reasons <- character();upper <- lower <- gap <- value <- NA_real_
  if(is.null(inner))reasons <- c(reasons,"inner_solve_error") else {
    .pr_envelope_fit_matches(inner,envelopes$inner_problem)
    candidate <- isTRUE(inner$incumbent_validated)&&isTRUE(inner$solution_validation$valid)&&
      !is.null(inner$grade)&&identical(inner$grade,inner$solution_validation$grade)&&
      !length(inner$numerical_issues)&&!identical(inner$status$normalized,"numerical_error")
    if(!candidate)reasons <- c(reasons,if(identical(inner$status$normalized,"infeasible"))"inner_infeasible" else
      if(length(inner$numerical_issues)||identical(inner$status$normalized,"numerical_error"))"inner_numerical_issue" else "inner_no_validated_candidate")
    else {
      upper <- .pr_solver_number(inner$objective$risk_upper_bound)
      if(!is.finite(upper))reasons <- c(reasons,"inner_risk_upper_unavailable")
    }
  }
  if(is.null(outer))reasons <- c(reasons,"outer_solve_error") else {
    .pr_envelope_fit_matches(outer,envelopes$outer_problem)
    bound <- .pr_solver_number(outer$objective$risk_lower_bound)
    usable <- is.finite(bound)&&isTRUE(outer$objective$bound_source%in%.pr_usable_bound_sources())&&
      !length(outer$numerical_issues)&&outer$status$normalized%in%c("optimal","feasible_not_certified","time_limit")
    if(usable)lower <- bound else reasons <- c(reasons,
      if(!is.finite(bound))"outer_whole_problem_lower_unavailable" else "outer_whole_problem_lower_not_usable")
  }
  weights <- envelopes$public_problem$settings$weights
  delta <- sum(weights*envelopes$bounds$epsilon[names(weights)])
  if(is.finite(upper)&&is.finite(lower)) {
    gap <- upper-lower
    if(gap<0)reasons <- c(reasons,"outer_lower_above_inner_upper")
    else value <- gap+2*delta
  }
  computed <- is.finite(value)&&!length(reasons)
  if(!computed)value <- NA_real_
  status <- if(computed)"diagnostic_only" else "not_established"
  # Fits are exposed once; attempt receipts retain outcome and option metadata.
  attempts$inner$fit <- NULL;attempts$outer$fit <- NULL
  out <- c(list(schema_version="0.1.0",envelope_identity=envelopes$envelope_identity,
    input_identity=envelopes$input_identity,public_problem_identity=envelopes$public_problem_identity,
    coefficient_bound_identity=envelopes$coefficient_bound_identity,
    backend=backend,control=control,solve_count=2L,attempts=attempts,
    inner_fit=inner,outer_fit=outer,public_q=envelopes$public_q,thresholds=envelopes$thresholds,
    inner_risk_upper=upper,outer_whole_problem_risk_lower=lower,empirical_inner_upper_minus_outer_lower=gap,
    delta_w=delta,computed_value=value,formula="inner_risk_upper - outer_whole_problem_risk_lower + 2 * sum(weights * epsilon)",
    status=status,reasons=unique(reasons),
    interpretation=paste("E5 is a conditional theoretical reference for weighted true-q constrained regret.",
      "A reported outer whole-problem lower bound is used; the inner lower bound is never substituted.",
      "No verified coefficient/arithmetic enclosure or solver-bound certification is implemented.")),
    .pr_guarantee_status(status,bound_computed=computed,
      reason=if(computed)"Conditional E5 reference only; numerical safety certification is disabled." else paste(unique(reasons),collapse="; "),
      assumptions=list(simultaneous_coefficient_event="required_not_verified",inner_true_feasibility="requires_coefficient_event_and_numerical_verification",
        whole_outer_lower_bound="backend_reported_not_rigorously_certified")))
  class(out) <- c("postrank_protection_analysis","list")
  out$analysis_identity <- .pr_identity(out)
  out
}

#' Solve Protection Envelopes for a Diagnostic E5 Reference
#' @param envelopes A postrank_protection_envelopes object.
#' @param backend \code{NULL} (option, then Gurobi) or an explicit \code{"gurobi"}/\code{"highs"};
#'   no fallback is attempted.
#' @param control Named controls passed to each of two sequential solves.
#' @return Both fits and attempt receipts, with a conditional E5 reference only
#'   when a validated inner candidate and usable whole-outer lower bound exist.
#' @concept reference
#' @export
postrank_protection_analysis <- function(envelopes, backend = NULL, control = list()) {
  # 0.9.0 adapter: NULL resolves by option then Gurobi (previously an explicit
  # backend was required); the converter's strategy is forwarded to both solves.
  resolved <- .pr_resolve_backend(backend)
  cc <- .pr_core_control(control, NULL)
  core_strategy <- cc$strategy
  # Phase 2 review H1: the frozen runner files solver errors as attempt records, so an
  # unavailable resolved backend is checked first and raised (no quiet result, no fallback).
  .pr_with_backend(resolved, .pr_backend_require(resolved$name))
  .pr_with_backend(resolved, .pr_run_protection_analysis(envelopes, resolved$name, cc$core,
    solver = function(problem, backend, control) postrank_solve(problem, backend, control, core_strategy)))
}
