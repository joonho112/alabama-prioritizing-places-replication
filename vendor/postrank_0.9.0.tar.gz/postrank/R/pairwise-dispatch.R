#' Compute Posterior Directional-Error Probabilities
#'
#' For i different from j, `e[i,j,k]` is `P(theta[i,k] <= theta[j,k])`.
#' Diagonals are NA sentinels. Criterionwise inputs retain their own draw
#' counts and no cross-criterion joint trace is constructed. Exact finite laws
#' retain rational coefficients alongside a diagnostic double projection.
#' Already projected typed conditional-law artifacts are validated and returned
#' with their original class, source and identity; draw aggregation controls
#' must be omitted. No target sample size or exact-law field is added.
#'
#' @param draws Validated postrank_draws/canonical payload, or an already projected typed coefficient artifact. For typed input omit method and block_size.
#' @param method Equal-weight aggregation algorithm: blocks or reference.
#' @param block_size Positive integer maximum ordered-pair block size.
#' @return A postrank_pairwise object with e, criterion sample sizes,
#'   provenance and, for finite laws, exact rational coefficient metadata.
#' @concept coefficients
#' @export
postrank_pairwise <- function(draws, method = c("blocks", "reference"), block_size = 128L) {
  if(inherits(draws,"postrank_coefficients")) {
    .pr_assert(missing(method)&&missing(block_size),"typed coefficients are already projected; draw aggregation controls are unsupported","unsupported_coefficient_aggregation")
    validate_postrank_coefficients(draws);return(draws)
  }
  method <- match.arg(method)
  .pr_assert(typeof(block_size) %in% c("integer", "double") && length(block_size) == 1L &&
               is.null(dim(block_size)), "block_size must be a positive scalar integer", "invalid_block_size")
  .pr_safe_integer(block_size, TRUE, "$.block_size")
  draws <- as_postrank_draws(draws)
  if (draws$input_kind == "exact_finite_posterior") return(.pr_pairwise_exact(draws))
  matrices <- .pr_draw_matrices(draws)
  e <- .pr_empty_e(draws$entity_ids, draws$criterion_ids)
  for (k in seq_along(draws$criterion_ids)) {
    values <- matrices[[draws$criterion_ids[k]]]
    e[, , k] <- if (method == "reference") .pr_pairwise_reference_one(values) else
      .pr_pairwise_blocks_one(values, block_size)
  }
  .pr_new_pairwise(draws, e, vapply(matrices, nrow, integer(1L)), method)
}
