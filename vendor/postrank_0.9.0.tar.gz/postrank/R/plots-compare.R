# Required figure fig-method-comparison and the autoplot()/plot() dispatch (Chapter 12).

#' Plot the Method Comparison Summary or Relations
#'
#' `view = "summary"`: for each method its risk, disclosure rate and number of
#' grades, the joint rule filled and the baselines hollow; a stored solver
#' lower bound is drawn as a tick. Baselines have no full-family bound. Rows
#' without an action keep their method, status and reason in the subtitle and
#' get no point. `view = "relations"`: for each compared method a stacked bar of
#' the pair-relation changes against the joint rule. Supplied actions outside
#' the declared grade/budget constraints retain their points and relations but
#' are explicitly marked `outside family`; their risks are not a comparison
#' of minima over the same feasible action family. Older objects without the
#' feasibility columns are labeled as not recorded; this view does not
#' reconstruct the missing checks. Recreate the comparison to obtain them.
#'
#' @param x A `postrank_comparison`.
#' @param view `"summary"` or `"relations"`.
#' @param ... Unused.
#' @return A `ggplot` object.
#' @seealso [postrank_compare()], [postrank_plot_relations()]
#' @concept visualization
#' @examples
#' if (requireNamespace("highs", quietly = TRUE)) {
#'   fit <- postrank(postrank_toy, weights = c(need_A = .6, need_B = .4), tau = .25,
#'     G_max = 3L, backend = "highs", fragility = FALSE)
#'   postrank_plot_compare(postrank_compare(fit))
#' }
#' @export
postrank_plot_compare <- function(x, view = c("summary", "relations"), ...) {
  view <- match.arg(view)
  .pr_assert(inherits(x, "postrank_comparison"), "x must be a postrank_comparison", "wrong_class", "$.x")
  t <- x$table; methods <- t$method
  family_recorded <- all(c("family_feasible", "feasibility_reason") %in% names(t))
  outside <- if (family_recorded) t[t$family_feasible %in% FALSE, , drop = FALSE] else t[FALSE, , drop = FALSE]
  display <- stats::setNames(methods, methods)
  if (nrow(outside)) display[outside$method] <- paste0(outside$method, " [outside family]")
  family_note <- if (nrow(outside)) paste("Outside declared family:",
    paste0(outside$method, " (", outside$feasibility_reason, ")", collapse = "; ")) else
    if (!family_recorded) "Family feasibility was not recorded; recreate the comparison to check constraints." else NULL
  cap <- "Same posterior, weights and tau. Under the same grade and budget constraints, admissible score-order partitions are a subset of the full family, whose minimum cannot exceed theirs. Points are selected actions; read their status, scope, family feasibility and gap."
  if (view == "relations") {
    r <- x$relations[!is.na(x$relations$n_same), , drop = FALSE]
    if (!nrow(r)) return(.pr_status_panel("Relation changes versus the joint rule", "no compared action with a grade"))
    long <- do.call(rbind, lapply(seq_len(nrow(r)), function(i) data.frame(method = r$method[i],
      change = c("unchanged", "newly disclosed", "newly withheld", "reversed"),
      count = c(r$n_same[i], r$n_new_disclosed[i], r$n_new_withheld[i], r$n_reversed[i]), stringsAsFactors = FALSE)))
    long$change <- factor(long$change, levels = c("unchanged", "newly disclosed", "newly withheld", "reversed"))
    long$method <- factor(long$method, levels = rev(r$method))
    return(ggplot2::ggplot(long, ggplot2::aes(y = .data$method, x = .data$count, fill = .data$change)) +
      ggplot2::geom_col(width = 0.6) +
      ggplot2::scale_fill_manual(values = postrank_palette(which = "change"), drop = FALSE, name = "relation change") +
      .pr_labs(title = "Relation changes versus the joint rule",
        subtitle = paste(c(paste("agreement:", paste(r$method, .pr_fmt(r$agreement, "ratio"), collapse = ", ")), family_note), collapse = " | "),
        x = "entity pairs", y = NULL, caption = cap) + ggplot2::scale_y_discrete(labels = display) + theme_postrank())
  }
  rows <- t[!is.na(t$risk), , drop = FALSE]
  missing <- t[is.na(t$risk), , drop = FALSE]
  long <- rbind(
    data.frame(method = rows$method, metric = "risk R", value = rows$risk, stringsAsFactors = FALSE),
    data.frame(method = rows$method, metric = "disclosure N/M", value = rows$disclosure_rate, stringsAsFactors = FALSE),
    data.frame(method = rows$method, metric = "grades G", value = rows$G, stringsAsFactors = FALSE))
  long$metric <- factor(long$metric, levels = c("risk R", "disclosure N/M", "grades G"))
  long$method <- factor(long$method, levels = rev(methods)); long$joint <- long$method == x$reference
  lb <- rows[!is.na(rows$risk_lower_bound), , drop = FALSE]
  lbd <- data.frame(method = factor(lb$method, levels = rev(methods)), metric = factor(rep("risk R", nrow(lb)), levels = levels(long$metric)),
    value = lb$risk_lower_bound)
  sub <- sprintf("%d methods; reference %s", nrow(t), x$reference)
  if (!is.null(family_note)) sub <- paste(sub, family_note, sep = " | ")
  if (nrow(missing)) sub <- paste0(sub, " | no action: ", paste(sprintf("%s (%s%s)", missing$method, missing$status,
    ifelse(is.na(missing$reason), "", paste0(", ", missing$reason))), collapse = "; "))
  ggplot2::ggplot(long, ggplot2::aes(x = .data$value, y = .data$method)) +
    ggplot2::geom_point(data = lbd, shape = 124, size = 4, colour = "grey40") +
    ggplot2::geom_point(ggplot2::aes(shape = .data$method, fill = .data$joint), colour = "#1F6F8B", size = 2.6) +
    ggplot2::scale_fill_manual(values = c(`TRUE` = "#1F6F8B", `FALSE` = "white"), guide = "none") +
    ggplot2::scale_shape_manual(values = stats::setNames(rep(c(21, 22, 24, 23, 25), length.out = length(methods)), methods), labels = display, name = "method") +
    ggplot2::scale_y_discrete(labels = display) +
    ggplot2::facet_wrap(~ metric, scales = "free_x", nrow = 1, labeller = ggplot2::label_wrap_gen(width = 10)) +
    ggplot2::guides(shape = ggplot2::guide_legend(nrow = 2, byrow = TRUE)) +
    ggplot2::scale_x_continuous(breaks = scales::breaks_extended(n = 3), guide = ggplot2::guide_axis(check.overlap = TRUE)) +
    .pr_labs(title = "Grading rules on one posterior and loss", subtitle = sub, x = NULL, y = NULL,
      caption = paste(cap, "Tick = stored solver lower bound (solved fits only).")) +
    theme_postrank() + ggplot2::theme(panel.spacing.x = ggplot2::unit(1.5, "lines"))
}

#' @importFrom ggplot2 autoplot
#' @export
ggplot2::autoplot

.pr_autoplot_type <- function(type, allowed) {
  .pr_assert(is.character(type) && length(type) == 1L && type %in% allowed, paste("type must be one of", paste(allowed, collapse = ", ")),
    "invalid_display", "$.type")
  type
}
#' @export
autoplot.postrank_analysis <- function(object, type = "report_card", ...) {
  switch(.pr_autoplot_type(type, c("report_card", "relations", "profile")),
    report_card = postrank_plot_report_card(object, ...), relations = postrank_plot_relations(object, ...),
    profile = postrank_plot_profile(object, ...))
}
#' @export
autoplot.postrank_fit <- function(object, type = "relations", ...) {
  switch(.pr_autoplot_type(type, c("relations", "profile")),
    relations = postrank_plot_relations(object, ...), profile = postrank_plot_profile(object, ...))
}
#' @export
autoplot.postrank_report_card <- function(object, ...) postrank_plot_report_card(object, ...)
#' @export
autoplot.postrank_frontier <- function(object, ...) postrank_plot_frontier(object, ...)
#' @export
autoplot.postrank_commonality_cost <- function(object, ...) postrank_plot_commonality(object, ...)
#' @export
autoplot.postrank_comparison <- function(object, ...) postrank_plot_compare(object, ...)
#' @export
autoplot.postrank_baseline <- function(object, ...) postrank_plot_relations(object, ...)

.pr_plot_method <- function(x, ...) { p <- ggplot2::autoplot(x, ...); print(p); invisible(p) }
#' @export
plot.postrank_analysis <- function(x, ...) .pr_plot_method(x, ...)
#' @export
plot.postrank_fit <- function(x, ...) .pr_plot_method(x, ...)
#' @export
plot.postrank_report_card <- function(x, ...) .pr_plot_method(x, ...)
#' @export
plot.postrank_frontier <- function(x, ...) .pr_plot_method(x, ...)
#' @export
plot.postrank_commonality_cost <- function(x, ...) .pr_plot_method(x, ...)
#' @export
plot.postrank_comparison <- function(x, ...) .pr_plot_method(x, ...)
#' @export
plot.postrank_baseline <- function(x, ...) .pr_plot_method(x, ...)
