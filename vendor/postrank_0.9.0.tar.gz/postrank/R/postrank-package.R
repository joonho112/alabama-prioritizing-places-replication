#' postrank: Multicriteria Posterior Ranking with Common Integer Grades
#'
#' postrank turns posterior information about several criteria into one common
#' integer grade per entity under a declared loss. It fits no model; it starts
#' from posterior draws or posterior coefficients that an external producer
#' made, together with their scientific declarations.
#'
#' @section What the grade means:
#' Grade 1 is the highest-priority block; larger targets mean higher priority,
#' and only the order and equality of grade labels matter. A shared grade
#' withholds the comparison of its members and asserts no equality of the
#' entities. The procedure seeks a grade minimizing the declared weighted
#' wrong-direction loss plus the withholding cost `tau`, and reports the
#' validated incumbent with the solver's bound and gap; withholding every
#' comparison, with risk `tau`, is a legitimate action.
#'
#' @section Layers:
#' \tabular{ll}{
#'   Input \tab [postrank_draws()], [postrank_declarations()], [read_postrank_draws()] and the strict constructors \cr
#'   Coefficients \tab [postrank_pairwise()], [postrank_gaussian_coefficients()], [postrank_mixture_coefficients()] \cr
#'   Settings and control \tab [postrank_settings()], [postrank_control()] \cr
#'   Decision \tab [postrank()], [postrank_problem()], [postrank_solve()], [postrank_evaluate()] \cr
#'   Baselines and comparison \tab [postrank_expected_rank()], [postrank_composite()], [postrank_cuts()], [postrank_compare()] \cr
#'   Side outputs and grids \tab [postrank_commonality_cost()], [postrank_frontier()], [postrank_sensitivity()] \cr
#'   Diagnostics \tab [postrank_crossfit()], [postrank_mc_fragility()], [postrank_diagnose()] \cr
#'   Reporting \tab [postrank_report_card()], [postrank_report()], [get_grades()] and the console formatters \cr
#'   Visualization \tab the six `postrank_plot_*()` figures, [theme_postrank()], [postrank_palette()] \cr
#'   Reference calculations \tab [postrank_iid_bounds()] and the conditional guarantee helpers
#' }
#'
#' @section Citation:
#' `citation("postrank")` returns the package entry and the method it builds
#' on: Kline, P., Rose, E. K., and Walters, C. R. (2024). A discrimination
#' report card. *American Economic Review*, 114(8), 2472-2525.
#' \doi{10.1257/aer.20230700}
#'
#' @seealso [postrank_options], `vignette("quickstart", package = "postrank")`
#' @keywords internal
"_PACKAGE"
