# Shared-h conditional Gaussian mixtures, distinct from latent target draws.
.pr_cf_mixture_axes <- function(components) {
  .pr_assert(is.list(components) && !is.data.frame(components) && length(components) > 0L &&
    is.list(components[[1L]]) && is.matrix(components[[1L]]$means),
    "components require a nonempty named conditional-state list", "invalid_coefficients")
  list(ids = rownames(components[[1L]]$means), ks = colnames(components[[1L]]$means))
}
.pr_cf_mixture_add <- function(total, correction, value) {
  adjusted <- value - correction
  next_total <- total + adjusted
  list(total = next_total, correction = (next_total - total) - adjusted)
}

# Internal projection of an already structurally validated mathematical source.
# Mu/Sigma remain source declarations: this does not verify an actual Y/V fit.
.pr_cf_project_mixture <- function(source) {
  axes <- .pr_cf_mixture_axes(source$components)
  ids <- axes$ids; ks <- axes$ks; n <- length(ids); K <- length(ks)
  means <- matrix(0, n, K, dimnames = list(entity = ids, criterion = ks))
  e <- array(0, c(n, n, K), dimnames = list(entity_i = ids, entity_j = ids, criterion = ks))
  mean_correction <- means; e_correction <- e
  diagonal <- row(matrix(0, n, n)) == col(matrix(0, n, n))
  for (s in seq_along(source$components)) {
    state <- source$components[[s]]
    gaussian <- list(kind = "gaussian_conditional", means = state$means,
      covariance = state$covariance, conditional_independence = source$conditional_independence)
    projection <- .pr_cf_project_gaussian(gaussian)
    update <- .pr_cf_mixture_add(means, mean_correction, source$weights[s] * projection$means)
    means <- update$total; mean_correction <- update$correction
    state_e <- projection$e
    for (k in seq_len(K)) state_e[, , k][diagonal] <- 0
    update <- .pr_cf_mixture_add(e, e_correction, source$weights[s] * state_e)
    e <- update$total; e_correction <- update$correction
  }
  for (k in seq_len(K)) e[, , k][diagonal] <- NA_real_
  list(means = means, e = e)
}

#' Typed Coefficients from a Shared-State Gaussian Mixture
#'
#' Each supplied hyperstate is shared by all entities. Conditional Gaussian
#' pair probabilities and means are averaged using compensated summation. No
#' target draws, target sample counts or rational finite-law interpretation are
#' created. The `mu`/`Sigma` and conditional moments are source declarations,
#' not proof that one observed dataset or a converged sampler produced those
#' values.
#'
#' Fixed finite states carry no fabricated MCMC coordinates. A declared MCMC
#' source requires original positive integer chain/iteration coordinates and
#' uniform retained-hyperstate weights. This validates structure, not sampler
#' truth or convergence. Source records remain bound to the output identity;
#' consumers verify expected source lineage and may request an explicit
#' projection audit with `validate_postrank_coefficients(x, recompute = TRUE)`.
#'
#' @param components Named list of supplied state records, each with exactly
#'   `mu`, `Sigma`, `means` and `covariance` on the declared entity and
#'   criterion axes.
#' @param weights Finite nonnegative state-named weights in exact component
#'   order, summing to one within the contract tolerance; no normalization is
#'   performed.
#' @param state_index Plain data.frame with `state_id` only for a fixed finite
#'   mixture; `state_id`, `chain_id` and original `iteration` for
#'   hyperparameter MCMC.
#' @param source_regime One of `"fixed_finite_mixture"` or
#'   `"hyperparameter_mcmc"`.
#' @param conditional_independence Required explicit
#'   `"entities_given_shared_h"`. There is no default that infers independence
#'   from marginal moments.
#' @param provenance Explicit `producer_id`, `producer_version`,
#'   `posterior_id`, `input_payload_sha256`, `source_sha256` and
#'   `config_sha256`; `model_sha256` is optional.
#' @return A sealed `postrank_coefficients` object, with inseparable means and
#'   `e`, the supplied mathematical source, derived capabilities and explicit
#'   false scientific verification flags.
#' @seealso [validate_postrank_coefficients()], [postrank_gaussian_coefficients()]
#' @examples
#' ids <- c("A", "B"); ks <- "k1"
#' covariance <- array(.5, c(1, 1, 2),
#'   dimnames = list(criterion_i = ks, criterion_j = ks, entity = ids))
#' state <- function(d) list(mu = c(k1 = d),
#'   Sigma = matrix(1, 1, 1, dimnames = list(criterion_i = ks, criterion_j = ks)),
#'   means = matrix(c(d, .4), 2, 1, dimnames = list(entity = ids, criterion = ks)),
#'   covariance = covariance)
#' components <- list(s1 = state(-1), s2 = state(.5))
#' provenance <- list(producer_id = "documentation-example", producer_version = "1",
#'   posterior_id = "fixed-two-state-mixture", input_payload_sha256 = strrep("a", 64),
#'   source_sha256 = strrep("b", 64), config_sha256 = strrep("c", 64))
#' x <- postrank_mixture_coefficients(components, c(s1 = .5, s2 = .5),
#'   data.frame(state_id = c("s1", "s2")), "fixed_finite_mixture",
#'   "entities_given_shared_h", provenance)
#' x$means
#' @concept coefficients
#' @export
postrank_mixture_coefficients <- function(components, weights, state_index,
    source_regime, conditional_independence, provenance) {
  axes <- .pr_cf_mixture_axes(components)
  .pr_cf_ids(axes$ids, 2L); .pr_cf_ids(axes$ks)
  source <- list(kind = "shared_hyperstate_mixture", components = components,
    weights = weights, state_index = state_index, source_regime = source_regime,
    conditional_independence = conditional_independence)
  .pr_cf_mixture_source(source, axes$ids, axes$ks)
  .pr_cf_provenance(provenance)
  projection <- .pr_cf_project_mixture(source)
  .pr_coefficient_assemble(source, projection$means, projection$e, provenance)
}
