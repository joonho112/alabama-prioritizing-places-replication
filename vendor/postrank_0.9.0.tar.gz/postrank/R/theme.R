# Theme, palettes and named grade scales (Chapter 12, PR-DEC-12-B).

#' The postrank ggplot2 Theme
#'
#' `ggplot2::theme_minimal()` with a light horizontal grid, axis lines, a
#' bold left-aligned title, a single bottom legend and explicit white
#' backgrounds (the palette contrast contract assumes a white background).
#'
#' @param base_size Base font size in points.
#' @param base_family Base font family.
#' @return A ggplot2 `theme`.
#' @seealso [postrank_palette()], [scale_colour_grade()]
#' @concept visualization
#' @examples
#' ggplot2::ggplot(data.frame(x = 1:3, y = 1:3), ggplot2::aes(x, y)) +
#'   ggplot2::geom_point() + theme_postrank()
#' @export
theme_postrank <- function(base_size = 11, base_family = "") {
  ggplot2::theme_minimal(base_size = base_size, base_family = base_family) +
    ggplot2::theme(
      panel.grid.minor = ggplot2::element_blank(), panel.grid.major.x = ggplot2::element_blank(),
      panel.grid.major.y = ggplot2::element_line(colour = "grey90", linewidth = 0.3),
      axis.line = ggplot2::element_line(colour = "grey20", linewidth = 0.4),
      axis.ticks = ggplot2::element_line(colour = "grey20", linewidth = 0.3),
      plot.title = ggplot2::element_text(face = "bold", hjust = 0), plot.title.position = "plot",
      plot.subtitle = ggplot2::element_text(colour = "grey30", hjust = 0),
      plot.caption = ggplot2::element_text(colour = "grey40", hjust = 0), plot.caption.position = "plot",
      legend.position = "bottom", legend.box = "vertical", legend.title.position = "top",
      legend.key.size = ggplot2::unit(0.9, "lines"), plot.margin = ggplot2::margin(5.5, 12, 5.5, 5.5),
      strip.text = ggplot2::element_text(face = "bold"),
      plot.background = ggplot2::element_rect(fill = "#FFFFFF", colour = NA),
      panel.background = ggplot2::element_rect(fill = "#FFFFFF", colour = NA))
}

.pr_grade_ends <- c("#153653", "#4F879E")
.pr_relation_colours <- c(above = "#0072B2", withheld = "grey80", below = "#E69F00")
.pr_change_colours <- c(unchanged = "grey92", `newly disclosed` = "#0072B2", `newly withheld` = "#999999", reversed = "#D55E00")
.pr_sequential_colours <- c("#EFF3FF", "#C6DBEF", "#9ECAE1", "#6BAED6", "#4292C6", "#2171B5", "#084594")

.pr_rel_luminance <- function(hex) {
  rgb <- grDevices::col2rgb(hex) / 255
  lin <- ifelse(rgb <= 0.04045, rgb / 12.92, ((rgb + 0.055) / 1.055)^2.4)
  as.numeric(c(0.2126, 0.7152, 0.0722) %*% lin)
}
.pr_contrast <- function(a, b) { la <- .pr_rel_luminance(a); lb <- .pr_rel_luminance(b); (max(la, lb) + 0.05) / (min(la, lb) + 0.05) }

#' Grade, Relation, Change and Sequential Palettes
#'
#' `"grade"` interpolates the sRGB channels from `#153653` (grade 1, darkest,
#' highest priority) to `#4F879E` for `1 <= n <= 64` grades: relative luminance
#' strictly increases with the grade label and every color keeps a contrast of
#' at least 3 against white. The result is named `"1"` to `"n"`. `"relation"`
#' (above / withheld / below) and `"change"` (unchanged / newly disclosed /
#' newly withheld / reversed) use color-blind-safe Okabe-Ito colors with gray
#' for withheld or unchanged pairs; `"sequential"` is a seven-stop Blues ramp.
#'
#' @param n Number of colors (`"grade"` only; ignored otherwise).
#' @param which Which palette.
#' @return A named character vector of hex colors.
#' @seealso [scale_colour_grade()], [theme_postrank()]
#' @concept visualization
#' @examples
#' postrank_palette(4)
#' postrank_palette(which = "relation")
#' @export
postrank_palette <- function(n, which = c("grade", "relation", "change", "sequential")) {
  which <- match.arg(which)
  if (which == "relation") return(.pr_relation_colours)
  if (which == "change") return(.pr_change_colours)
  if (which == "sequential") return(.pr_sequential_colours)
  if (!is.numeric(n) || length(n) != 1L || !is.finite(n) || n != floor(n) || n < 1 || n > 64)
    .pr_abort("the grade palette supports 1 to 64 grades; above 64 views use neutral ink and explicit labels",
      "invalid_palette_size", "$.n")
  n <- as.integer(n)
  a <- grDevices::col2rgb(.pr_grade_ends[1L])[, 1]; b <- grDevices::col2rgb(.pr_grade_ends[2L])[, 1]
  t <- if (n == 1L) 0 else (seq_len(n) - 1) / (n - 1)
  cols <- vapply(t, function(ti) { ch <- floor(a + (b - a) * ti + 0.5); grDevices::rgb(ch[1], ch[2], ch[3], maxColorValue = 255) }, "")
  stats::setNames(cols, as.character(seq_len(n)))
}

#' Ordinal Grade Color and Fill Scales
#'
#' Discrete scales over the named grade palette with
#' `limits = as.character(seq_len(G))` and `drop = FALSE`, so that a view
#' showing only some grades still draws each grade in its own color. `G` is
#' the number of grades of the whole object (pass `n_grades`); it is never
#' derived from a visible subset.
#'
#' @param n_grades The number of grades `G` of the object (1 to 64). With
#'   `NULL` the levels present in the data are colored in order; pass `n_grades`
#'   whenever some grades may be absent from the plotted rows.
#' @param ... Passed to [ggplot2::discrete_scale()].
#' @return A ggplot2 discrete scale.
#' @seealso [postrank_palette()]
#' @concept visualization
#' @examples
#' scale_colour_grade(3)
#' @export
scale_colour_grade <- function(n_grades = NULL, ...) .pr_grade_scale("colour", n_grades, ...)
#' @rdname scale_colour_grade
#' @export
scale_color_grade <- function(n_grades = NULL, ...) .pr_grade_scale("colour", n_grades, ...)
#' @rdname scale_colour_grade
#' @export
scale_fill_grade <- function(n_grades = NULL, ...) .pr_grade_scale("fill", n_grades, ...)
.pr_grade_scale <- function(aesthetic, n_grades, ...) {
  if (is.null(n_grades)) return(ggplot2::discrete_scale(aesthetics = aesthetic, palette = function(n) unname(postrank_palette(n)),
    drop = FALSE, name = "grade", ...))
  pal <- postrank_palette(n_grades)
  ggplot2::discrete_scale(aesthetics = aesthetic, palette = function(n) unname(pal[seq_len(n)]),
    limits = names(pal), drop = FALSE, name = "grade", ...)
}

# Wrap figure titles, subtitles and captions so that they also fit the 3.4-inch canvas
# (about 32 title, 42 subtitle and 48 caption characters per line at the default sizes).
.pr_wrap_label <- function(text, width = 100L) if (is.null(text)) NULL else paste(strwrap(text, width = width), collapse = "\n")
.pr_labs <- function(...) {
  a <- list(...)
  if (is.character(a$title)) a$title <- .pr_wrap_label(a$title, 32L)
  if (!is.null(a$subtitle)) a$subtitle <- .pr_wrap_label(a$subtitle, 42L)
  if (!is.null(a$caption)) a$caption <- .pr_wrap_label(a$caption, 48L)
  do.call(ggplot2::labs, a)
}
