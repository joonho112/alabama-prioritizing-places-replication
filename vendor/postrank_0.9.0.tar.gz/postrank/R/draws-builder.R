# Input builder (014 repair, AP-2): the scientific declarations stay required
# arguments; the bookkeeping (slot IDs, draw index, variable map, chain
# history, hashes) is generated from the array and the declared layout.

.pr_builder_text <- function(x, name) {
  .pr_assert(is.character(x) && length(x) == 1L && !is.na(x) && nzchar(trimws(x)),
    paste(name, "must be one nonempty character string"), "invalid_builder_input")
  x
}

.pr_builder_record <- function(x, required, name) {
  .pr_assert(is.list(x) && !is.data.frame(x) && !is.null(names(x)) && all(required %in% names(x)),
    paste0(name, " must be a named list with ", paste(required, collapse = ", ")), "invalid_builder_input")
  for (f in required) .pr_builder_text(x[[f]], paste0(name, "$", f))
  x[required]
}

#' Build Validated Joint Draws from a Posterior Array
#'
#' Wraps an \code{S x n x K} array of joint posterior draws (draw, entity,
#' criterion) into the canonical \code{applied-0.1} payload and validates it
#' with \code{\link{as_postrank_draws}}. The scientific declarations remain
#' required arguments: what each criterion's target is, the analysis context,
#' provenance, why exact within-criterion ties have probability zero, and that
#' every draw is one joint state. Slot IDs, the draw index, the variable map,
#' MCMC chain history and content hashes are generated.
#' @param values Numeric array with \code{dim = c(S, n, K)} and dimnames for
#'   entities (second axis) and criteria (third axis). Larger values must mean
#'   higher priority. Draw names are generated when absent.
#' @param regime \code{"iid"} or \code{"mcmc"}.
#' @param chains For MCMC (required), the number of chains; draws must be stored
#'   chain by chain (all draws of chain 1, then chain 2, ...) with equal
#'   lengths. Leave unset for IID draws.
#' @param targets Either a list of per-criterion records or a data frame with
#'   columns \code{criterion_id}, \code{estimand}, \code{entity_population},
#'   \code{time_reference}, \code{units}; optional \code{source_transform}
#'   (default \code{"identity"}) and \code{identification_basis}.
#' @param context Named list with \code{cohort_id}, \code{data_version},
#'   \code{data_conditioning} and \code{model_summary}.
#' @param provenance Named list with \code{producer}, \code{artifact_id} and
#'   \code{construction_note}; \code{artifact_hash} defaults to the SHA-256 of
#'   \code{values}.
#' @param origin Named list with \code{source_id}, \code{fit_id},
#'   \code{model_id}, \code{source_format} and \code{source_artifact}.
#' @param identification_note Why every target is identified.
#' @param tie_justification Why exact within-criterion ties between distinct
#'   entities have probability zero (observed ties are still rejected).
#' @param joint_generation How each draw holds one joint state of all entities
#'   and criteria.
#' @param sampling_provenance How the draws were produced.
#' @param warmup_per_chain For MCMC (required), the number of warmup iterations
#'   removed before the retained draws on each chain; 0 declares that the
#'   retained draws start at the first iteration. Leave unset for IID draws.
#' @param thin For MCMC (required), the retained-iteration spacing (1 for no
#'   thinning). Leave unset for IID draws.
#' @details For MCMC the chain layout (\code{chains}, \code{warmup_per_chain},
#'   \code{thin}) is a declaration about how the draws were produced and is
#'   never assumed; the builder only turns it into iteration numbers.
#' @return A validated \code{postrank_draws} object.
#' @examples
#' set.seed(1)
#' values <- array(stats::rnorm(200 * 4 * 2), c(200, 4, 2),
#'   dimnames = list(NULL, c("A", "B", "C", "D"), c("need1", "need2")))
#' draws <- postrank_draws_from_array(values, regime = "iid",
#'   targets = data.frame(criterion_id = c("need1", "need2"),
#'     estimand = "Illustrative latent need", entity_population = "Four example sites",
#'     time_reference = "Example year", units = "standardized units"),
#'   context = list(cohort_id = "example", data_version = "1",
#'     data_conditioning = "Simulated values for illustration",
#'     model_summary = "Independent standard Normal draws"),
#'   provenance = list(producer = "help example", artifact_id = "example-array",
#'     construction_note = "Generated in the help page"),
#'   origin = list(source_id = "example", fit_id = "none", model_id = "normal",
#'     source_format = "R array", source_artifact = "help example"),
#'   identification_note = "Targets are defined directly by the simulation.",
#'   tie_justification = "Continuous draws; exact ties have probability zero.",
#'   joint_generation = "Each draw holds all sites and criteria from one state.",
#'   sampling_provenance = "IID draws from the stated Normal law.")
#' pw <- postrank_pairwise(draws)
#' dim(pw$e)
#' @concept input
#' @export
postrank_draws_from_array <- function(values, regime = c("iid", "mcmc"), chains = NULL, targets, context, provenance,
                                      origin, identification_note, tie_justification, joint_generation,
                                      sampling_provenance, warmup_per_chain = NULL, thin = NULL) {
  regime <- match.arg(regime)
  .pr_assert(is.array(values) && is.numeric(values) && length(dim(values)) == 3L,
    "values must be a numeric S x n x K array", "invalid_builder_input")
  d <- dim(values); S <- d[1L]; n <- d[2L]; K <- d[3L]
  dn <- dimnames(values)
  .pr_assert(!is.null(dn) && !is.null(dn[[2L]]) && !is.null(dn[[3L]]),
    "values needs entity (2nd axis) and criterion (3rd axis) dimnames", "invalid_builder_input")
  entities <- as.character(dn[[2L]]); criteria <- as.character(dn[[3L]])
  slots <- if (is.null(dn[[1L]])) sprintf("draw_%06d", seq_len(S)) else as.character(dn[[1L]])
  storage.mode(values) <- "double"
  dimnames(values) <- list(draw = slots, entity = entities, criterion = criteria)
  if (is.data.frame(targets)) targets <- lapply(seq_len(nrow(targets)), function(r) as.list(targets[r, , drop = FALSE]))
  .pr_assert(is.list(targets) && length(targets) == K, "targets needs one record per criterion", "invalid_builder_input")
  required_target <- c("criterion_id", "estimand", "entity_population", "time_reference", "units")
  targets <- lapply(targets, function(z) {
    z <- lapply(z, function(v) if (is.factor(v)) as.character(v) else v)
    out <- .pr_builder_record(z, required_target, "targets")
    out$source_transform <- if (is.null(z$source_transform)) "identity" else .pr_builder_text(z$source_transform, "targets$source_transform")
    out$identification_basis <- if (is.null(z$identification_basis)) identification_note else .pr_builder_text(z$identification_basis, "targets$identification_basis")
    out$orientation <- "higher_priority"
    out
  })
  context <- .pr_builder_record(context, c("cohort_id", "data_version", "data_conditioning", "model_summary"), "context")
  value_hash <- digest::digest(values, algo = "sha256", serialize = TRUE)
  prov <- .pr_builder_record(provenance, c("producer", "artifact_id", "construction_note"), "provenance")
  prov$artifact_hash <- if (is.null(provenance$artifact_hash)) value_hash else .pr_builder_text(provenance$artifact_hash, "provenance$artifact_hash")
  prov$created_at <- if (is.null(provenance$created_at)) format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC") else
    .pr_builder_text(provenance$created_at, "provenance$created_at")
  orig <- .pr_builder_record(origin, c("source_id", "fit_id", "model_id", "source_format", "source_artifact"), "origin")
  orig$source_hash <- if (is.null(origin$source_hash)) value_hash else .pr_builder_text(origin$source_hash, "origin$source_hash")
  orig$vector_generation_provenance <- .pr_builder_text(joint_generation, "joint_generation")
  orig$within_criterion_joint_declared <- TRUE
  variable_map <- unlist(lapply(seq_len(K), function(k) lapply(seq_len(n), function(i)
    list(entity_id = entities[i], criterion_id = criteria[k], source_target_variable_id = sprintf("theta[%d,%d]", i, k),
      derivation_note = "Array coordinate (entity, criterion) of the supplied values; identity transform."))), recursive = FALSE)
  layout <- list(chains = chains, warmup_per_chain = warmup_per_chain, thin = thin)
  unset <- vapply(layout, is.null, logical(1L))
  if (identical(regime, "iid")) {
    .pr_assert(all(unset), "chains, warmup_per_chain and thin describe MCMC chains; leave them unset for IID draws",
      "invalid_builder_input")
    draw_index <- lapply(seq_len(S), function(s) list(slot_id = slots[s], original_draw_id = slots[s], chain_id = NULL, iteration = NULL))
    sampling <- list(regime = "iid", target_distribution = "declared_posterior", equal_weight = TRUE, warmup_status = "not_applicable",
      sampling_provenance = .pr_builder_text(sampling_provenance, "sampling_provenance"), chain_history = list())
  } else {
    .pr_assert(!any(unset), paste0("MCMC draws need explicit ", paste(names(layout)[unset], collapse = ", "),
      ": the number of chains, the warmup iterations removed before the retained draws on each chain and the ",
      "retained-iteration spacing are declarations and are not assumed"), "invalid_builder_input")
    for (a in layout) .pr_assert(typeof(a) %in% c("integer", "double") && length(a) == 1L && is.finite(a) && a == floor(a),
      "chains, warmup_per_chain and thin must be whole numbers", "invalid_builder_input")
    .pr_assert(chains >= 1L && warmup_per_chain >= 0L && thin >= 1L && S %% chains == 0L,
      "MCMC draws must split into equal chain-major blocks", "invalid_builder_input")
    L <- S %/% chains; ids <- sprintf("chain%d", seq_len(chains))
    iter <- warmup_per_chain + thin * seq_len(L)
    draw_index <- lapply(seq_len(S), function(s) list(slot_id = slots[s], original_draw_id = slots[s],
      chain_id = ids[(s - 1L) %/% L + 1L], iteration = iter[(s - 1L) %% L + 1L]))
    history <- lapply(ids, function(c) list(chain_id = c, retained_iterations = iter,
      warmup_iterations = if (warmup_per_chain > 0) seq_len(warmup_per_chain) else numeric(),
      discarded_sampling_iterations = setdiff(seq.int(warmup_per_chain + 1L, max(iter)), iter),
      selection_note = sprintf("Builder layout: %d warmup iterations removed, thinning %d.", as.integer(warmup_per_chain), as.integer(thin))))
    sampling <- list(regime = "mcmc", target_distribution = "declared_posterior", equal_weight = TRUE, warmup_status = "removed",
      sampling_provenance = .pr_builder_text(sampling_provenance, "sampling_provenance"), chain_history = history)
  }
  payload <- list(schema_version = "applied-0.1", input_kind = "equal_weight_draws", dependence_mode = "joint_model",
    requested_functional = "expected_rank_loss", entity_ids = entities, criterion_ids = criteria, targets = targets,
    context = context, identification = list(status = "identified_declared", note = .pr_builder_text(identification_note, "identification_note")),
    tie_policy = list(rule = "pairwise_tie_free", declared = TRUE, justification = .pr_builder_text(tie_justification, "tie_justification"),
      observed_tie_action = "reject_and_review"),
    provenance = prov,
    joint_draws = list(tensor = list(axis_order = c("draw", "entity", "criterion"), shape = list(S = S, n = n, K = K),
      dimnames = dimnames(values), values = values), origin = orig, sampling = sampling, draw_index = draw_index,
      variable_map = variable_map, cross_criterion_joint_provenance = orig$vector_generation_provenance))
  as_postrank_draws(payload)
}
