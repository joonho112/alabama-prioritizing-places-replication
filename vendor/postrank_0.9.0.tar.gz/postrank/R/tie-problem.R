# Separate tie-aware problem path. No legacy object inherits from these classes,
# and no legacy coefficient, settings or solver behavior is reinterpreted here.

.pr_tie_loss_settings <- function(pairwise, weights, tau) {
  validate_postrank_tie_pairwise(pairwise)
  # This shared helper validates only the policy vector and tau; it does not
  # dispatch to the legacy pairwise validator or assume reverse complements.
  settings <- .pr_loss_settings(pairwise, weights, tau)
  settings$active_criteria <- pairwise$criterion_ids[settings$weights > 0]
  settings
}

.pr_tie_guard <- function(pairwise, weights) {
  ids <- pairwise$entity_ids
  active <- pairwise$criterion_ids[weights[pairwise$criterion_ids] > 0]
  .pr_assert(length(active) > 0L, "tie-aware loss requires an active criterion", "invalid_weights")
  classes <- rep(1L, length(ids))
  for (k in active) {
    partition <- pairwise$equality$criterion_classes[[k]]
    .pr_assert(is.character(partition) && identical(names(partition), ids) &&
      !anyNA(partition) && all(nzchar(partition)),
      "tie-aware pairwise input lacks a complete criterion equality partition", "invalid_tie_equality")
    # Both components are integer class numbers, so this key cannot collide
    # when opaque source labels contain punctuation or separators.
    key <- paste(classes, match(partition, unique(partition)), sep = ":")
    classes <- match(key, unique(key))
  }
  labels <- paste0("profile_", classes)
  names(labels) <- ids
  groups <- lapply(seq_len(max(classes)), function(j) ids[classes == j])
  names(groups) <- paste0("profile_", seq_along(groups))
  list(classes = labels, groups = groups, active_criteria = active,
    source = "criterion_class_intersection", basis = pairwise$equality$basis,
    justification = pairwise$equality$justification,
    criterion_classes = pairwise$equality$criterion_classes[active],
    evidence = pairwise$equality$evidence, pairwise_identity = pairwise$pairwise_identity)
}

.pr_tie_guard_satisfied <- function(grade, guard) {
  all(vapply(guard$groups, function(ids) length(unique(unname(grade[ids]))) == 1L, logical(1L)))
}

.pr_tie_weighted_coefficients <- function(pairwise, settings) {
  n <- length(pairwise$entity_ids)
  cost <- distinct <- matrix(0, n, n)
  for (k in seq_along(pairwise$criterion_ids)) {
    b <- matrix(pairwise$b[, , k], nrow = n, ncol = n)
    d <- matrix(pairwise$d[, , k], nrow = n, ncol = n)
    diag(b) <- 0
    diag(d) <- 0
    cost <- cost + settings$weights[k] * b
    distinct <- distinct + settings$weights[k] * d
  }
  list(wrong = cost, distinct = distinct,
    centered = cost - settings$tau * distinct,
    baseline = settings$tau * sum(distinct[upper.tri(distinct)]) / choose(n, 2))
}

.pr_validate_tie_problem <- function(problem) {
  .pr_assert(inherits(problem, "postrank_tie_problem") &&
    !inherits(problem, "postrank_problem") &&
    identical(problem$schema_version, "tie-problem-0.1.0") &&
    identical(problem$loss, "tie_aware_v1"),
    "expected a current separate postrank_tie_problem", "invalid_tie_problem")
  .pr_assert(requireNamespace("Matrix", quietly = TRUE),
    "Matrix is required for sparse model methods", "matrix_package_missing")
  validate_postrank_tie_pairwise(problem$pairwise)
  content <- problem
  content$problem_identity <- NULL
  .pr_assert(is.character(problem$problem_identity) && length(problem$problem_identity) == 1L &&
    identical(.pr_tie_identity(content, "postrank_tie_problem:0.1.0"), problem$problem_identity),
    "tie-aware problem changed after construction; rebuild it from pairwise inputs", "stale_tie_problem_identity")
  .pr_assert(identical(problem$settings$objective, "weighted") &&
    is.null(problem$settings$q) && is.null(problem$settings$exact_G),
    "tie-aware problems support weighted at-most-G only", "unsupported_tie_mode_capability")
  invisible(TRUE)
}

#' Build a Separate Equality-Neutral Common-Grade Problem
#'
#' Constructs the weighted at-most-G label mixed-integer model for the
#' \code{tie_aware_v1} loss. This is a separate, opt-in object family; it does not
#' alter the tie-free postrank mode.
#'
#' @param pairwise A sealed \code{postrank_tie_pairwise} object containing
#'   strict wrong, equality and distinct-event probabilities and verified
#'   criterion equality partitions.
#' @param weights Nonnegative finite criterion-named weights summing to one.
#'   All criteria must be named exactly once. Weights are not normalized.
#' @param tau Cost of withholding a distinct comparison, with
#'   \code{0 < tau <= 0.5}.
#' @param G_max Positive integer upper bound on occupied grades, no larger than
#'   the original entity count. It does not require exactly that many grades.
#' @param objective Only \code{"weighted"} is supported in this mode.
#' @param q Must be \code{NULL}; tie-aware error-budget protection is unsupported.
#' @param exact_G Must be \code{NULL}; exact grade counts are unsupported.
#'
#' @return A sealed \code{postrank_tie_problem}, with a sparse label model,
#'   \code{guard}, \code{M}, \code{objective_units}, and loss/input identities.
#'   The raw objective is \code{sum_ordered(c - tau * delta)}. Risk is
#'   \code{objective_units$offset + raw / M}, where the offset is the
#'   all-withhold risk, not generally tau.
#'
#' @details
#' Smaller grades mean higher priority. A declared direction has criterion
#' loss \code{P(theta_i < theta_j)}; withholding has criterion loss
#' \code{tau * P(theta_i != theta_j)}. Equality costs zero under either action.
#'
#' The mandatory guard intersects the verified equality partitions over
#' positive-weight criteria. Every entity in each resulting full active-profile
#' class receives the same grade. A representative-label equality row enforces
#' each nonsingleton class. No entity or original pair multiplicity is removed.
#' Sample coincidences and equality of posterior means cannot establish a class.
#'
#' For this weighted at-most-G family without extra constraints, a global
#' minimizer satisfying the guard exists: moving every member of an equality
#' class to its least costly currently occupied class grade cannot increase
#' risk or occupied grades. This does not establish corresponding claims for
#' quotas, error budgets, minimax or exact-G decisions, or preserve a downstream
#' funding schedule when occupied grades change.
#'
#' @concept tie-aware
#' @export
postrank_tie_problem <- function(pairwise, weights, tau, G_max,
                                 objective = "weighted", q = NULL, exact_G = NULL) {
  settings <- .pr_tie_loss_settings(pairwise, weights, tau)
  .pr_assert(is.character(objective) && length(objective) == 1L &&
    !is.na(objective) && identical(objective, "weighted") && is.null(q) && is.null(exact_G),
    "tie-aware mode supports weighted at-most-G only; q, minimax and exact_G are unsupported",
    "unsupported_tie_mode_capability")
  .pr_assert(typeof(G_max) %in% c("integer", "double") && is.null(dim(G_max)) && length(G_max) == 1L,
    "G_max must be a scalar positive integer", "invalid_grade_limit")
  .pr_safe_integer(G_max, TRUE, "$.G_max")
  n <- length(pairwise$entity_ids)
  .pr_assert(G_max <= n, "G_max cannot exceed the original entity count", "invalid_grade_limit")
  settings$G_max <- as.integer(G_max)
  settings$objective <- "weighted"
  settings$q <- NULL
  settings$exact_G <- NULL
  guard <- .pr_tie_guard(pairwise, settings$weights)
  coefficients <- .pr_tie_weighted_coefficients(pairwise, settings)
  base <- .pr_encoding_model(pairwise$entity_ids, settings$G_max)
  base$model$objective[base$index$pairs] <- coefficients$centered[
    cbind(base$index$pair_i, base$index$pair_j)]

  representatives <- match(guard$classes, guard$classes)
  members <- which(seq_len(n) != representatives)
  if (length(members)) {
    m <- length(members)
    equalities <- Matrix::sparseMatrix(i = rep(seq_len(m), each = 2L),
      j = as.vector(rbind(base$index$labels[members], base$index$labels[representatives[members]])),
      x = rep(c(1, -1), m), dims = c(m, length(base$model$objective)))
    base$model$A <- methods::as(rbind(base$model$A, equalities), "CsparseMatrix")
    base$model$row_lower <- c(base$model$row_lower, rep(0, m))
    base$model$row_upper <- c(base$model$row_upper, rep(0, m))
    base$model$row_names <- c(base$model$row_names, paste0("tie_profile_equal_", members))
  }
  problem <- list(schema_version = "tie-problem-0.1.0", loss = "tie_aware_v1",
    input_identity = pairwise$input_identity, pairwise = pairwise, settings = settings,
    guard = guard, model = base$model, index = base$index, pair_map = base$pair_map,
    M = choose(n, 2), objective_units = list(raw = "tie_weighted_Z", scale = 1 / choose(n, 2),
      offset = coefficients$baseline), builder_version = "tie-aware-0.1.0")
  class(problem) <- c("postrank_tie_problem", "list")
  problem$problem_identity <- .pr_tie_identity(problem, "postrank_tie_problem:0.1.0")
  .pr_validate_tie_problem(problem)
  problem
}
