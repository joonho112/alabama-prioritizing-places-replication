# Accessors (Chapter 11): defined for postrank_fit and postrank_analysis (get_grades also
# for postrank_baseline). Without a validated incumbent, grades and relations are NULL,
# the profile and grade table are zero-row data frames with their normal columns, and
# get_risk() keeps the status and bound fields. No accessor manufactures an all-tie grade.

#' Extract the Canonical Grade Vector
#'
#' @param x A `postrank_fit`, `postrank_analysis` or `postrank_baseline`.
#' @param ... Unused.
#' @return A named integer vector (1 = highest priority), or `NULL` when the
#'   fit has no validated incumbent.
#' @seealso [get_relations()], [get_profile()], [get_risk()]
#' @concept reporting
#' @examples
#' if (requireNamespace("highs", quietly = TRUE)) {
#'   fit <- postrank(postrank_toy, weights = c(need_A = .6, need_B = .4), tau = .25,
#'     G_max = 3L, backend = "highs", fragility = FALSE)
#'   get_grades(fit)
#' }
#' @export
get_grades <- function(x, ...) UseMethod("get_grades")
#' @export
get_grades.postrank_fit <- function(x, ...) if (isTRUE(x$incumbent_validated)) x$grade else NULL
#' @export
get_grades.postrank_analysis <- function(x, ...) get_grades(x$fit)

#' Extract the Pair Relation Matrix
#'
#' Entry `[i, j]` is `1` when entity `i` is disclosed above `j` (a smaller
#' grade), `-1` when below and `0` when the comparison is withheld (same grade).
#'
#' @inheritParams get_grades
#' @return An `n x n` integer matrix in \eqn{\{1, 0, -1\}}, or `NULL` without
#'   a validated incumbent.
#' @seealso [get_grades()]
#' @concept reporting
#' @examples
#' if (requireNamespace("highs", quietly = TRUE)) {
#'   fit <- postrank(postrank_toy, weights = c(need_A = .6, need_B = .4), tau = .25,
#'     G_max = 3L, backend = "highs", fragility = FALSE)
#'   get_relations(fit)
#' }
#' @export
get_relations <- function(x, ...) UseMethod("get_relations")
#' @export
get_relations.postrank_fit <- function(x, ...) if (isTRUE(x$incumbent_validated)) .pr_relations(x$grade) else NULL
#' @export
get_relations.postrank_analysis <- function(x, ...) get_relations(x$fit)

.pr_profile_columns <- c("criterion", "weight", "E", "E_over_M", "E_over_N", "risk", "q", "budget_slack", "is_minimax_max")
.pr_empty_profile <- function() {
  data.frame(criterion = character(), weight = numeric(), E = numeric(), E_over_M = numeric(), E_over_N = numeric(),
    risk = numeric(), q = numeric(), budget_slack = numeric(), is_minimax_max = logical(), stringsAsFactors = FALSE)
}

#' Extract the Per-Criterion Error Profile
#'
#' One row per criterion of the selected grade: its weight, expected error
#' count `E`, `E/M`, `E/N` (`NA` when nothing is disclosed), criterion risk,
#' error budget `q` (`NA` for unprotected criteria), the budget slack
#' \eqn{q_k N - E_k} (non-negative when the budget row holds; `NA` without a
#' budget) and whether the criterion attains the minimax maximum.
#'
#' @inheritParams get_grades
#' @return A data frame with columns `criterion`, `weight`, `E`, `E_over_M`,
#'   `E_over_N`, `risk`, `q`, `budget_slack`, `is_minimax_max`; zero rows
#'   without a validated incumbent.
#' @seealso [get_risk()]
#' @concept reporting
#' @examples
#' if (requireNamespace("highs", quietly = TRUE)) {
#'   fit <- postrank(postrank_toy, weights = c(need_A = .6, need_B = .4), tau = .25,
#'     G_max = 3L, backend = "highs", fragility = FALSE)
#'   get_profile(fit)
#' }
#' @export
get_profile <- function(x, ...) UseMethod("get_profile")
#' @export
get_profile.postrank_fit <- function(x, ...) {
  ev <- if (isTRUE(x$incumbent_validated)) x$evaluation else NULL
  if (is.null(ev)) return(.pr_empty_profile())
  s <- x$problem$settings; ks <- x$problem$pairwise$criterion_ids
  q <- stats::setNames(rep(NA_real_, length(ks)), ks); if (!is.null(s$q)) q[names(s$q)] <- s$q
  sel <- if (identical(s$objective, "minimax")) s$minimax_criteria else ks
  risk <- unname(ev$criterion_risk[ks])
  is_max <- identical(s$objective, "minimax") & ks %in% sel & abs(risk - max(ev$criterion_risk[sel])) <= 1e-12
  data.frame(criterion = ks, weight = unname(s$weights[ks]), E = unname(ev$E[ks]), E_over_M = unname(ev$E_over_M[ks]),
    E_over_N = unname(ev$E_over_N[ks]), risk = risk, q = unname(q), budget_slack = unname(q * ev$N - ev$E[ks]),
    is_minimax_max = is_max, stringsAsFactors = FALSE)
}
#' @export
get_profile.postrank_analysis <- function(x, ...) get_profile(x$fit)

#' Extract Risk, Lower Bound, Gap and Status
#'
#' The primary risk of the validated action, the solver's numerical lower
#' bound and their absolute gap, with the normalized solver status. The bound
#' is a numerical solver bound, not a certificate; a gap is not posterior
#' regret.
#'
#' @inheritParams get_grades
#' @return A named list: `risk`, `lower_bound`, `gap` (numeric, `NA` when
#'   unavailable) and `status` (character).
#' @seealso [get_profile()]
#' @concept reporting
#' @examples
#' if (requireNamespace("highs", quietly = TRUE)) {
#'   fit <- postrank(postrank_toy, weights = c(need_A = .6, need_B = .4), tau = .25,
#'     G_max = 3L, backend = "highs", fragility = FALSE)
#'   get_risk(fit)
#' }
#' @export
get_risk <- function(x, ...) UseMethod("get_risk")
#' @export
get_risk.postrank_fit <- function(x, ...) {
  num <- function(v) if (is.null(v) || !length(v)) NA_real_ else as.numeric(v)[1L]
  ok <- isTRUE(x$incumbent_validated)
  list(risk = if (ok) num(x$objective$primary_action_risk) else NA_real_, lower_bound = num(x$objective$risk_lower_bound),
    gap = if (ok) num(x$objective$risk_absolute_gap) else NA_real_, status = as.character(x$status$normalized))
}
#' @export
get_risk.postrank_analysis <- function(x, ...) get_risk(x$fit)

#' @export
as.data.frame.postrank_fit <- function(x, row.names = NULL, optional = FALSE, ...) {
  g <- get_grades(x)
  if (is.null(g)) return(data.frame(entity_id = character(), grade = integer(), stringsAsFactors = FALSE))
  data.frame(entity_id = names(g), grade = unname(g), stringsAsFactors = FALSE)
}
#' @export
as.data.frame.postrank_analysis <- function(x, row.names = NULL, optional = FALSE, ...)
  if (!is.null(x$report_card)) x$report_card$data else as.data.frame(x$fit)
#' @export
as.data.frame.postrank_report_card <- function(x, row.names = NULL, optional = FALSE, ...) x$data
