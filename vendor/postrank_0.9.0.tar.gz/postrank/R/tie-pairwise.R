.pr_tie_empty_probability <- function(ids, ks) array(NA_real_, c(length(ids), length(ids), length(ks)),
  dimnames = list(entity_i = ids, entity_j = ids, criterion = ks))

.pr_tie_pairwise_one <- function(values, block_size) {
  n <- ncol(values)
  b <- tprob <- d <- matrix(NA_real_, n, n)
  total <- as.double(n) * (n - 1L); first <- 1
  while (first <= total) {
    last <- min(total, first + block_size - 1); pair <- seq.int(first, last) - 1
    i <- pair %/% (n - 1L) + 1; j <- pair %% (n - 1L) + 1; j <- j + (j >= i)
    left <- values[, i, drop = FALSE]; right <- values[, j, drop = FALSE]
    b[cbind(i, j)] <- colMeans(left < right)
    tprob[cbind(i, j)] <- colMeans(left == right)
    d[cbind(i, j)] <- colMeans(left != right)
    first <- last + 1
  }
  list(b = b, t = tprob, d = d)
}

.pr_tie_pairwise_exact <- function(source) {
  ids <- source$entity_ids; ks <- source$criterion_ids
  out <- lapply(c("b", "t", "d"), function(z) .pr_tie_empty_probability(ids, ks)); names(out) <- c("b", "t", "d")
  chars <- array(NA_character_, dim(out$b), dimnames(out$b))
  numerators <- rationals <- differences <- lapply(out, function(z) chars)
  law <- source$finite_law; denominator <- .pr_big_integer(law$denominator)
  maximum <- gmp::as.bigq(0)
  for (k in seq_along(ks)) for (i in seq_along(ids)) for (j in seq_along(ids)) if (i != j) {
    counts <- lapply(out, function(z) gmp::as.bigz(0))
    for (state in law$states) {
      a <- state$theta[i, k]; z <- state$theta[j, k]; mass <- .pr_big_integer(state$mass_numerator)
      if (a < z) counts$b <- counts$b + mass
      if (a == z) counts$t <- counts$t + mass
      if (a != z) counts$d <- counts$d + mass
    }
    for (name in names(out)) {
      p <- gmp::as.bigq(counts[[name]], denominator); value <- as.numeric(p)
      difference <- gmp::as.bigq(value) - p
      out[[name]][i, j, k] <- value
      numerators[[name]][i, j, k] <- as.character(counts[[name]])
      rationals[[name]][i, j, k] <- as.character(p)
      differences[[name]][i, j, k] <- as.character(difference)
      if (abs(difference) > maximum) maximum <- abs(difference)
    }
  }
  out$exact <- list(numerators = numerators, denominator = as.character(denominator),
    rationals = rationals, projection_difference_rationals = differences,
    maximum_absolute_projection_difference_rational = as.character(maximum),
    state_count = length(law$states), arithmetic = "gmp arbitrary-precision integer masses and rational probabilities",
    projection_note = "b, t and d are double projections; exact coefficient arithmetic does not certify downstream floating risk or solver calculations.",
    numerical_certification = FALSE, law_definition = law$law_definition,
    nonempirical_declaration = law$not_empirical_posterior_relabeling)
  out
}

.pr_tie_pairwise_content <- function(x) {
  x <- unclass(x); x$pairwise_identity <- NULL; x
}

#' Compute Equality-Neutral Strict and Tie Probabilities
#'
#' Aggregates complete joint states from [as_postrank_tie_draws()] without
#' reordering entities, dropping providers or altering precision. For distinct
#' entities, `b[i,j,k] = P(theta[i,k] < theta[j,k])`, `t` is equality probability,
#' and `d` is inequality probability. All diagonals are `NA` sentinels. Equality
#' and inequality coefficients are symmetric, and `b[i,j,k] + b[j,i,k] = d[i,j,k]`.
#' Strict directions complement each other only when the tie probability is zero.
#'
#' `method = "reference"` evaluates one direction at a time; `"blocks"` bounds
#' working indicator storage by the selected pair block size. Exact finite laws
#' use integer masses and rational arithmetic with explicit double-projection
#' diagnostics. Their probabilities are not estimated from fabricated draws.
#'
#' Equality classes remain source declarations for Monte Carlo inputs and are
#' derived over every positive-mass state for exact laws. The problem builder
#' intersects the classes of positive-weight criteria to form its active-profile
#' guard. This producer has no policy weights and never infers structural classes
#' from Monte Carlo coincidences. Its source, loss domain and all coefficients
#' are sealed independently of legacy pairwise artifacts. Legacy consumers and
#' unsupported diagnostic/guarantee capabilities do not become available.
#'
#' @param draws A new tie-aware canonical payload or `postrank_tie_draws`.
#' @param method Equal-weight aggregation algorithm, `"blocks"` or `"reference"`.
#' @param block_size Positive safe integer maximum number of directions per block.
#' @return A distinct `postrank_tie_pairwise` with `b`, `t`, `d`, validated
#'   `source`, equality evidence, source and pairwise identities, source-specific
#'   sample sizes/regimes, and `loss = "tie_aware_v1"`.
#' @seealso [validate_postrank_tie_pairwise()]
#' @concept tie-aware
#' @export
postrank_tie_pairwise <- function(draws, method = c("blocks", "reference"), block_size = 128L) {
  method <- match.arg(method)
  .pr_assert(is.numeric(block_size) && is.null(dim(block_size)) && length(block_size) == 1L,
    "block_size must be a positive scalar integer", "invalid_block_size")
  .pr_safe_integer(block_size, TRUE, "$.block_size")
  source <- as_postrank_tie_draws(draws); ids <- source$entity_ids; ks <- source$criterion_ids
  exact <- identical(source$input_kind, "exact_finite_posterior")
  if (exact) {
    probabilities <- .pr_tie_pairwise_exact(source)
    sizes <- rep(NA_real_, length(ks)); regimes <- rep("exact_law", length(ks))
  } else {
    matrices <- .pr_tie_source_matrices(source)
    probabilities <- lapply(c("b", "t", "d"), function(z) .pr_tie_empty_probability(ids, ks))
    names(probabilities) <- c("b", "t", "d")
    for (k in seq_along(ks)) {
      one <- .pr_tie_pairwise_one(matrices[[k]], if (method == "reference") 1 else block_size)
      for (name in names(one)) probabilities[[name]][, , k] <- one[[name]]
    }
    probabilities$exact <- NULL
    sizes <- rep(dim(source$joint_draws$tensor$values)[1L], length(ks))
    regimes <- rep(source$joint_draws$sampling$regime, length(ks))
  }
  evidence <- list(partition_source = if (exact) "all_positive_mass_states" else "structural_declaration",
    within_class_values_checked = TRUE, monte_carlo_coincidences_used_to_merge_classes = FALSE,
    scientific_equality_verified = FALSE)
  equality <- c(source$equality, list(evidence = evidence))
  out <- list(schema_version = "tie-pairwise-0.1", loss = "tie_aware_v1", entity_ids = ids,
    criterion_ids = ks, b = probabilities$b, t = probabilities$t, d = probabilities$d,
    sample_sizes = stats::setNames(as.numeric(sizes), ks), sampling_regimes = stats::setNames(regimes, ks),
    input_kind = source$input_kind, dependence_mode = source$dependence_mode, equality = equality,
    input_identity = source$input_identity, source = source,
    method = if (exact) "exact_finite_law" else method, exact = probabilities$exact,
    coefficient_type = if (exact) "exact_rational_with_double_projection" else "monte_carlo",
    validation = source$validation)
  out$pairwise_identity <- .pr_tie_identity(out, "postrank-tie-pairwise-v1")
  class(out) <- c("postrank_tie_pairwise", "list")
  validate_postrank_tie_pairwise(out); out
}

#' Validate Equality-Neutral Pairwise Coefficients
#'
#' Checks named axes, diagonal sentinels, categorical probability identities,
#' source association, equality evidence and the own-domain content seal. This
#' does not promote declared posterior provenance or floating arithmetic to a
#' scientific or numerical certificate. Mutations require a fresh aggregation
#' from the original source; the validator never repairs or reseals an object.
#'
#' @param x A `postrank_tie_pairwise` from [postrank_tie_pairwise()].
#' @return Invisible `TRUE`; invalid or stale content raises a structured error.
#' @concept tie-aware
#' @export
validate_postrank_tie_pairwise <- function(x) {
  fields <- c("schema_version", "loss", "entity_ids", "criterion_ids", "b", "t", "d", "sample_sizes",
    "sampling_regimes", "input_kind", "dependence_mode", "equality", "input_identity", "source", "method",
    "exact", "coefficient_type", "validation", "pairwise_identity")
  .pr_assert(identical(class(x), c("postrank_tie_pairwise", "list")),
    "expected separate postrank_tie_pairwise class", "invalid_tie_pairwise")
  .pr_fields(x, fields)
  .pr_assert(identical(x$schema_version, "tie-pairwise-0.1") && identical(x$loss, "tie_aware_v1"),
    "unsupported tie-aware coefficient domain", "unsupported_version")
  validate_postrank_tie_draws(x$source)
  for (field in c("entity_ids", "criterion_ids", "input_identity", "input_kind", "dependence_mode", "validation"))
    .pr_assert(identical(x[[field]], x$source[[field]]), "pairwise source association differs", "invalid_tie_pairwise")
  .pr_assert(identical(x$equality[c("basis", "justification", "criterion_classes")], x$source$equality),
    "pairwise equality partition differs from source", "invalid_equality_partition")
  exact <- identical(x$input_kind, "exact_finite_posterior")
  evidence <- list(partition_source = if (exact) "all_positive_mass_states" else "structural_declaration",
    within_class_values_checked = TRUE, monte_carlo_coincidences_used_to_merge_classes = FALSE,
    scientific_equality_verified = FALSE)
  .pr_assert(identical(x$equality, c(x$source$equality, list(evidence = evidence))),
    "pairwise equality evidence differs from the supported source checks", "invalid_tie_pairwise")
  .pr_assert(identical(x$coefficient_type, if (exact) "exact_rational_with_double_projection" else "monte_carlo"),
    "coefficient type differs from source", "invalid_tie_pairwise")
  n <- length(x$entity_ids); K <- length(x$criterion_ids)
  axes <- list(entity_i = x$entity_ids, entity_j = x$entity_ids, criterion = x$criterion_ids)
  for (name in c("b", "t", "d")) {
    a <- x[[name]]
    .pr_assert(is.numeric(a) && identical(dim(a), c(n, n, K)) && identical(dimnames(a), axes),
      "tie coefficient axes differ from declared IDs", "invalid_tie_pairwise")
    for (k in seq_len(K)) {
      m <- matrix(a[, , k], n, n); off <- row(m) != col(m)
      .pr_assert(all(is.na(diag(m))) && !any(is.nan(diag(m))) && all(is.finite(m[off])) &&
        all(m[off] >= 0 & m[off] <= 1), "invalid probabilities or diagonal sentinel", "invalid_tie_pairwise")
    }
  }
  for (k in seq_len(K)) {
    b <- matrix(x$b[, , k], n, n); tprob <- matrix(x$t[, , k], n, n); d <- matrix(x$d[, , k], n, n)
    off <- row(b) != col(b)
    .pr_assert(all(abs((tprob - t(tprob))[off]) <= 1e-12) && all(abs((d - t(d))[off]) <= 1e-12) &&
      all(abs((b + t(b) - d)[off]) <= 1e-12) && all(abs((d + tprob - 1)[off]) <= 1e-12),
      "strict/equality/discordance probability identities disagree", "invalid_tie_pairwise")
  }
  sizes <- if (exact) rep(NA_real_, K) else rep(as.numeric(dim(x$source$joint_draws$tensor$values)[1L]), K)
  regimes <- if (exact) rep("exact_law", K) else rep(x$source$joint_draws$sampling$regime, K)
  .pr_assert(identical(x$sample_sizes, stats::setNames(sizes, x$criterion_ids)) &&
    identical(x$sampling_regimes, stats::setNames(regimes, x$criterion_ids)),
    "sample sizes/regimes disagree with source", "invalid_tie_pairwise")
  .pr_assert(if (exact) identical(x$method, "exact_finite_law") && is.list(x$exact) else
    x$method %in% c("blocks", "reference") && is.null(x$exact), "method disagrees with input kind", "invalid_tie_pairwise")
  .pr_assert(is.character(x$pairwise_identity) && length(x$pairwise_identity) == 1L &&
    identical(x$pairwise_identity, .pr_tie_identity(.pr_tie_pairwise_content(x), "postrank-tie-pairwise-v1")),
    "tie-aware pairwise object changed after aggregation", "stale_tie_pairwise_identity")
  invisible(TRUE)
}
