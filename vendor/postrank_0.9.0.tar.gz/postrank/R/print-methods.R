# Result-first English console (Chapter 13, PR-DEC-13-A). For every print-bearing class:
# format_postrank_<class>_cli() builds the lines, format.<class>() returns them and
# print.<class>() writes them and returns the object invisibly. summary.<class>() returns
# a typed postrank_<class>_summary. All are pure views over stored slots.

#' Format a postrank Object for the Console
#'
#' The exported formatters behind every `print()` and `format()` method of
#' postrank. Each returns a character vector with one element per console
#' line, has no side effect and recomputes nothing: it reads stored slots
#' only. The first line is the result (for a grading object: the number of
#' entities and grade sizes), the next lines carry risk, disclosure and
#' status, followed by an optional body, one pointer line (`i`) and at most
#' one warning line (`!`) that counts the stored warnings. All authored text
#' is English; entity identifiers and stored warning text are kept verbatim.
#'
#' Three tiers differ only in ANSI styling: tier 1 (interactive color
#' terminal), tier 2 (plain text: logs, checks, captures) and tier 3
#' (knitting). `tier = NULL` detects the tier once per call; removing the ANSI
#' styling of tier 1 gives tier 2 byte for byte.
#'
#' Prefer `format(x, width = 72, tier = 2)` in code that handles several
#' postrank classes. Each class-specific formatter produces the same lines as
#' the corresponding `format()` method with the same arguments; none is
#' deprecated in this release.
#' This text is for display, not a machine-readable data format: use accessors
#' or structured result slots for calculations. With `width = NULL` the line
#' width follows the session; to write plain text that does not depend on the
#' session, fix both arguments: `cat(format(x, width = 72, tier = 2), sep = "\n")`.
#'
#' Shared bodies: `format_postrank_validation_cli()` serves `postrank_validation`
#' and `postrank_solution_validation`; `format_postrank_guarantee_cli()` serves
#' the four appendix-tier classes; `format_postrank_summary_cli()` serves every
#' `summary()` result.
#'
#' @param x The object to format; a formatter called with the wrong class
#'   stops with code `wrong_class`.
#' @param ... Unused.
#' @param width Line width; `NULL` uses `getOption("width")`, floored at 40.
#' @param tier `NULL` (detect), `1`, `2` or `3`.
#' @param n_head Maximum number of table rows shown by table-bodied classes.
#' @return A character vector, one element per line.
#' @name format_postrank_cli
#' @concept reporting
#' @examples
#' lines <- format(postrank_toy, width = 72, tier = 2)
#' cat(lines, sep = "\n")
#' identical(lines, format_postrank_draws_cli(postrank_toy, width = 72, tier = 2))
#' format(postrank_settings(c(need_A = .6, need_B = .4)), tier = 2)
NULL

.pr_fmt_fit_lines <- function(fit, width, requested_gap = NULL, cls = "postrank_fit", extra = character(), pointer = NULL,
                              warnings = fit$warnings) {
  ok <- isTRUE(fit$incumbent_validated) && !is.null(fit$grade)
  st <- fit$status$normalized; obj <- fit$objective; ev <- fit$evaluation
  gap_txt <- if (identical(obj$bound_source, "missing") || is.na(obj$risk_absolute_gap %||% NA)) "gap NA (no bound)" else
    paste0("gap ", .pr_fmt(obj$risk_absolute_gap, "gap"), if (!is.null(requested_gap)) paste0(" (requested <= ", .pr_fmt(requested_gap, "gap"), ")") else "")
  backend <- paste0("backend ", fit$backend$name %||% "NA", " (", fit$engine$strategy %||% "NA", ")")
  if (!ok) {
    lb <- obj$risk_lower_bound
    lines <- c(.pr_cli_header(cls, "no validated incumbent, no grades"),
      .pr_cli_line("status ", st, "   lower bound ", if (is.null(lb) || is.na(lb)) "NA (no bound)" else .pr_fmt(lb, "risk"),
        "   ", backend),
      .pr_cli_line("termination: ", fit$status$termination_reason %||% "NA",
        if (!is.null(obj$bound_source)) paste0("; bound source ", obj$bound_source) else ""), extra,
      .pr_cli_warning_line(warnings, width),
      .pr_cli_pointer(pointer %||% "inspect x$status$termination_reason and the computation settings."))
    return(lines)
  }
  n <- length(fit$grade); G <- ev$G
  head <- if (G == 1L) sprintf("%d entities in 1 grade; all comparisons withheld", n) else
    sprintf("%d entities in %d grades (%s)", n, G, .pr_grade_sizes(fit$grade))
  minimax <- identical(fit$problem$settings$objective, "minimax")
  risk <- if (minimax) paste0("max criterion risk ", .pr_fmt(obj$primary_action_risk, "risk"), " (weighted ",
    .pr_fmt(obj$weighted_auxiliary_risk, "risk"), ")") else paste0("risk ", .pr_fmt(obj$primary_action_risk, "risk"))
  if (!identical(st, "optimal")) risk <- paste0(risk, " (validated incumbent; an upper bound)")
  disc <- sprintf("disclosed %s/%s pairs (%s)", .pr_fmt(ev$N, "count"), .pr_fmt(ev$M, "count"), .pr_fmt(ev$disclosure_rate, "pct"))
  err <- if (ev$N == 0) "error per disclosed pair: NA (N = 0)" else
    paste0("error per disclosed pair: ", paste(names(ev$E_over_N), .pr_fmt(ev$E_over_N, "ratio"), collapse = ", "))
  c(.pr_cli_header(cls, head), .pr_cli_line(risk, "   ", disc),
    .pr_cli_line("status ", st, "   ", gap_txt, "   ", backend),
    if (minimax && !is.null(fit$minimax_refine)) .pr_cli_line("minimax second stage: ", fit$minimax_refine$mode %||% "none") else character(),
    .pr_cli_line(err), extra,
    if (G == 1L) .pr_cli_line("all-tie is an admissible action with risk tau; it is not an error-free ranking") else character(),
    .pr_members(fit$grade, fit$problem$pairwise$entity_ids, width),
    .pr_cli_warning_line(warnings, width),
    .pr_cli_pointer(pointer %||% "get_grades(x), get_profile(x) and summary(x); one validated incumbent, the number of optima is unknown."))
}

#' @rdname format_postrank_cli
#' @export
format_postrank_fit_cli <- function(x, ..., width = NULL, tier = NULL, n_head = 10L) {
  .pr_cli_assert_class(x, "postrank_fit", "format_postrank_fit_cli")
  width <- .pr_cli_width(width); tier <- .pr_cli_tier(tier)
  .pr_cli_finish(.pr_fmt_fit_lines(x, width), width, tier)
}

#' @rdname format_postrank_cli
#' @export
format_postrank_analysis_cli <- function(x, ..., width = NULL, tier = NULL, n_head = 10L) {
  .pr_cli_assert_class(x, "postrank_analysis", "format_postrank_analysis_cli")
  width <- .pr_cli_width(width); tier <- .pr_cli_tier(tier)
  ex <- vapply(names(x$extras), function(e) {
    r <- x$extras[[e]]; paste0(e, " ", if (r$available) "available" else gsub("_", " ", r$reason))
  }, "")
  lines <- .pr_fmt_fit_lines(x$fit, width, requested_gap = x$control$absolute_risk_gap, cls = "postrank_analysis",
    extra = .pr_cli_line("extras: ", paste(ex, collapse = "; ")),
    pointer = "summary(x) shows declarations, provenance and timings; get_grades(x), get_profile(x).", warnings = x$warnings)
  .pr_cli_finish(lines, width, tier)
}

#' @rdname format_postrank_cli
#' @export
format_postrank_draws_cli <- function(x, ..., width = NULL, tier = NULL, n_head = 10L) {
  .pr_cli_assert_class(x, "postrank_draws", "format_postrank_draws_cli")
  width <- .pr_cli_width(width); tier <- .pr_cli_tier(tier)
  n <- length(x$entity_ids); K <- length(x$criterion_ids)
  what <- if (identical(x$input_kind, "exact_finite_posterior")) sprintf("%d-state exact finite law", length(x$finite_law$states)) else
    if (identical(x$dependence_mode, "joint_model")) sprintf("%d retained %s states", dim(x$joint_draws$tensor$values)[1L],
      toupper(x$joint_draws$sampling$regime)) else
    paste0("criterionwise draws (S_k ", paste(vapply(x$criterion_blocks, function(b) b$matrix$shape$S, 1), collapse = "/"), ")")
  lines <- c(.pr_cli_header("postrank_draws", sprintf("%d entities x %d criteria; %s", n, K, what)),
    .pr_cli_line("structurally valid: ", tolower(as.character(isTRUE(x$validation$valid))),
      "; required declarations present; jointness/convergence not verified"),
    .pr_cli_pointer("summary(x) shows the source declarations and sampling history."))
  .pr_cli_finish(lines, width, tier)
}

#' @rdname format_postrank_cli
#' @export
format_postrank_validation_cli <- function(x, ..., width = NULL, tier = NULL, n_head = 10L) {
  .pr_cli_assert_class(x, c("postrank_validation", "postrank_solution_validation"), "format_postrank_validation_cli")
  width <- .pr_cli_width(width); tier <- .pr_cli_tier(tier)
  cls <- if (inherits(x, "postrank_solution_validation")) "postrank_solution_validation" else "postrank_validation"
  issues <- length(x$issues)
  extra <- if (inherits(x, "postrank_solution_validation")) {
    r <- x$raw_residuals; mx <- if (is.list(r) || is.numeric(r)) suppressWarnings(max(abs(unlist(r)), na.rm = TRUE)) else NA
    paste0("max raw residual ", .pr_fmt(if (is.finite(mx)) mx else NA, "gap"))
  } else paste0(length(x$check_results %||% list()), " check results")
  lines <- c(.pr_cli_header(cls, paste0(if (isTRUE(x$valid)) "valid" else "not valid", "; ", issues, " issue", if (issues != 1L) "s" else "", "; ", extra)),
    .pr_cli_pointer("unclass(x) shows the full receipt; validity is structural, not scientific verification."))
  .pr_cli_finish(lines, width, tier)
}

#' @rdname format_postrank_cli
#' @export
format_postrank_pairwise_cli <- function(x, ..., width = NULL, tier = NULL, n_head = 10L) {
  .pr_cli_assert_class(x, "postrank_pairwise", "format_postrank_pairwise_cli")
  width <- .pr_cli_width(width); tier <- .pr_cli_tier(tier)
  d <- dim(x$e)
  lines <- c(.pr_cli_header("postrank_pairwise", sprintf("%d x %d x %d directional-error coefficients", d[1], d[2], d[3])),
    .pr_cli_line("diagonal NA; input ", x$input_kind %||% "NA", "; method ", x$method %||% "NA",
      if (!is.null(x$exact)) "; exact rational coefficients kept" else ""),
    .pr_cli_pointer("inspect x$e or summary(x); pairwise plotting is not shipped in 0.9.0."))
  .pr_cli_finish(lines, width, tier)
}

#' @rdname format_postrank_cli
#' @export
format_postrank_coefficients_cli <- function(x, ..., width = NULL, tier = NULL, n_head = 10L) {
  .pr_cli_assert_class(x, "postrank_coefficients", "format_postrank_coefficients_cli")
  width <- .pr_cli_width(width); tier <- .pr_cli_tier(tier)
  d <- dim(x$e)
  lines <- c(.pr_cli_header("postrank_coefficients", sprintf("%d x %d x %d; %s", d[1], d[2], d[3], x$input_kind)),
    .pr_cli_line("weighted at-most-G scope; analytic source summaries available"),
    .pr_cli_pointer("summary(x) records the declared conditional law and capabilities."))
  .pr_cli_finish(lines, width, tier)
}

#' @rdname format_postrank_cli
#' @export
format_postrank_coefficient_diagnostics_cli <- function(x, ..., width = NULL, tier = NULL, n_head = 10L) {
  .pr_cli_assert_class(x, "postrank_coefficient_diagnostics", "format_postrank_coefficient_diagnostics_cli")
  width <- .pr_cli_width(width); tier <- .pr_cli_tier(tier)
  m <- x$diagnostics$mcse_mean
  mcse <- if (isTRUE(m$available)) paste0("MCSE ", .pr_fmt(m$value, "gap")) else paste0("MCSE NA (", m$unavailable_reason %||% x$unavailable_reason %||% "unavailable", ")")
  lines <- c(.pr_cli_header("postrank_coefficient_diagnostics", paste0("weighted risk ", .pr_fmt(x$evaluation$weighted_risk, "risk"),
    "; conditional expected-risk diagnostics")),
    .pr_cli_line(mcse, "; target draws, convergence and certificates are not claimed"),
    .pr_cli_warning_line(x$warnings, width),
    .pr_cli_pointer("summary(x) lists the reasons for unavailable items."))
  .pr_cli_finish(lines, width, tier)
}

#' @rdname format_postrank_cli
#' @export
format_postrank_declarations_cli <- function(x, ..., width = NULL, tier = NULL, n_head = 10L) {
  .pr_cli_assert_class(x, "postrank_declarations", "format_postrank_declarations_cli")
  width <- .pr_cli_width(width); tier <- .pr_cli_tier(tier)
  .pr_cli_finish(.pr_cli_header("postrank_declarations", "8 required declarations present; not independently verified"), width, tier)
}

#' @rdname format_postrank_cli
#' @export
format_postrank_settings_cli <- function(x, ..., width = NULL, tier = NULL, n_head = 10L) {
  .pr_cli_assert_class(x, "postrank_settings", "format_postrank_settings_cli")
  width <- .pr_cli_width(width); tier <- .pr_cli_tier(tier)
  w <- if (is.null(names(x$weights))) paste(.pr_fmt(x$weights, "num"), collapse = ", ") else
    paste(names(x$weights), .pr_fmt(x$weights, "num"), collapse = ", ")
  lines <- c(.pr_cli_header("postrank_settings", paste0(x$objective, "; tau ", .pr_fmt(x$tau, "num"), "; ",
    if (is.null(x$exact_G)) paste0("G_max ", x$G_max) else paste0("exact G ", x$exact_G, " (G_max ", x$G_max, ")"))),
    .pr_cli_line("weights ", w),
    .pr_cli_line("q ", if (is.null(x$q)) "none" else paste(names(x$q), .pr_fmt(x$q, "num"), collapse = ", "),
      if (identical(x$objective, "minimax")) paste0("; minimax refine ", x$minimax_refine) else ""),
    .pr_cli_pointer("pass to postrank(settings = ) or postrank_problem(settings = )."))
  .pr_cli_finish(lines, width, tier)
}

#' @rdname format_postrank_cli
#' @export
format_postrank_control_cli <- function(x, ..., width = NULL, tier = NULL, n_head = 10L) {
  .pr_cli_assert_class(x, "postrank_control", "format_postrank_control_cli")
  width <- .pr_cli_width(width); tier <- .pr_cli_tier(tier)
  lines <- c(.pr_cli_header("postrank_control", paste0("time limit ", .pr_fmt(x$time_limit, "num"), " s; ", x$threads,
    " thread", if (x$threads != 1L) "s" else "", "; strategy ", x$strategy)),
    .pr_cli_line("absolute risk gap ", .pr_fmt(x$absolute_risk_gap, "gap"), "; relative gap ", .pr_fmt(x$relative_gap, "gap"),
      "; seed ", x$seed),
    .pr_cli_pointer("summary(x) shows the staged-engine options and tolerances."))
  .pr_cli_finish(lines, width, tier)
}

#' @rdname format_postrank_cli
#' @export
format_postrank_problem_cli <- function(x, ..., width = NULL, tier = NULL, n_head = 10L) {
  .pr_cli_assert_class(x, "postrank_problem", "format_postrank_problem_cli")
  width <- .pr_cli_width(width); tier <- .pr_cli_tier(tier)
  s <- x$settings
  lines <- c(.pr_cli_header("postrank_problem", sprintf("%d entities, %d criteria, %s pairs; not solved",
    length(x$pairwise$entity_ids), length(x$pairwise$criterion_ids), .pr_fmt(x$M, "count"))),
    .pr_cli_line(s$objective, "; tau ", .pr_fmt(s$tau, "num"), "; G_max ", s$G_max,
      if (!is.null(s$exact_G)) paste0("; exact G ", s$exact_G) else "", if (!is.null(s$q)) "; error budgets q" else ""),
    .pr_cli_pointer("postrank_solve(x) solves it; backend NULL resolves to the option, then Gurobi."))
  .pr_cli_finish(lines, width, tier)
}

#' @rdname format_postrank_cli
#' @export
format_postrank_report_card_cli <- function(x, ..., width = NULL, tier = NULL, n_head = 10L) {
  .pr_cli_assert_class(x, "postrank_report_card", "format_postrank_report_card_cli")
  width <- .pr_cli_width(width); tier <- .pr_cli_tier(tier); n_head <- .pr_cli_n_head(n_head)
  d <- x$data; n <- nrow(d); ks <- names(x$settings$weights)
  head <- if (max(d$grade) == 1L) sprintf("%d entities in 1 grade; all comparisons withheld", n) else
    sprintf("%d entities in %d grades (%s)", n, max(d$grade), paste(tabulate(d$grade), collapse = " / "))
  tab <- d[seq_len(min(n, n_head)), c("grade", "entity_id", "n_above", "n_below", "n_withheld"), drop = FALSE]
  names(tab) <- c("grade", "entity_id", "above", "below", "withheld")
  show_means <- 32L + 10L * length(ks) <= width
  if (show_means) for (k in ks) tab[[k]] <- .pr_fmt(d[[paste0("mean_", k)]][seq_len(nrow(tab))], "num")
  body <- paste0("  ", utils::capture.output(print(tab, row.names = FALSE, right = FALSE)))
  lines <- c(.pr_cli_header("postrank_report_card", head),
    .pr_cli_line("posterior means; ", .pr_fmt(x$level, "pct"), " central intervals (", x$interval_source, ") in x$data"),
    body, if (n > n_head) .pr_cli_line(sprintf("Showing %d of %d entities; full table in x$data.", n_head, n)) else character(),
    .pr_cli_pointer("as.data.frame(x) returns the full table."))
  .pr_cli_finish(lines, width, tier)
}

.pr_table_lines <- function(df, n_head, width) {
  shown <- df[seq_len(min(nrow(df), n_head)), , drop = FALSE]
  for (nm in names(shown)) if (is.double(shown[[nm]])) shown[[nm]] <- .pr_fmt(shown[[nm]], "num")
  out <- paste0("  ", utils::capture.output(print(shown, row.names = FALSE, right = FALSE)))
  if (nrow(df) > n_head) out <- c(out, .pr_cli_line(sprintf("Showing %d of %d rows.", n_head, nrow(df))))
  out
}

#' @rdname format_postrank_cli
#' @export
format_postrank_baseline_cli <- function(x, ..., width = NULL, tier = NULL, n_head = 10L) {
  .pr_cli_assert_class(x, "postrank_baseline", "format_postrank_baseline_cli")
  width <- .pr_cli_width(width); tier <- .pr_cli_tier(tier)
  ev <- x$evaluation; G <- ev$G
  lines <- c(.pr_cli_header("postrank_baseline", paste0(x$method, " + ", x$cut_rule, " cuts: ", length(x$grade), " entities in ",
    G, if (G == 1L) " grade" else paste0(" grades (", .pr_grade_sizes(x$grade), ")"))),
    .pr_cli_line("risk ", .pr_fmt(x$risk, "risk"), "   disclosed ", .pr_fmt(ev$N, "count"), "/", .pr_fmt(ev$M, "count"),
      " pairs (", .pr_fmt(ev$disclosure_rate, "pct"), ")"),
    .pr_cli_line("optimality scope: ", x$optimality_scope),
    .pr_cli_warning_line(x$warnings, width),
    .pr_cli_pointer("get_grades(x); postrank_compare() puts it next to the joint rule."))
  .pr_cli_finish(lines, width, tier)
}

#' @rdname format_postrank_cli
#' @export
format_postrank_comparison_cli <- function(x, ..., width = NULL, tier = NULL, n_head = 10L) {
  .pr_cli_assert_class(x, "postrank_comparison", "format_postrank_comparison_cli")
  width <- .pr_cli_width(width); tier <- .pr_cli_tier(tier); n_head <- .pr_cli_n_head(n_head)
  t <- x$table[, c("method", "risk", "disclosure_rate", "G", "status"), drop = FALSE]
  t$risk <- .pr_fmt(t$risk, "risk"); t$disclosure_rate <- .pr_fmt(t$disclosure_rate, "pct"); names(t)[3] <- "N/M"
  ag <- x$relations
  family_recorded <- all(c("family_feasible", "feasibility_reason") %in% names(x$table))
  outside <- if (family_recorded) x$table[x$table$family_feasible %in% FALSE, , drop = FALSE] else x$table[FALSE, , drop = FALSE]
  if (nrow(outside)) t$family <- ifelse(is.na(x$table$family_feasible), "unknown",
    ifelse(x$table$family_feasible, "within", "outside"))
  lines <- c(.pr_cli_header("postrank_comparison", sprintf("%d methods on one posterior and loss; reference %s", nrow(x$table), x$reference)),
    paste0("  ", utils::capture.output(print(t, row.names = FALSE, right = FALSE))),
    if (nrow(ag)) .pr_cli_line("agreement with ", x$reference, ": ", paste0(ag$method, " ", .pr_fmt(ag$agreement, "ratio"),
      ifelse(is.na(ag$n_same), "", paste0(" (", ag$n_new_disclosed + ag$n_new_withheld + ag$n_reversed, " pairs changed)")), collapse = ", ")) else character(),
    if (any(!is.na(x$table$reason))) .pr_cli_line("no action: ", paste0(x$table$method, " (", x$table$status, ", ", x$table$reason, ")")[!is.na(x$table$reason)]) else character(),
    if (nrow(outside)) .pr_cli_line("outside declared family: ",
      paste0(outside$method, " (", outside$feasibility_reason, ")", collapse = "; ")) else character(),
    if (!family_recorded) .pr_cli_line("family feasibility was not recorded; recreate the comparison to check constraints") else character(),
    .pr_cli_line("scope: ", paste0(x$table$method, " = ", x$table$optimality_scope, collapse = "; ")),
    .pr_cli_line("baseline optimality is restricted to the declared score-order partitions"),
    .pr_cli_warning_line(x$warnings, width),
    .pr_cli_pointer("x$table has scope, bounds and reasons; x$relations the relation counts."))
  .pr_cli_finish(lines, width, tier)
}

#' @rdname format_postrank_cli
#' @export
format_postrank_frontier_cli <- function(x, ..., width = NULL, tier = NULL, n_head = 10L) {
  .pr_cli_assert_class(x, "postrank_frontier", "format_postrank_frontier_cli")
  width <- .pr_cli_width(width); tier <- .pr_cli_tier(tier); n_head <- .pr_cli_n_head(n_head)
  t <- x$table; axis <- if (is.null(x$q_criterion)) "tau" else paste0("tau x q_", x$q_criterion)
  cols <- intersect(c("tau", "q_value", "status", "G", "N", "disclosure_rate", "primary_risk", "risk_absolute_gap"), names(t))
  if (is.null(x$q_criterion)) cols <- setdiff(cols, "q_value")
  lines <- c(.pr_cli_header("postrank_frontier", sprintf("%d grid points over %s", nrow(t), axis)),
    .pr_cli_line(x$objective %||% "weighted", "; G_max ", x$G_max %||% "NA", "; backend ", x$backend %||% "NA", " (", x$strategy %||% "NA", ")"),
    .pr_table_lines(t[, cols, drop = FALSE], n_head, width),
    .pr_cli_line("monotonicity in tau is stated only up to the reported gaps; rows without bounds make no trend claim"),
    .pr_cli_pointer("x$table holds E_over_N and criterion risks per row."))
  .pr_cli_finish(lines, width, tier)
}

#' @rdname format_postrank_cli
#' @export
format_postrank_commonality_cost_cli <- function(x, ..., width = NULL, tier = NULL, n_head = 10L) {
  .pr_cli_assert_class(x, "postrank_commonality_cost", "format_postrank_commonality_cost_cli")
  width <- .pr_cli_width(width); tier <- .pr_cli_tier(tier); n_head <- .pr_cli_n_head(n_head)
  t <- x$table[, intersect(c("criterion_id", "common_grade_risk", "own_best_risk", "own_lower_bound", "cost_lower", "cost_upper",
    "own_status", "own_G", "own_disclosures", "relation_agreement"), names(x$table)), drop = FALSE]
  lines <- c(.pr_cli_header("postrank_commonality_cost", sprintf("%d criteria; criterion problems: q %s", nrow(t), x$protection)),
    .pr_table_lines(t, n_head, width),
    .pr_cli_line("cost bounds use solver values; own_best_risk is a validated incumbent, not a certified minimum"),
    .pr_cli_pointer("x$table also has own lower bounds, grade counts and relation agreement."))
  .pr_cli_finish(lines, width, tier)
}

#' @rdname format_postrank_cli
#' @export
format_postrank_sensitivity_cli <- function(x, ..., width = NULL, tier = NULL, n_head = 10L) {
  .pr_cli_assert_class(x, "postrank_sensitivity", "format_postrank_sensitivity_cli")
  width <- .pr_cli_width(width); tier <- .pr_cli_tier(tier); n_head <- .pr_cli_n_head(n_head)
  t <- data.frame(setting = x$grid$label, risk = x$table$risk, `N/M` = x$table$disclosure_rate, G = x$table$G,
    status = x$table$status, changed = x$changes$change_fraction, check.names = FALSE, stringsAsFactors = FALSE)
  t$risk <- .pr_fmt(t$risk, "risk"); t$`N/M` <- .pr_fmt(t$`N/M`, "pct"); t$changed <- .pr_fmt(t$changed, "ratio")
  lines <- c(.pr_cli_header("postrank_sensitivity", sprintf("%d settings; reference %s", nrow(t), x$reference_id)),
    .pr_table_lines(t, n_head, width), .pr_cli_warning_line(x$warnings, width),
    .pr_cli_pointer("x$grid holds the complete typed settings per row."))
  .pr_cli_finish(lines, width, tier)
}

#' @rdname format_postrank_cli
#' @export
format_postrank_crossfit_cli <- function(x, ..., width = NULL, tier = NULL, n_head = 10L) {
  .pr_cli_assert_class(x, "postrank_crossfit", "format_postrank_crossfit_cli")
  width <- .pr_cli_width(width); tier <- .pr_cli_tier(tier)
  sizes <- x$split$sizes
  f <- x$folds
  fold_lines <- vapply(f, function(z) sprintf("  fold %s: status %s; G %s; in-fold risk %s; out-of-fold risk %s; optimism %s; full-grade risk %s",
    z$fold, z$status, if (is.null(z$G)) "NA" else z$G, .pr_fmt(z$in_fold_risk, "risk"), .pr_fmt(z$out_of_fold_risk, "risk"),
    .pr_fmt(z$optimism, "risk"), .pr_fmt(z$full_grade_risk_on_fold, "risk")), "")
  lines <- c(.pr_cli_header("postrank_crossfit", sprintf("%d folds; %s; sizes %s", length(f), x$split$method, paste(sizes, collapse = "/"))),
    fold_lines,
    .pr_cli_line("mean optimism ", .pr_fmt(x$mean_optimism, "risk"), "; mean absolute optimism ", .pr_fmt(x$mean_abs_optimism, "risk"),
      if (!is.null(x$agreement)) paste0("; relation agreement ", .pr_fmt(unlist(x$agreement)[1], "ratio")) else ""),
    .pr_cli_warning_line(x$warnings, width),
    .pr_cli_pointer("x$interpretation_support states the scope of the unbiasedness statement."))
  .pr_cli_finish(lines, width, tier)
}

#' @rdname format_postrank_cli
#' @export
format_postrank_mc_fragility_cli <- function(x, ..., width = NULL, tier = NULL, n_head = 10L) {
  .pr_cli_assert_class(x, "postrank_mc_fragility", "format_postrank_mc_fragility_cli")
  width <- .pr_cli_width(width); tier <- .pr_cli_tier(tier); n_head <- .pr_cli_n_head(n_head)
  s <- x$summary
  split <- if (!is.null(s$fragile_disclosed) && !is.null(s$fragile_tied)) sprintf(" (%d disclosed, %d withheld)", s$fragile_disclosed, s$fragile_tied) else ""
  pairs <- x$pairs
  top <- if (is.data.frame(pairs) && nrow(pairs) && "fragile" %in% names(pairs) && any(pairs$fragile %in% TRUE)) {
    f <- pairs[pairs$fragile %in% TRUE, , drop = FALSE]
    if ("ratio" %in% names(f)) f <- f[order(-f$ratio, method = "radix"), , drop = FALSE]
    f <- f[seq_len(min(nrow(f), n_head)), intersect(c("entity_i", "entity_j", "weighted_error", "margin", "mcse", "ratio"), names(f)), drop = FALSE]
    c(.pr_cli_line("most fragile pairs:"), .pr_table_lines(f, n_head, width))
  } else character()
  lines <- c(.pr_cli_header("postrank_mc_fragility", sprintf("%d fragile of %d traced pairs%s", as.integer(s$fragile), as.integer(s$traced), split)),
    .pr_cli_line("S ", .pr_fmt(x$draws %||% NA, "count"), "; z ", .pr_fmt(x$z, "num"), "; MCSE method ", x$mcse_method %||% "NA",
      if (isTRUE(s$mcse_unavailable > 0)) paste0("; MCSE unavailable for ", s$mcse_unavailable, " pairs") else ""),
    top, .pr_cli_warning_line(x$warnings, width),
    .pr_cli_pointer("x$pairs lists the traced pairs; the fragility figure is deferred."))
  .pr_cli_finish(lines, width, tier)
}

#' @rdname format_postrank_cli
#' @export
format_postrank_diagnostics_cli <- function(x, ..., width = NULL, tier = NULL, n_head = 10L) {
  .pr_cli_assert_class(x, "postrank_diagnostics", "format_postrank_diagnostics_cli")
  width <- .pr_cli_width(width); tier <- .pr_cli_tier(tier)
  val <- function(name) unlist(lapply(x$summaries, function(s) { d <- s$diagnostics[[name]]; if (isTRUE(d$available)) d$value else NULL }))
  rh <- val("rhat"); es <- val("ess_bulk")
  tl <- x$summaries[[x$total_loss$trace_id %||% ""]]
  mcse <- if (!is.null(tl) && isTRUE(tl$diagnostics$mcse_mean$available)) .pr_fmt(tl$diagnostics$mcse_mean$value, "gap") else "NA"
  lines <- c(.pr_cli_header("postrank_diagnostics", sprintf("%d decision traces; regime %s", length(x$summaries), paste(unique(x$regimes), collapse = "/"))),
    .pr_cli_line("max Rhat ", if (length(rh)) .pr_fmt(max(rh), "num") else "NA", "; min bulk ESS ", if (length(es)) .pr_fmt(min(es), "num") else "NA",
      "; total-loss MCSE ", mcse),
    .pr_cli_line("ESS is not an IID sample size; no convergence verification"),
    .pr_cli_warning_line(x$warnings, width),
    .pr_cli_pointer("summary(x) contains the per-trace records; trace plotting is deferred."))
  .pr_cli_finish(lines, width, tier)
}

#' @rdname format_postrank_cli
#' @export
format_postrank_report_cli <- function(x, ..., width = NULL, tier = NULL, n_head = 10L) {
  .pr_cli_assert_class(x, "postrank_report", "format_postrank_report_cli")
  width <- .pr_cli_width(width); tier <- .pr_cli_tier(tier)
  ok <- isTRUE(x$incumbent_validated) && !is.null(x$grade)
  state <- if (!ok) "no validated incumbent; no grades" else if (x$disclosure$N == 0) "all comparisons withheld; E/N is NA" else
    sprintf("%d entities in %d grades; disclosed %s", length(x$grade), x$disclosure$G, .pr_fmt(x$disclosure$disclosure_rate, "pct"))
  n_fig <- sum(vapply(x$figures %||% list(), function(f) isTRUE(f$available), TRUE))
  lines <- c(.pr_cli_header("postrank_report", paste0("en; ", if (is.null(x$output_file)) "not written" else paste0("written ", basename(x$output_file)),
      "; ", length(x$sections %||% character()), " sections; ", n_fig, if (n_fig == 1L) " figure" else " figures")),
    .pr_cli_line(state),
    .pr_cli_line("status ", x$status$normalized, "   backend ", x$backend$name %||% "NA", " (", x$strategy %||% "NA", ")"),
    .pr_cli_warning_line(x$warnings, width),
    .pr_cli_pointer("postrank_report(..., output_file = ) writes the standalone English HTML report."))
  .pr_cli_finish(lines, width, tier)
}

#' @rdname format_postrank_cli
#' @export
format_postrank_guarantee_cli <- function(x, ..., width = NULL, tier = NULL, n_head = 10L) {
  cls <- c("postrank_iid_bounds", "postrank_protection_envelopes", "postrank_protection_analysis", "postrank_regret_bound")
  .pr_cli_assert_class(x, cls, "format_postrank_guarantee_cli")
  width <- .pr_cli_width(width); tier <- .pr_cli_tier(tier)
  g <- if (is.list(x$guarantee)) x$guarantee else x
  flag <- function(f) tolower(as.character(isTRUE(g[[f]])))
  lines <- c(.pr_cli_header(cls[inherits(x, cls, which = TRUE) > 0][1L], "conditional reference calculation"),
    .pr_cli_line("guarantee status ", g$guarantee_status %||% "not_established"),
    .pr_cli_line("guarantee_issued ", flag("guarantee_issued"), "; numerical_certification ", flag("numerical_certification")),
    .pr_cli_line("finite_sample_certificate ", flag("finite_sample_certificate"), "; numerically_verified ", flag("numerically_verified")),
    if (!is.null(g$guarantee_reason)) .pr_cli_line("reason ", paste(g$guarantee_reason, collapse = "; ")) else character(),
    .pr_cli_pointer("inspect x$assumptions; this is not a numerical certificate."))
  .pr_cli_finish(lines, width, tier)
}

#' @rdname format_postrank_cli
#' @export
format_postrank_backend_availability_cli <- function(x, ..., width = NULL, tier = NULL, n_head = 10L) {
  .pr_cli_assert_class(x, "postrank_backend_availability", "format_postrank_backend_availability_cli")
  width <- .pr_cli_width(width); tier <- .pr_cli_tier(tier)
  lines <- c(.pr_cli_header("postrank_backend_availability", paste0(x$backend, ": ", if (isTRUE(x$installed)) paste0("installed ", x$wrapper_version) else "not installed")),
    .pr_cli_line("available for attempt ", tolower(as.character(isTRUE(x$available_for_attempt))), "; runtime check ", x$runtime_check$status,
      "; license check ", x$license_check$status),
    .pr_cli_pointer("availability is package metadata only; it is not a license or runtime test."))
  .pr_cli_finish(lines, width, tier)
}

#' @rdname format_postrank_cli
#' @export
format_postrank_summary_cli <- function(x, ..., width = NULL, tier = NULL, n_head = 10L) {
  .pr_cli_assert_class(x, "postrank_summary", "format_postrank_summary_cli")
  width <- .pr_cli_width(width); tier <- .pr_cli_tier(tier)
  rule <- function(title) paste0("-- ", title, " ", strrep("-", max(3L, width - nchar(title) - 4L)))
  one <- function(v) {
    u <- unlist(v); if (!length(u)) return("none")
    vals <- if (is.numeric(u)) format(u, digits = 4) else as.character(u)
    if (!is.null(names(u)) && all(nzchar(names(u)))) paste(names(u), vals, sep = "=", collapse = ", ") else paste(vals, collapse = ", ")
  }
  kv <- function(r) if (!length(r)) .pr_cli_line("none") else vapply(names(r), function(k) .pr_cli_line(k, ": ", one(r[[k]])), "")
  lines <- c(paste0("<", class(x)[1L], ">"),
    rule("Result"), kv(x$headline), rule("Settings"), kv(x$settings),
    rule("Declarations"), kv(x$declarations), rule("Provenance"), kv(x$provenance),
    rule("Identities"), kv(lapply(x$identities, function(v) substr(v, 1L, 8L))),
    rule("Warnings"), if (length(x$warnings)) .pr_cli_line(x$warnings) else .pr_cli_line("none"),
    rule("Reading"), .pr_cli_line(x$interpretation))
  .pr_cli_finish(lines, width, tier)
}

# ---- print / format methods ------------------------------------------------------------------
.pr_formatter_of <- c(postrank_draws = "draws", postrank_validation = "validation", postrank_pairwise = "pairwise",
  postrank_coefficients = "coefficients", postrank_coefficient_diagnostics = "coefficient_diagnostics",
  postrank_declarations = "declarations", postrank_settings = "settings", postrank_control = "control",
  postrank_problem = "problem", postrank_fit = "fit", postrank_solution_validation = "validation",
  postrank_analysis = "analysis", postrank_report_card = "report_card", postrank_baseline = "baseline",
  postrank_comparison = "comparison", postrank_frontier = "frontier", postrank_commonality_cost = "commonality_cost",
  postrank_sensitivity = "sensitivity", postrank_crossfit = "crossfit", postrank_mc_fragility = "mc_fragility",
  postrank_diagnostics = "diagnostics", postrank_report = "report", postrank_iid_bounds = "guarantee",
  postrank_protection_envelopes = "guarantee", postrank_protection_analysis = "guarantee",
  postrank_regret_bound = "guarantee", postrank_backend_availability = "backend_availability",
  postrank_summary = "summary")
.pr_format_dispatch <- function(x, cls, ...) {
  f <- get(paste0("format_postrank_", .pr_formatter_of[[cls]], "_cli"), mode = "function")
  f(x, ...)
}
.pr_print_dispatch <- function(x, cls, ..., width = NULL, n_head = 10L) {
  cat(.pr_format_dispatch(x, cls, width = width, n_head = n_head), sep = "\n")
  invisible(x)
}

#' @export
print.postrank_draws <- function(x, ..., width = NULL, n_head = 10L) .pr_print_dispatch(x, "postrank_draws", width = width, n_head = n_head)
#' @export
format.postrank_draws <- function(x, ...) .pr_format_dispatch(x, "postrank_draws", ...)
#' @export
print.postrank_validation <- function(x, ..., width = NULL, n_head = 10L) .pr_print_dispatch(x, "postrank_validation", width = width, n_head = n_head)
#' @export
format.postrank_validation <- function(x, ...) .pr_format_dispatch(x, "postrank_validation", ...)
#' @export
print.postrank_pairwise <- function(x, ..., width = NULL, n_head = 10L) .pr_print_dispatch(x, "postrank_pairwise", width = width, n_head = n_head)
#' @export
format.postrank_pairwise <- function(x, ...) .pr_format_dispatch(x, "postrank_pairwise", ...)
#' @export
print.postrank_coefficients <- function(x, ..., width = NULL, n_head = 10L) .pr_print_dispatch(x, "postrank_coefficients", width = width, n_head = n_head)
#' @export
format.postrank_coefficients <- function(x, ...) .pr_format_dispatch(x, "postrank_coefficients", ...)
#' @export
print.postrank_coefficient_diagnostics <- function(x, ..., width = NULL, n_head = 10L) .pr_print_dispatch(x, "postrank_coefficient_diagnostics", width = width, n_head = n_head)
#' @export
format.postrank_coefficient_diagnostics <- function(x, ...) .pr_format_dispatch(x, "postrank_coefficient_diagnostics", ...)
#' @export
print.postrank_declarations <- function(x, ..., width = NULL, n_head = 10L) .pr_print_dispatch(x, "postrank_declarations", width = width, n_head = n_head)
#' @export
format.postrank_declarations <- function(x, ...) .pr_format_dispatch(x, "postrank_declarations", ...)
#' @export
print.postrank_settings <- function(x, ..., width = NULL, n_head = 10L) .pr_print_dispatch(x, "postrank_settings", width = width, n_head = n_head)
#' @export
format.postrank_settings <- function(x, ...) .pr_format_dispatch(x, "postrank_settings", ...)
#' @export
print.postrank_control <- function(x, ..., width = NULL, n_head = 10L) .pr_print_dispatch(x, "postrank_control", width = width, n_head = n_head)
#' @export
format.postrank_control <- function(x, ...) .pr_format_dispatch(x, "postrank_control", ...)
#' @export
print.postrank_problem <- function(x, ..., width = NULL, n_head = 10L) .pr_print_dispatch(x, "postrank_problem", width = width, n_head = n_head)
#' @export
format.postrank_problem <- function(x, ...) .pr_format_dispatch(x, "postrank_problem", ...)
#' @export
print.postrank_fit <- function(x, ..., width = NULL, n_head = 10L) .pr_print_dispatch(x, "postrank_fit", width = width, n_head = n_head)
#' @export
format.postrank_fit <- function(x, ...) .pr_format_dispatch(x, "postrank_fit", ...)
#' @export
print.postrank_solution_validation <- function(x, ..., width = NULL, n_head = 10L) .pr_print_dispatch(x, "postrank_solution_validation", width = width, n_head = n_head)
#' @export
format.postrank_solution_validation <- function(x, ...) .pr_format_dispatch(x, "postrank_solution_validation", ...)
#' @export
print.postrank_analysis <- function(x, ..., width = NULL, n_head = 10L) .pr_print_dispatch(x, "postrank_analysis", width = width, n_head = n_head)
#' @export
format.postrank_analysis <- function(x, ...) .pr_format_dispatch(x, "postrank_analysis", ...)
#' @export
print.postrank_report_card <- function(x, ..., width = NULL, n_head = 10L) .pr_print_dispatch(x, "postrank_report_card", width = width, n_head = n_head)
#' @export
format.postrank_report_card <- function(x, ...) .pr_format_dispatch(x, "postrank_report_card", ...)
#' @export
print.postrank_baseline <- function(x, ..., width = NULL, n_head = 10L) .pr_print_dispatch(x, "postrank_baseline", width = width, n_head = n_head)
#' @export
format.postrank_baseline <- function(x, ...) .pr_format_dispatch(x, "postrank_baseline", ...)
#' @export
print.postrank_comparison <- function(x, ..., width = NULL, n_head = 10L) .pr_print_dispatch(x, "postrank_comparison", width = width, n_head = n_head)
#' @export
format.postrank_comparison <- function(x, ...) .pr_format_dispatch(x, "postrank_comparison", ...)
#' @export
print.postrank_frontier <- function(x, ..., width = NULL, n_head = 10L) .pr_print_dispatch(x, "postrank_frontier", width = width, n_head = n_head)
#' @export
format.postrank_frontier <- function(x, ...) .pr_format_dispatch(x, "postrank_frontier", ...)
#' @export
print.postrank_commonality_cost <- function(x, ..., width = NULL, n_head = 10L) .pr_print_dispatch(x, "postrank_commonality_cost", width = width, n_head = n_head)
#' @export
format.postrank_commonality_cost <- function(x, ...) .pr_format_dispatch(x, "postrank_commonality_cost", ...)
#' @export
print.postrank_sensitivity <- function(x, ..., width = NULL, n_head = 10L) .pr_print_dispatch(x, "postrank_sensitivity", width = width, n_head = n_head)
#' @export
format.postrank_sensitivity <- function(x, ...) .pr_format_dispatch(x, "postrank_sensitivity", ...)
#' @export
print.postrank_crossfit <- function(x, ..., width = NULL, n_head = 10L) .pr_print_dispatch(x, "postrank_crossfit", width = width, n_head = n_head)
#' @export
format.postrank_crossfit <- function(x, ...) .pr_format_dispatch(x, "postrank_crossfit", ...)
#' @export
print.postrank_mc_fragility <- function(x, ..., width = NULL, n_head = 10L) .pr_print_dispatch(x, "postrank_mc_fragility", width = width, n_head = n_head)
#' @export
format.postrank_mc_fragility <- function(x, ...) .pr_format_dispatch(x, "postrank_mc_fragility", ...)
#' @export
print.postrank_diagnostics <- function(x, ..., width = NULL, n_head = 10L) .pr_print_dispatch(x, "postrank_diagnostics", width = width, n_head = n_head)
#' @export
format.postrank_diagnostics <- function(x, ...) .pr_format_dispatch(x, "postrank_diagnostics", ...)
#' @export
print.postrank_report <- function(x, ..., width = NULL, n_head = 10L) .pr_print_dispatch(x, "postrank_report", width = width, n_head = n_head)
#' @export
format.postrank_report <- function(x, ...) .pr_format_dispatch(x, "postrank_report", ...)
#' @export
print.postrank_iid_bounds <- function(x, ..., width = NULL, n_head = 10L) .pr_print_dispatch(x, "postrank_iid_bounds", width = width, n_head = n_head)
#' @export
format.postrank_iid_bounds <- function(x, ...) .pr_format_dispatch(x, "postrank_iid_bounds", ...)
#' @export
print.postrank_protection_envelopes <- function(x, ..., width = NULL, n_head = 10L) .pr_print_dispatch(x, "postrank_protection_envelopes", width = width, n_head = n_head)
#' @export
format.postrank_protection_envelopes <- function(x, ...) .pr_format_dispatch(x, "postrank_protection_envelopes", ...)
#' @export
print.postrank_protection_analysis <- function(x, ..., width = NULL, n_head = 10L) .pr_print_dispatch(x, "postrank_protection_analysis", width = width, n_head = n_head)
#' @export
format.postrank_protection_analysis <- function(x, ...) .pr_format_dispatch(x, "postrank_protection_analysis", ...)
#' @export
print.postrank_regret_bound <- function(x, ..., width = NULL, n_head = 10L) .pr_print_dispatch(x, "postrank_regret_bound", width = width, n_head = n_head)
#' @export
format.postrank_regret_bound <- function(x, ...) .pr_format_dispatch(x, "postrank_regret_bound", ...)
#' @export
print.postrank_backend_availability <- function(x, ..., width = NULL, n_head = 10L) .pr_print_dispatch(x, "postrank_backend_availability", width = width, n_head = n_head)
#' @export
format.postrank_backend_availability <- function(x, ...) .pr_format_dispatch(x, "postrank_backend_availability", ...)
#' @export
print.postrank_summary <- function(x, ..., width = NULL, n_head = 10L) .pr_print_dispatch(x, "postrank_summary", width = width, n_head = n_head)
#' @export
format.postrank_summary <- function(x, ...) .pr_format_dispatch(x, "postrank_summary", ...)

# ---- summary() methods: typed receipts (SPEC-13.5) -------------------------------------------
.pr_summary_lang <- function() {
  lang <- getOption("postrank.lang", "en")
  if (!identical(lang, "en")) .pr_abort(paste0("postrank.lang = \"", lang, "\" is not supported; official output is English (\"en\")"),
    "unsupported_language", "$.postrank.lang")
}
.pr_new_summary <- function(cls, x, headline = list(), settings = list(), declarations = list(), provenance = list(),
                            identities = list(), warnings = character(), interpretation = character()) {
  .pr_summary_lang()
  structure(list(object_class = cls, schema_version = x$schema_version %||% NA_character_, headline = headline,
    provenance = provenance, declarations = declarations, settings = settings,
    identities = identities[!vapply(identities, is.null, TRUE)], warnings = unique(as.character(warnings)),
    interpretation = c(interpretation, "Smaller grade = higher priority; a shared grade withholds the comparison.",
      "Bounds are solver values; the gap is not regret.")),
    class = c(paste0(cls, "_summary"), "postrank_summary", "list"))
}
.pr_fit_headline <- function(fit) {
  ev <- fit$evaluation; ok <- isTRUE(fit$incumbent_validated)
  list(n = length(fit$problem$pairwise$entity_ids), K = length(fit$problem$pairwise$criterion_ids),
    G = if (ok) ev$G else NA_integer_, sizes = if (ok) tabulate(fit$grade) else NULL, N = if (ok) ev$N else NA, M = fit$problem$M,
    disclosure_rate = if (ok) ev$disclosure_rate else NA, risk = if (ok) fit$objective$primary_action_risk else NA,
    status = fit$status$normalized, gap = fit$objective$risk_absolute_gap, bound_source = fit$objective$bound_source,
    E_over_N = if (ok) ev$E_over_N else NULL)
}
.pr_policy_view <- function(s) s[intersect(c("weights", "tau", "G_max", "q", "exact_G", "objective", "minimax_criteria", "minimax_refine"), names(s))]

#' @export
summary.postrank_fit <- function(object, ...) {
  .pr_new_summary("postrank_fit", object, headline = .pr_fit_headline(object), settings = .pr_policy_view(object$problem$settings),
    declarations = list(status = if (is.null(object$problem$pairwise$context)) "undeclared (typed coefficient source)" else "declared, not independently verified"),
    provenance = list(backend = object$backend$name, wrapper_version = object$backend$wrapper_version %||% NA_character_,
      solver_version = object$backend$solver_version %||% NA_character_, resolution = object$backend$resolution %||% NA_character_,
      channel = object$backend$channel %||% NA_character_, strategy = object$engine$strategy, runtime = object$runtime),
    identities = list(input = object$input_identity, problem = object$problem_identity,
      solution = object$solution_identity$relation_identity),
    warnings = object$warnings)
}
#' @export
summary.postrank_analysis <- function(object, ...) {
  s <- summary.postrank_fit(object$fit)
  s$object_class <- "postrank_analysis"; class(s)[1L] <- "postrank_analysis_summary"
  s$declarations <- object$metadata$declarations[intersect(c("status", "source", "kind", "note"), names(object$metadata$declarations))]
  s$provenance$timings <- object$timings
  s$provenance$package_version <- object$provenance$package_version
  s$headline$extras <- vapply(object$extras, function(r) if (r$available) "available" else r$reason, "")
  s$settings$label <- object$settings$label
  s$warnings <- object$warnings
  s
}
.pr_simple_summary <- function(cls) function(object, ...) {
  .pr_new_summary(cls, object, headline = list(class = cls),
    identities = list(input = object$input_identity %||% object$validation$input_identity, pairwise = object$pairwise_identity,
      problem = object$problem_identity), warnings = object$warnings, interpretation = object$interpretation)
}
#' @export
summary.postrank_draws <- function(object, ...) {
  .pr_new_summary("postrank_draws", object,
    headline = list(n = length(object$entity_ids), K = length(object$criterion_ids), input_kind = object$input_kind,
      dependence_mode = object$dependence_mode, regime = object$joint_draws$sampling$regime),
    declarations = list(targets = vapply(object$targets, function(t) paste0(t$criterion_id, ": ", t$estimand), ""),
      identification = object$identification$note, tie_justification = object$tie_policy$justification,
      transforms = vapply(object$targets, function(t) t$source_transform %||% "identity", "")),
    provenance = object$provenance[intersect(c("producer", "artifact_id", "created_at"), names(object$provenance))],
    identities = list(input = object$validation$input_identity))
}
#' @export
summary.postrank_validation <- .pr_simple_summary("postrank_validation")
#' @export
summary.postrank_pairwise <- function(object, ...) .pr_new_summary("postrank_pairwise", object,
  headline = list(dim = dim(object$e), sample_sizes = object$sample_sizes, method = object$method),
  identities = list(input = object$input_identity, pairwise = object$pairwise_identity))
#' @export
summary.postrank_coefficients <- function(object, ...) .pr_new_summary("postrank_coefficients", object,
  headline = list(dim = dim(object$e), kind = object$input_kind),
  declarations = list(conditional_independence = object$source$conditional_independence),
  provenance = object$provenance, settings = object$capabilities,
  identities = list(coefficient = object$coefficient_identity))
#' @export
summary.postrank_coefficient_diagnostics <- .pr_simple_summary("postrank_coefficient_diagnostics")
#' @export
summary.postrank_settings <- function(object, ...) .pr_new_summary("postrank_settings", object, headline = list(label = object$label),
  settings = c(.pr_policy_view(object), list(weight_sum_tolerance = object$weight_sum_tolerance)), provenance = object$provenance)
#' @export
summary.postrank_control <- function(object, ...) .pr_new_summary("postrank_control", object,
  headline = list(time_limit = object$time_limit, threads = object$threads, strategy = object$strategy),
  settings = list(seed = object$seed, absolute_risk_gap = object$absolute_risk_gap, relative_gap = object$relative_gap,
    engine = unlist(object$engine), tolerances = unlist(object$tolerances)), provenance = object$provenance)
#' @export
summary.postrank_problem <- function(object, ...) .pr_new_summary("postrank_problem", object,
  headline = list(n = length(object$pairwise$entity_ids), K = length(object$pairwise$criterion_ids), M = object$M,
    objective_units = object$objective_units$raw, builder_version = object$builder_version),
  settings = .pr_policy_view(object$settings), identities = list(input = object$input_identity, problem = object$problem_identity))
#' @export
summary.postrank_solution_validation <- .pr_simple_summary("postrank_solution_validation")
#' @export
summary.postrank_report_card <- function(object, ...) .pr_new_summary("postrank_report_card", object,
  headline = list(n = nrow(object$data), level = object$level, interval_source = object$interval_source,
    secondary_order = object$secondary_order), settings = .pr_policy_view(object$settings),
  identities = list(input = object$input_identity, grade = object$grade_identity), warnings = object$warnings)
#' @export
summary.postrank_baseline <- function(object, ...) .pr_new_summary("postrank_baseline", object,
  headline = list(method = object$method, cut_rule = object$cut_rule, risk = object$risk, objective = object$objective,
    cuts = object$cuts), settings = c(.pr_policy_view(object$settings), object$tie_policy),
  identities = list(input = object$input_identity), warnings = object$warnings)
#' @export
summary.postrank_comparison <- function(object, ...) .pr_new_summary("postrank_comparison", object,
  headline = list(methods = object$table$method, reference = object$reference), settings = .pr_policy_view(object$settings),
  identities = list(input = object$input_identity), warnings = object$warnings)
#' @export
summary.postrank_frontier <- function(object, ...) .pr_new_summary("postrank_frontier", object,
  headline = list(rows = nrow(object$table), backend = object$backend, strategy = object$strategy),
  settings = list(weights = object$weights, G_max = object$G_max, objective = object$objective),
  identities = list(input = object$input_identity), interpretation = object$interpretation)
#' @export
summary.postrank_commonality_cost <- function(object, ...) .pr_new_summary("postrank_commonality_cost", object,
  headline = list(criteria = nrow(object$table), protection = object$protection, backend = object$backend),
  identities = list(input = object$input_identity, problem = object$problem_identity), interpretation = object$interpretation)
#' @export
summary.postrank_sensitivity <- function(object, ...) .pr_new_summary("postrank_sensitivity", object,
  headline = list(rows = nrow(object$table), reference = object$reference_id), warnings = object$warnings)
#' @export
summary.postrank_crossfit <- .pr_simple_summary("postrank_crossfit")
#' @export
summary.postrank_mc_fragility <- .pr_simple_summary("postrank_mc_fragility")
#' @export
summary.postrank_diagnostics <- function(object, ...) .pr_new_summary("postrank_diagnostics", object,
  headline = list(traces = names(object$summaries), regimes = object$regimes,
    convergence_verified = object$convergence_verified, finite_sample_certificate = object$finite_sample_certificate,
    numerical_certification = object$numerical_certification),
  identities = list(input = object$input_identity, problem = object$problem_identity), warnings = object$warnings,
  interpretation = object$interpretation)
#' @export
summary.postrank_report <- function(object, ...) .pr_new_summary("postrank_report", object,
  headline = list(output_file = object$output_file %||% "not written", status = object$status$normalized),
  identities = list(input = object$input_identity, problem = object$problem_identity), warnings = object$warnings,
  interpretation = object$interpretation)
#' @export
summary.postrank_iid_bounds <- .pr_simple_summary("postrank_iid_bounds")
#' @export
summary.postrank_protection_envelopes <- .pr_simple_summary("postrank_protection_envelopes")
#' @export
summary.postrank_protection_analysis <- .pr_simple_summary("postrank_protection_analysis")
#' @export
summary.postrank_regret_bound <- .pr_simple_summary("postrank_regret_bound")
#' @export
summary.postrank_backend_availability <- function(object, ...) .pr_new_summary("postrank_backend_availability", object,
  headline = list(backend = object$backend, installed = object$installed, available_for_attempt = object$available_for_attempt),
  provenance = list(package_path = object$package_path, runtime_check = object$runtime_check$status,
    license_check = object$license_check$status), interpretation = object$interpretation)
