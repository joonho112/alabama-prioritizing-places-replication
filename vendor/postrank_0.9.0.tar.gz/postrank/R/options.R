# The package options topic (Chapter 9): options are read at call time; loading the package sets none.

#' Package Options
#'
#' Options are read at call time; loading the package sets none of them.
#'
#' \describe{
#'   \item{`postrank.backend`}{Unset by default. The backend used when a
#'     solving verb is called with `backend = NULL`: the explicit `backend`
#'     argument wins, then this option, then `"gurobi"`. The value must be
#'     `"gurobi"` or `"highs"`; anything else raises `invalid_backend`. If the
#'     resolved backend is not installed or not usable the call stops with both
#'     remedies; postrank never switches to another backend.}
#'   \item{`postrank.lang`}{Default `"en"`. Official report and summary text is
#'     English only. Language-sensitive views ([postrank_report()] and the
#'     `summary()` methods) reject any other value with `unsupported_language`.
#'     [postrank_report()] has a `lang` argument, and an explicit `lang = "en"`
#'     there overrides the option; the `summary()` methods have no such argument
#'     and always read the option. `print()` and the formatters do not read it.}
#'   \item{`postrank.verbose`}{Reserved for progress messages. postrank 0.9.0
#'     emits no progress messages: this option and
#'     `postrank_control(verbose = )` are accepted and recorded but currently
#'     have no effect.}
#' }
#'
#' The environment variable `POSTRANK_TEST_GUROBI` is for the package's own
#' test suite only: set to `"true"`, it enables the tests that run the licensed
#' Gurobi backend. Ordinary use never reads it.
#'
#' @name postrank_options
#' @seealso [postrank_solve()], [postrank()], [postrank_report()]
#' @examples
#' getOption("postrank.backend")             # NULL: solving verbs default to "gurobi"
#' old <- options(postrank.backend = "highs") # select HiGHS for this session
#' getOption("postrank.backend")
#' options(old)
NULL
