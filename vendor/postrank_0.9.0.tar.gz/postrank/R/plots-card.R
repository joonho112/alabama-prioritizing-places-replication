# Required figures fig-report-card and fig-relations (Chapter 12). Pure views: they read
# stored slots through postrank_plot_data() and draw; nothing is solved or summarized.

#' @importFrom ggplot2 .data
NULL

.pr_status_panel <- function(title, reason, caption = NULL) {
  ggplot2::ggplot() + ggplot2::geom_blank() +
    .pr_labs(title = title, subtitle = paste("Unavailable:", reason), caption = caption) +
    theme_postrank() + ggplot2::theme(axis.line = ggplot2::element_blank(), axis.ticks = ggplot2::element_blank(),
      panel.grid.major.y = ggplot2::element_blank())
}
.pr_weights_text <- function(w) paste(names(w), formatC(unname(w), digits = 2, format = "f"), sep = " ", collapse = ", ")
.pr_sizes_text <- function(grade) paste(tabulate(grade, nbins = max(grade)), collapse = "/")

#' Plot the Common Grade Report Card
#'
#' One row per entity, sorted by grade (highest priority on top) and a stable
#' secondary key, with one panel per criterion: the stored posterior mean as a
#' point and the stored central interval as a separate segment, colored by
#' grade. The mean is never clipped into the interval (it may lie outside for a
#' skewed law). Light bands separate the grade blocks. The interval level and
#' source in the caption come from the stored card; the figure computes
#' nothing. Without a prepared card (for example no validated incumbent) a
#' status-only panel states the recorded reason.
#'
#' @param x A `postrank_report_card` or a `postrank_analysis`.
#' @param criteria Optional subset (and order) of criteria to show.
#' @param order Secondary order within a grade: `"grade"` (the stored card
#'   order), `"expected_rank"`, `"mean"` or `"label"`.
#' @param max_rows Optional maximum number of entities shown; truncation is
#'   announced in the subtitle.
#' @param show_withheld Logical; show grade-block sizes in the subtitle.
#' @param ... Unused.
#' @return A `ggplot` object.
#' @seealso [postrank_report_card()], [postrank_plot_data()]
#' @concept visualization
#' @examples
#' if (requireNamespace("highs", quietly = TRUE)) {
#'   fit <- postrank(postrank_toy, weights = c(need_A = .6, need_B = .4), tau = .25,
#'     G_max = 3L, backend = "highs", fragility = FALSE)
#'   postrank_plot_report_card(fit)
#' }
#' @export
postrank_plot_report_card <- function(x, criteria = NULL, order = c("grade", "expected_rank", "mean", "label"),
                                      max_rows = NULL, show_withheld = TRUE, ...) {
  order <- match.arg(order)
  .pr_assert(inherits(x, c("postrank_report_card", "postrank_analysis")), "x must be a postrank_report_card or postrank_analysis",
    "wrong_class", "$.x")
  title <- "Common grade report card"
  if (inherits(x, "postrank_analysis")) {
    if (is.null(x$report_card)) return(.pr_status_panel(title, if (!isTRUE(x$fit$incumbent_validated)) "no validated incumbent" else
      gsub("_", " ", x$extras$report_card$reason)))
    card <- x$report_card; risk <- x$fit$objective$primary_action_risk
  } else { card <- x; risk <- NULL }
  if (!is.null(max_rows)) .pr_assert(is.numeric(max_rows) && length(max_rows) == 1L && max_rows >= 1, "max_rows must be a positive integer", "invalid_display", "$.max_rows")
  .pr_assert(is.logical(show_withheld) && length(show_withheld) == 1L && !is.na(show_withheld), "show_withheld must be TRUE or FALSE", "invalid_display", "$.show_withheld")
  ks <- names(card$settings$weights)
  if (!is.null(criteria)) { .pr_assert(is.character(criteria) && all(criteria %in% ks) && !anyDuplicated(criteria),
    "criteria must name criteria of the card", "invalid_display", "$.criteria"); ks <- criteria }
  d <- card$data; n <- nrow(d); G <- max(d$grade); w <- card$settings$weights
  key <- switch(order, grade = d$sort_rank,
    expected_rank = as.numeric(as.matrix(d[paste0("expected_rank_", names(w))]) %*% w),
    mean = -as.numeric(as.matrix(d[paste0("mean_", names(w))]) %*% w), label = match(d$entity_id, sort(d$entity_id, method = "radix")))
  d <- d[order(d$grade, key, d$entity_id, method = "radix"), , drop = FALSE]
  shown <- if (is.null(max_rows)) n else min(n, as.integer(max_rows))
  d <- d[seq_len(shown), , drop = FALSE]
  long <- .pr_card_long(structure(list(data = d, settings = card$settings), class = "postrank_report_card"))
  long <- long[long$criterion %in% ks, , drop = FALSE]
  long$criterion <- factor(long$criterion, levels = ks)
  long$entity_id <- factor(long$entity_id, levels = rev(d$entity_id))
  long$grade <- factor(long$grade, levels = as.character(seq_len(G)))
  pos <- stats::setNames(rev(seq_len(shown)), d$entity_id)
  bands <- do.call(rbind, lapply(unique(d$grade), function(g) {
    p <- pos[d$entity_id[d$grade == g]]; data.frame(grade = g, ymin = min(p) - .5, ymax = max(p) + .5, odd = (g %% 2L) == 1L)
  }))
  bands <- bands[bands$odd, , drop = FALSE]
  sub <- if (G == 1L) sprintf("%d entities in 1 grade; all comparisons withheld", n) else
    sprintf("%d entities in %d grades%s", n, G, if (isTRUE(show_withheld)) paste0(" (sizes ", .pr_sizes_text(card$data$grade), ")") else "")
  sub <- paste0(sub, " | weights ", .pr_weights_text(w), " | tau ", format(card$settings$tau))
  if (!is.null(risk)) sub <- paste0(sub, " | risk ", .pr_fmt(risk, "risk"))
  if (shown < n) sub <- paste0(sub, sprintf(" | Showing %d of %d entities", shown, n))
  lvl <- format(100 * card$level)
  ggplot2::ggplot(long, ggplot2::aes(y = .data$entity_id)) +
    ggplot2::geom_rect(data = bands, ggplot2::aes(xmin = -Inf, xmax = Inf, ymin = .data$ymin, ymax = .data$ymax),
      inherit.aes = FALSE, fill = "grey95", colour = NA) +
    ggplot2::geom_segment(ggplot2::aes(x = .data$lower, xend = .data$upper, yend = .data$entity_id, colour = .data$grade), linewidth = 0.5) +
    ggplot2::geom_point(ggplot2::aes(x = .data$mean, colour = .data$grade), size = 1.6) +
    ggplot2::facet_wrap(~ criterion, scales = "free_x", nrow = 1) +
    (if (G <= 64L) scale_colour_grade(G) else ggplot2::scale_colour_manual(values = stats::setNames(rep("grey25", G), as.character(seq_len(G))),
      guide = "none")) +
    .pr_labs(title = "Common grade report card", subtitle = sub, x = "posterior mean and interval", y = NULL,
      caption = paste0(lvl, "% equal-tail posterior intervals from the declared input law (", card$interval_source,
        "). Shared grade = comparison withheld, not equality.")) +
    theme_postrank()
}

.pr_grade_of <- function(x, what) {
  if (inherits(x, "postrank_analysis")) x <- x$fit
  if (inherits(x, "postrank_fit")) return(if (isTRUE(x$incumbent_validated)) x$grade else NULL)
  if (inherits(x, "postrank_baseline")) return(x$grade)
  if (is.numeric(x) && !is.null(names(x))) return(stats::setNames(as.integer(x), names(x)))
  .pr_abort(paste(what, "must be a postrank_fit, postrank_analysis, postrank_baseline or named grade vector"), "wrong_class", paste0("$.", what))
}

#' Plot Pair Relations or a Relation Change Map
#'
#' With one object, the upper triangle of the pair relations in grade order:
#' above, withheld (gray) or below. With a second object `y`, the change of
#' each pair relation from `x` to `y`: unchanged, newly disclosed, newly
#' withheld or reversed, with the four counts and the agreement in the
#' subtitle. The map compares pair relations, not grade labels.
#'
#' @param x A `postrank_fit`, `postrank_analysis` or `postrank_baseline`.
#' @param y Optional second fit, analysis, baseline or named grade vector on
#'   the same entities.
#' @param labels `"auto"` (entity IDs when there are at most 30 entities),
#'   `"ids"` or `"none"`.
#' @param ... Unused.
#' @return A `ggplot` object.
#' @seealso [postrank_plot_compare()], [get_relations()]
#' @concept visualization
#' @examples
#' if (requireNamespace("highs", quietly = TRUE)) {
#'   fit <- postrank(postrank_toy, weights = c(need_A = .6, need_B = .4), tau = .25,
#'     G_max = 3L, backend = "highs", fragility = FALSE)
#'   postrank_plot_relations(fit)
#' }
#' @export
postrank_plot_relations <- function(x, y = NULL, labels = c("auto", "ids", "none"), ...) {
  labels <- match.arg(labels)
  g0 <- .pr_grade_of(x, "x")
  if (is.null(g0)) return(.pr_status_panel("Pair relations", "no validated incumbent"))
  n <- length(g0); show_ids <- labels == "ids" || (labels == "auto" && n <= 30L)
  if (is.null(y)) {
    d <- .pr_relations_long(g0)
    N <- sum(d$code != 0L); M <- nrow(d)
    p <- ggplot2::ggplot(d, ggplot2::aes(x = .data$j_pos, y = .data$i_pos, fill = .data$relation)) +
      ggplot2::geom_tile(colour = "white", linewidth = 0.2) +
      ggplot2::scale_fill_manual(values = postrank_palette(which = "relation"), drop = FALSE, name = "row entity is") +
      .pr_labs(title = "Pair relations of the common grade",
        subtitle = sprintf("%d entities in %d grades | disclosed %d/%d pairs", n, max(g0), N, M),
        caption = "Grey = withheld (same grade). A change map compares pair relations, not grade labels.")
  } else {
    g1 <- .pr_grade_of(y, "y")
    if (is.null(g1)) return(.pr_status_panel("Pair relation changes", "the second object has no validated grade"))
    .pr_assert(setequal(names(g1), names(g0)), "x and y must grade the same entities", "invalid_display", "$.y")
    d <- .pr_change_long(g0, g1); tab <- table(d$change); M <- nrow(d)
    sub <- if (tab[["unchanged"]] == M) sprintf("identical relations (agreement %s)", .pr_fmt(1, "ratio")) else
      sprintf("unchanged %d, newly disclosed %d, newly withheld %d, reversed %d | agreement %s",
        tab[["unchanged"]], tab[["newly disclosed"]], tab[["newly withheld"]], tab[["reversed"]], .pr_fmt(tab[["unchanged"]] / M, "ratio"))
    p <- ggplot2::ggplot(d, ggplot2::aes(x = .data$j_pos, y = .data$i_pos, fill = .data$change)) +
      ggplot2::geom_tile(colour = "white", linewidth = 0.2) +
      ggplot2::scale_fill_manual(values = postrank_palette(which = "change"), drop = FALSE, name = "relation change") +
      .pr_labs(title = "Pair relation changes", subtitle = sub,
        caption = "Grey = withheld or unchanged. A change map compares pair relations, not grade labels.")
  }
  ids <- names(g0)[order(g0, names(g0), method = "radix")]
  p + ggplot2::scale_x_continuous(breaks = if (show_ids) seq_len(n) else NULL, labels = if (show_ids) ids else NULL,
      expand = c(0, 0), position = "top") +
    ggplot2::scale_y_reverse(breaks = if (show_ids) seq_len(n) else NULL, labels = if (show_ids) ids else NULL, expand = c(0, 0)) +
    ggplot2::coord_equal() + .pr_labs(x = NULL, y = NULL) + theme_postrank() +
    ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 90, hjust = 0, vjust = 0.5), panel.grid.major.y = ggplot2::element_blank())
}
