.pr_tie_serialization_schema <- function() {
  path <- ""
  if (!isNamespace(environment(.pr_tie_serialization_schema))) {
    candidates <- file.path(c(".", "..", "../.."), "inst/schema/tie-draws-schema.json")
    found <- candidates[file.exists(candidates)]
    if (length(found)) path <- found[[1L]]
  }
  if (!nzchar(path)) path <- system.file("schema", "tie-draws-schema.json", package = "postrank")
  if (!nzchar(path)) .pr_abort("tie-aware serialization schema unavailable", "schema_unavailable")
  jsonlite::fromJSON(path, simplifyVector = FALSE)
}

.pr_tie_json_bind <- function(x) {
  x <- .pr_json_bind_payload(x)
  classes <- x$equality$criterion_classes
  if (!is.null(classes)) {
    .pr_fields(classes, x$criterion_ids, path = "$.equality.criterion_classes")
    x$equality$criterion_classes <- lapply(classes, function(z) {
      .pr_fields(z, x$entity_ids, path = "$.equality.criterion_classes")
      .pr_assert(all(vapply(z, function(a) is.character(a) && length(a) == 1L && is.null(dim(a)), logical(1L))),
        "class labels must be JSON strings", "invalid_json_type", "$.equality.criterion_classes")
      unlist(z, use.names = TRUE)
    })
  }
  x
}

.pr_tie_json_unbind <- function(x) {
  x <- .pr_json_unbind_payload(x)
  if (!is.null(x$equality$criterion_classes))
    x$equality$criterion_classes <- lapply(x$equality$criterion_classes, as.list)
  x
}

#' Read a Separate Equality-Neutral Input from Strict JSON
#'
#' Reads only `tie-aware-input-0.1`; it never upgrades or reinterprets a legacy
#' input. Duplicate JSON keys, malformed arrays and unsafe finite-law integer
#' tokens are rejected before floating conversion. Source histories, exact
#' equality declarations and opaque provider IDs retain their meaning.
#' Shape checks cover the supported schema-binding subset; the R validator
#' supplies the documented semantic checks. This is not scientific verification.
#'
#' @param path Existing JSON input file.
#' @return A sealed `postrank_tie_draws` from [as_postrank_tie_draws()].
#' @seealso [write_postrank_tie_draws()]
#' @concept tie-aware
#' @export
read_postrank_tie_draws <- function(path) {
  .pr_string(path, "$.path")
  .pr_assert(file.exists(path) && !dir.exists(path), "JSON file does not exist", "input_file_missing", path)
  text <- paste(readLines(path, warn = FALSE, encoding = "UTF-8"), collapse = "\n")
  node <- .pr_tie_json_scan(text); schema <- .pr_tie_serialization_schema()
  .pr_json_shape_guard(node, schema, schema)
  x <- tryCatch(jsonlite::fromJSON(text, simplifyVector = FALSE),
    error = function(e) .pr_abort(conditionMessage(e), "invalid_json"))
  x <- .pr_tie_json_restore_numbers(x, node)
  as_postrank_tie_draws(.pr_tie_json_bind(x))
}

#' Write a Separate Equality-Neutral Input as Strict JSON
#'
#' Writes the validated canonical payload with seventeen significant digits,
#' all original providers and histories, and named criterion equality partitions.
#' Validation is repeated before writing. The content is written atomically;
#' legacy input schemas, identities and readers are unchanged.
#'
#' @param x A new canonical payload or sealed `postrank_tie_draws`.
#' @param path Destination JSON file; its parent directory must exist.
#' @param overwrite Whether an existing file may be replaced.
#' @return The destination path invisibly.
#' @seealso [read_postrank_tie_draws()]
#' @concept tie-aware
#' @export
write_postrank_tie_draws <- function(x, path, overwrite = FALSE) {
  .pr_string(path, "$.path")
  .pr_assert(is.logical(overwrite) && length(overwrite) == 1L && !is.na(overwrite),
    "overwrite must be TRUE or FALSE")
  if (file.exists(path) && !overwrite) .pr_abort("output already exists; set overwrite=TRUE explicitly", "output_exists", path)
  .pr_assert(dir.exists(dirname(path)), "output directory does not exist", "output_directory_missing", path)
  source <- as_postrank_tie_draws(x)
  tree <- .pr_tie_json_unbind(.pr_tie_input_payload(source))
  text <- as.character(jsonlite::toJSON(tree, auto_unbox = TRUE, null = "null", na = "null", digits = 17, pretty = TRUE))
  schema <- .pr_tie_serialization_schema()
  .pr_json_shape_guard(.pr_tie_json_scan(text), schema, schema)
  temp <- tempfile(".postrank-tie-json-", tmpdir = dirname(path)); on.exit(unlink(temp), add = TRUE)
  writeLines(text, temp, useBytes = TRUE)
  .pr_assert(file.rename(temp, path), "atomic JSON replacement failed", "output_write_failed", path)
  invisible(path)
}
