.pr_stop <- function(message,class="postrank_error",code="postrank_error",details=NULL) {
  stop(structure(list(message=message,call=NULL,code=code,details=details),class=unique(c(class,"postrank_error","error","condition"))))
}
.pr_validate_problem <- function(problem) {
  .pr_assert(inherits(problem,"postrank_problem")&&identical(problem$schema_version,"0.1.0"),"expected current postrank_problem","invalid_problem")
  # readRDS restores sparse objects without registering Matrix's S4 methods.
  # Initialize them before a caller's first dim/nrow operation in fresh R.
  .pr_assert(requireNamespace("Matrix",quietly=TRUE),"Matrix is required for sparse model methods","matrix_package_missing")
  content<-problem;content$problem_identity<-NULL
  .pr_assert(!is.null(problem$problem_identity)&&identical(.pr_identity(content),problem$problem_identity),"problem changed after construction; rebuild from pairwise/settings","stale_problem_identity")
  .pr_validate_pairwise(problem$pairwise)
  if(!is.null(problem$protection_envelope)).pr_problem_q_thresholds(problem)
  invisible(TRUE)
}

#' Build a Backend-Independent Common-Grade Problem
#' @param pairwise Validated postrank_pairwise or typed postrank_coefficients. Typed inputs support weighted at-most-G problems only.
#' @param weights Criterion-named rank-loss weights summing to one.
#' @param tau Abstention cost in (0,0.5].
#' @param G_max Integer upper bound on occupied grades.
#' @param settings Optional [postrank_settings()] object, an alternative to the
#'   loose policy arguments; explicitly supplying both is a `settings_conflict`
#'   error. Typed settings cap `G_max` at the number of entities; only the legacy
#'   policy values enter `problem$settings`.
#' @param objective Weighted or minimax expected risk.
#' @param q Optional named criterion error budgets.
#' @param exact_G Optional exact nonempty grade count.
#' @param minimax_criteria Optional criterion IDs for minimax risk.
#' @param minimax_refine For minimax problems: \code{"weighted"} (default) first
#'   minimizes the ORIGINAL weighted risk within the selected minimax cap.
#'   If any weight is zero, a separate third stage minimizes uniform criterion
#'   risk under an additional cap on that original weighted optimum; weights
#'   are never perturbed. \code{fit$minimax_refine$lexicographic_certified}
#'   concerns the actual released action's primary and original weighted
#'   objectives; \code{pareto_certified} additionally requires the third stage
#'   when applicable. These are solver-reported conclusions subject to recorded
#'   gap controls and floating-point tolerances, not numerical proofs.
#'   \code{"none"} returns the first-stage incumbent. Ignored for weighted
#'   problems.
#' @return A postrank_problem with one sparse model shared by all backends.
#'   Minimax problems also record \code{minimax_diagnostics}: selected criteria
#'   whose directional error probabilities are all at least tau (degenerate: no
#'   action brings their risk below tau, so the minimax value is at least tau,
#'   and equals tau when all-tie is allowed).
#' @examples
#' draws <- read_postrank_draws(system.file("examples", "synthetic-iid.json",
#'   package = "postrank", mustWork = TRUE))
#' pairwise <- postrank_pairwise(draws)
#' weights <- c(need_A = .6, need_B = .4)
#' problem <- postrank_problem(pairwise, weights, tau = .25, G_max = 3L)
#' problem$objective_units
#' minimax <- postrank_problem(pairwise, weights, .25, 3L, objective = "minimax")
#' minimax$minimax_diagnostics$degenerate_criteria
#' @concept decision
#' @export
postrank_problem <- function(pairwise, weights = NULL, tau = NULL, G_max = NULL, objective = c("weighted", "minimax"),
                             q = NULL, exact_G = NULL, minimax_criteria = NULL, minimax_refine = c("weighted", "none"),
                             settings = NULL) {
  if (is.null(settings))
    return(.pr_problem_core(pairwise, weights, tau, G_max, objective, q, exact_G, minimax_criteria, minimax_refine))
  .pr_settings_conflict(.pr_supplied(.pr_policy_args))
  .pr_validate_pairwise(pairwise)
  p <- .pr_settings_bind(settings, pairwise)$policy
  .pr_problem_core(pairwise, p$weights, p$tau, p$G_max, p$objective, p$q, p$exact_G, p$minimax_criteria,
    p$minimax_refine)
}

# Unchanged 0.0.1.9003 (C3) body, moved behind the public adapter (freeze manifest: moved_from postrank_problem).
.pr_problem_core <- function(pairwise,weights,tau,G_max,objective=c("weighted","minimax"),q=NULL,exact_G=NULL,minimax_criteria=NULL,
                             minimax_refine=c("weighted","none")) {
  .pr_validate_pairwise(pairwise);loss<-.pr_loss_settings(pairwise,weights,tau)
  objective<-match.arg(objective);minimax_refine<-match.arg(minimax_refine)
  .pr_cf_problem_scope(pairwise,objective,q,exact_G,minimax_criteria)
  .pr_assert(typeof(G_max)%in%c("integer","double")&&is.null(dim(G_max))&&length(G_max)==1L,"G_max must be a scalar integer","invalid_grade_limit")
  .pr_safe_integer(G_max,TRUE,"$.G_max")
  .pr_assert(G_max<=length(pairwise$entity_ids),"G_max cannot exceed entity count","invalid_grade_limit")
  if(!is.null(q)) {
    .pr_assert(typeof(q)%in%c("integer","double")&&is.null(dim(q))&&length(q)>0L&&
      !is.null(names(q))&&!anyNA(names(q))&&!anyDuplicated(names(q))&&
      all(names(q)%in%pairwise$criterion_ids)&&all(is.finite(q))&&all(q>=0&q<=1),
      "q must be a nonempty uniquely criterion-named vector in [0,1]","invalid_protection")
    q<-q[pairwise$criterion_ids[pairwise$criterion_ids%in%names(q)]]
  }
  if(!is.null(exact_G)) {
    .pr_assert(typeof(exact_G)%in%c("integer","double")&&is.null(dim(exact_G))&&length(exact_G)==1L,
      "exact_G must be a scalar integer","invalid_exact_grade_count")
    .pr_safe_integer(exact_G,TRUE,"$.exact_G")
    .pr_assert(exact_G<=G_max,"exact_G cannot exceed G_max","invalid_exact_grade_count")
    exact_G<-as.integer(exact_G)
  }
  if(objective=="weighted") .pr_assert(is.null(minimax_criteria),
    "minimax_criteria requires objective='minimax'","invalid_minimax_criteria")
  else {
    if(is.null(minimax_criteria)) minimax_criteria<-pairwise$criterion_ids
    .pr_assert(is.character(minimax_criteria)&&is.null(dim(minimax_criteria))&&length(minimax_criteria)>0L&&
      !anyNA(minimax_criteria)&&!anyDuplicated(minimax_criteria)&&all(minimax_criteria%in%pairwise$criterion_ids),
      "minimax_criteria must be a nonempty unique subset of criterion IDs","invalid_minimax_criteria")
    minimax_criteria<-pairwise$criterion_ids[pairwise$criterion_ids%in%minimax_criteria]
  }
  settings<-c(loss,list(G_max=as.integer(G_max),objective=objective,q=q,exact_G=exact_G,minimax_criteria=minimax_criteria))
  if(objective=="minimax") settings$minimax_refine<-minimax_refine
  encoding_settings<-settings
  if(!is.null(exact_G)) encoding_settings$G_max<-exact_G
  base<-.pr_weighted_model(pairwise,encoding_settings)
  if(!is.null(exact_G)) base<-.pr_add_exact_grades(base,pairwise,settings)
  if(!is.null(q)) base<-.pr_add_protection(base,pairwise,settings)
  if(objective=="minimax") base<-.pr_add_minimax(base,pairwise,settings)
  units<-if(objective=="weighted")list(raw="weighted_Z",scale=1/choose(length(pairwise$entity_ids),2),offset=tau) else
    list(raw="minimax_risk_t",scale=1,offset=0)
  problem<-list(schema_version="0.1.0",input_identity=pairwise$input_identity,pairwise=pairwise,settings=settings,
    model=base$model,index=base$index,pair_map=base$pair_map,M=choose(length(pairwise$entity_ids),2),
    objective_units=units,builder_version="0.1.0")
  if(objective=="minimax") problem$minimax_diagnostics<-.pr_minimax_diagnostics(pairwise,tau,minimax_criteria)
  class(problem)<-c("postrank_problem","list");problem$problem_identity<-.pr_identity(problem)
  .pr_validate_problem(problem);problem
}
