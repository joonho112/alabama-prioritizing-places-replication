# Tidy plot data behind the six shipped figure verbs (Chapter 12 dispatch spec). Reads
# stored slots and reshapes them; never computes posterior summaries, risks or diagnostics.

.pr_reserved_figures <- c(pairwise = "fig-pairwise-error", sensitivity = "fig-settings-lattice",
  fragility = "fig-fragile-pairs", crossfit = "fig-crossfit", trace = "fig-mc-trace", dispersion = "fig-dispersion")

.pr_unshipped <- function(which) .pr_abort(sprintf("'%s' (%s) is a reserved figure design that is not shipped in postrank 0.9.0",
  which, .pr_reserved_figures[[which]]), "unshipped_figure", "$.which")

.pr_card_long <- function(card) {
  d <- card$data; ks <- names(card$settings$weights)
  do.call(rbind, lapply(ks, function(k) data.frame(entity_id = d$entity_id, grade = d$grade, sort_rank = d$sort_rank,
    n_withheld = d$n_withheld, criterion = k, mean = d[[paste0("mean_", k)]], lower = d[[paste0("lower_", k)]],
    upper = d[[paste0("upper_", k)]], expected_rank = d[[paste0("expected_rank_", k)]], stringsAsFactors = FALSE)))
}

.pr_relations_long <- function(grade) {
  ids <- names(grade); o <- order(grade, ids, method = "radix"); ids <- ids[o]; g <- grade[ids]
  r <- .pr_relations(g); n <- length(ids)
  idx <- which(upper.tri(r), arr.ind = TRUE)
  code <- r[idx]
  data.frame(entity_i = ids[idx[, 1]], entity_j = ids[idx[, 2]], i_pos = idx[, 1], j_pos = idx[, 2], code = as.integer(code),
    relation = factor(ifelse(code == 1L, "above", ifelse(code == 0L, "withheld", "below")), levels = c("above", "withheld", "below")),
    stringsAsFactors = FALSE)
}

.pr_change_long <- function(g0, g1) {
  base <- .pr_relations_long(g0)
  r1 <- .pr_relations(g1[names(g0)])
  b <- r1[cbind(base$entity_i, base$entity_j)]
  a <- base$code
  base$change <- factor(ifelse(a == b, "unchanged", ifelse(a == 0L, "newly disclosed", ifelse(b == 0L, "newly withheld", "reversed"))),
    levels = c("unchanged", "newly disclosed", "newly withheld", "reversed"))
  base
}

#' Tidy Plot Data Behind Every Figure Verb
#'
#' Returns the prepared table each shipped figure draws, so that any figure can
#' be rebuilt in another style. It reshapes stored slots only; it never solves,
#' evaluates actions or computes posterior summaries. For a `postrank_analysis`,
#' `which` is one of `"report_card"`, `"relations"` and `"profile"`
#' (`NULL` returns a named list of the available ones, with an availability
#' record for missing components). Frontier, commonality and comparison objects
#' supply their own tables. Reserved, unshipped designs (`"pairwise"`,
#' `"sensitivity"`, `"fragility"`, `"crossfit"`, `"trace"`, `"dispersion"`)
#' raise `unshipped_figure`.
#'
#' @param x A `postrank_analysis`, `postrank_fit`, `postrank_report_card`,
#'   `postrank_baseline`, `postrank_frontier`, `postrank_commonality_cost` or
#'   `postrank_comparison`.
#' @param which Optional component name (see Details).
#' @return A data frame, or for an analysis with `which = NULL` a named list.
#' @seealso [postrank_plot_report_card()], [postrank_plot_relations()]
#' @concept visualization
#' @examples
#' if (requireNamespace("highs", quietly = TRUE)) {
#'   fit <- postrank(postrank_toy, weights = c(need_A = .6, need_B = .4), tau = .25,
#'     G_max = 3L, backend = "highs", fragility = FALSE)
#'   head(postrank_plot_data(fit, "report_card"))
#' }
#' @export
postrank_plot_data <- function(x, which = NULL) {
  if (!is.null(which)) {
    .pr_assert(is.character(which) && length(which) == 1L, "which must be one string", "invalid_display", "$.which")
    if (which %in% names(.pr_reserved_figures)) .pr_unshipped(which)
  }
  if (inherits(x, "postrank_analysis")) {
    avail <- list(report_card = !is.null(x$report_card), relations = isTRUE(x$fit$incumbent_validated), profile = isTRUE(x$fit$incumbent_validated))
    get1 <- function(w) switch(w, report_card = if (avail$report_card) .pr_card_long(x$report_card) else NULL,
      relations = if (avail$relations) .pr_relations_long(x$fit$grade) else NULL, profile = get_profile(x),
      .pr_abort(paste("unknown plot data component:", w), "invalid_display", "$.which"))
    if (is.null(which)) {
      out <- lapply(c(report_card = "report_card", relations = "relations", profile = "profile"), get1)
      attr(out, "availability") <- lapply(names(avail), function(n) list(available = avail[[n]],
        reason = if (avail[[n]]) NULL else if (!isTRUE(x$fit$incumbent_validated)) "no_validated_incumbent" else x$extras$report_card$reason))
      names(attr(out, "availability")) <- names(avail)
      return(out)
    }
    return(get1(which))
  }
  if (inherits(x, "postrank_report_card")) return(.pr_card_long(x))
  if (inherits(x, "postrank_fit")) {
    w <- if (is.null(which)) "relations" else which
    if (w == "relations") return(if (isTRUE(x$incumbent_validated)) .pr_relations_long(x$grade) else NULL)
    if (w == "profile") return(get_profile(x))
    .pr_abort(paste("unknown plot data component for a fit:", w), "invalid_display", "$.which")
  }
  if (inherits(x, "postrank_baseline")) return(.pr_relations_long(x$grade))
  if (inherits(x, "postrank_frontier")) return(x$table)
  if (inherits(x, "postrank_commonality_cost")) return(x$table)
  if (inherits(x, "postrank_comparison")) return(if (identical(which, "relations")) x$relations else x$table)
  .pr_abort(sprintf("no shipped figure for class %s", class(x)[1L]), "wrong_class", "$.x")
}
