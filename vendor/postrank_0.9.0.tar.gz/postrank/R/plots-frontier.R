# Required figures fig-criterion-profile, fig-frontier and fig-commonality (Chapter 12).

#' Plot the Per-Criterion Error Profile
#'
#' One dot per criterion: the stored `E_k/N` (expected errors per disclosed
#' pair), `E_k/M` or criterion risk of the selected grade, with point size
#' proportional to the weight. With `budgets = TRUE` and `show = "E_over_N"`
#' an error budget `q_k` is drawn as a tick with a segment to the dot; for
#' `show = "risk"` a dashed line marks tau, the all-tie risk. In minimax mode
#' the criterion attaining the maximum risk gets a ring. When nothing is
#' disclosed, `E_k/N` is undefined and no point is invented.
#'
#' @param x A `postrank_fit` or `postrank_analysis` with a stored evaluation.
#' @param show `"E_over_N"`, `"E_over_M"` or `"risk"`.
#' @param budgets Logical; draw error budgets when present.
#' @param ... Unused.
#' @return A `ggplot` object.
#' @seealso [get_profile()]
#' @concept visualization
#' @examples
#' if (requireNamespace("highs", quietly = TRUE)) {
#'   fit <- postrank(postrank_toy, weights = c(need_A = .6, need_B = .4), tau = .25,
#'     G_max = 3L, backend = "highs", fragility = FALSE)
#'   postrank_plot_profile(fit)
#' }
#' @export
postrank_plot_profile <- function(x, show = c("E_over_N", "E_over_M", "risk"), budgets = TRUE, ...) {
  show <- match.arg(show)
  .pr_assert(inherits(x, c("postrank_fit", "postrank_analysis")), "x must be a postrank_fit or postrank_analysis", "wrong_class", "$.x")
  fit <- .pr_fit_of(x)
  title <- "Criterion error profile of the common grade"
  if (!isTRUE(fit$incumbent_validated)) return(.pr_status_panel(title, "no validated incumbent"))
  pr <- get_profile(fit); ev <- fit$evaluation; tau <- fit$problem$settings$tau
  pr$criterion <- factor(pr$criterion, levels = rev(pr$criterion))
  pr$value <- pr[[show]]
  sub <- sprintf("disclosed %s | weighted risk %s", .pr_fmt(ev$disclosure_rate, "pct"), .pr_fmt(ev$weighted_risk, "risk"))
  xlab <- switch(show, E_over_N = expression(E[k]/N), E_over_M = expression(E[k]/M), risk = expression(R[k]))
  p <- ggplot2::ggplot(pr, ggplot2::aes(y = .data$criterion))
  if (show == "E_over_N" && ev$N == 0) {
    p <- p + ggplot2::geom_blank() + ggplot2::scale_x_continuous(limits = c(0, 1))
    sub <- paste(sub, "| E/N NA: no disclosed pairs")
  } else {
    if (isTRUE(budgets) && show == "E_over_N" && any(!is.na(pr$q))) {
      qd <- pr[!is.na(pr$q), , drop = FALSE]
      p <- p + ggplot2::geom_segment(data = qd, ggplot2::aes(x = .data$q, xend = .data$value, yend = .data$criterion), colour = "grey50") +
        ggplot2::geom_point(data = qd, ggplot2::aes(x = .data$q), shape = 124, size = 5, colour = "grey20")
    }
    if (show == "risk") p <- p + ggplot2::geom_vline(xintercept = tau, linetype = "dashed", colour = "grey40")
    p <- p + ggplot2::geom_point(ggplot2::aes(x = .data$value, size = .data$weight), colour = "#153653") +
      ggplot2::scale_size_area(max_size = 5, name = "weight") +
      ggplot2::scale_x_continuous(labels = scales::label_number(accuracy = 0.001))
    if (identical(fit$problem$settings$objective, "minimax") && any(pr$is_minimax_max))
      p <- p + ggplot2::geom_point(data = pr[pr$is_minimax_max, , drop = FALSE], ggplot2::aes(x = .data$value), shape = 1, size = 7, colour = "#D55E00")
  }
  p + .pr_labs(title = title, subtitle = sub, x = xlab, y = NULL,
    caption = "E_k/N = expected errors per disclosed pair (NA when nothing is disclosed). Dashed line (risk view) = tau, the all-tie risk.") +
    theme_postrank()
}

#' Plot the Disclosure, Error and Risk Frontier
#'
#' Stacked panels over the frontier grid (tau, or one error budget): the
#' disclosure rate `N/M` with the number of grades as point shape, the
#' per-criterion `E_k/N`, and the risk. Rows whose status is not `optimal` are
#' drawn hollow; rows without an incumbent keep their status in the subtitle
#' but get no point. Disclosure is nondecreasing in tau for exact optima with
#' all other settings fixed; recorded solver statuses and gaps do not establish
#' exact monotonicity for the displayed actions. Every criterion receives a color and line style;
#' style combinations are extended beyond seven criteria without dropping rows.
#' Criterion IDs may also be named `risk` or `N/M` without colliding with the
#' aggregate panels.
#'
#' @param x A `postrank_frontier`.
#' @param panels Which panels to draw, any of `"disclosure"`, `"error"`, `"risk"`.
#' @param highlight Optional value on the displayed horizontal axis (tau or
#'   the varied error budget), marked by a dashed line.
#' @param mark_uncertified Logical; draw rows whose recorded status is not
#'   `"optimal"` hollow. `FALSE` uses the ordinary point style for every row.
#'   This legacy argument name does not imply numerical certification.
#' @param ... Unused.
#' @return A `ggplot` object.
#' @seealso [postrank_frontier()]
#' @concept visualization
#' @examples
#' if (requireNamespace("highs", quietly = TRUE)) {
#'   pw <- postrank_pairwise(postrank_toy)
#'   fr <- postrank_frontier(pw, c(need_A = .6, need_B = .4), tau = c(.1, .25, .4), G_max = 3L,
#'     backend = "highs", control = list(time_limit = 10))
#'   postrank_plot_frontier(fr)
#' }
#' @export
postrank_plot_frontier <- function(x, panels = c("disclosure", "error", "risk"), highlight = NULL, mark_uncertified = TRUE, ...) {
  .pr_assert(inherits(x, "postrank_frontier"), "x must be a postrank_frontier", "wrong_class", "$.x")
  .pr_assert(is.character(panels) && length(panels) >= 1L && all(panels %in% c("disclosure", "error", "risk")) && !anyDuplicated(panels),
    "panels must be a subset of disclosure, error, risk", "invalid_display", "$.panels")
  t <- x$table
  axis <- if (is.null(x$q_criterion)) "tau" else "q_value"
  ks <- sub("^E_over_N_", "", grep("^E_over_N_", names(t), value = TRUE))
  ok <- !is.na(t$G)
  cert <- t$status == "optimal"
  rows <- list()
  tau_lab <- paste0("tau = ", format(t$tau))
  if ("disclosure" %in% panels) rows[[length(rows) + 1L]] <- data.frame(x = t[[axis]], panel = "disclosure N/M", series = "N/M",
    value = t$disclosure_rate, G = t$G, certified = cert, tau_lab = tau_lab, stringsAsFactors = FALSE)
  if ("error" %in% panels) for (k in ks) rows[[length(rows) + 1L]] <- data.frame(x = t[[axis]], panel = "error E_k/N",
    series = k, value = t[[paste0("E_over_N_", k)]], G = t$G, certified = cert, tau_lab = tau_lab, stringsAsFactors = FALSE)
  if ("risk" %in% panels) rows[[length(rows) + 1L]] <- data.frame(x = t[[axis]], panel = "risk", series = "risk",
    value = t$primary_risk, G = t$G, certified = cert, tau_lab = tau_lab, stringsAsFactors = FALSE)
  d <- do.call(rbind, rows); d <- d[!is.na(d$value), , drop = FALSE]
  title <- "Disclosure, error and risk frontier"
  if (!nrow(d)) return(.pr_status_panel(title, "no grid point has a value for the selected panels (no incumbent, or nothing disclosed)"))
  # On a q grid, rows with different tau are different losses: they get separate panels, never one line.
  by_tau <- axis == "q_value" && length(unique(t$tau)) > 1L
  d$panel <- factor(d$panel, levels = c("disclosure N/M", "error E_k/N", "risk")[c("disclosure", "error", "risk") %in% panels])
  d$G <- factor(d$G); if (!isTRUE(mark_uncertified)) d$certified <- TRUE
  missing <- t[!ok, , drop = FALSE]
  sub <- sprintf("%d grid points over %s", nrow(t), if (axis == "tau") "tau" else paste0("q_", x$q_criterion))
  if (axis == "q_value") sub <- paste0(sub, if (by_tau) " | one panel column per tau (different losses)" else paste0(" | tau ", format(unique(t$tau))))
  shapes <- c(16, 17, 15, 18, 3, 4, 8, 7, 9, 10, 12, 13, 14, 0, 1, 2, 5, 6)
  many_G <- nlevels(d$G) > length(shapes)
  if (many_G) sub <- paste0(sub, " | grade counts G in the table (more than ", length(shapes), " values)")
  if (nrow(missing)) sub <- paste0(sub, sprintf(" | %d without incumbent (%s)", nrow(missing), paste(unique(missing$status), collapse = ", ")))
  if (!is.null(highlight)) sub <- paste0(sub, " | highlighted ", axis, " = ", format(highlight))
  # Internal keys separate criterion IDs from the two aggregate metric labels.
  criterion_keys <- paste0("criterion:", seq_along(ks))
  d$series_id <- ifelse(as.character(d$panel) == "error E_k/N", criterion_keys[match(d$series, ks)],
    ifelse(as.character(d$panel) == "risk", "metric:risk", "metric:disclosure"))
  colours <- c("#0072B2", "#E69F00", "#009E73", "#CC79A7", "#56B4E9", "#D55E00", "#F0E442")
  if (length(ks) > length(colours)) colours <- grDevices::hcl.colors(length(ks), "Dark 3")
  lines <- rep_len(c("solid", "dashed", "dotted", "dotdash", "longdash", "twodash", "11"), length(ks))
  d$line_group <- if (by_tau) paste(d$series_id, d$tau_lab) else d$series_id
  d$line_group <- factor(d$line_group, levels = unique(d$line_group[order(d$series, d$tau_lab, method = "radix")]))
  p <- ggplot2::ggplot(d, ggplot2::aes(x = .data$x, y = .data$value, group = .data$line_group)) +
    ggplot2::geom_line(ggplot2::aes(colour = .data$series_id, linetype = .data$series_id), linewidth = 0.5) +
    (if (many_G) ggplot2::geom_point(data = d[d$certified, , drop = FALSE], ggplot2::aes(colour = .data$series_id), shape = 16, size = 2)
     else ggplot2::geom_point(data = d[d$certified, , drop = FALSE], ggplot2::aes(colour = .data$series_id, shape = .data$G), size = 2)) +
    ggplot2::geom_point(data = d[!d$certified, , drop = FALSE], ggplot2::aes(colour = .data$series_id), shape = 1, size = 2.4) +
    (if (by_tau) ggplot2::facet_grid(panel ~ tau_lab, scales = "free_y") else ggplot2::facet_wrap(~ panel, scales = "free_y", ncol = 1)) +
    ggplot2::scale_colour_manual(values = c(`metric:disclosure` = "grey30", `metric:risk` = "grey30",
      stats::setNames(colours[seq_along(ks)], criterion_keys)),
      breaks = criterion_keys, labels = ks, name = "criterion") +
    ggplot2::scale_linetype_manual(values = c(`metric:disclosure` = "solid", `metric:risk` = "solid",
      stats::setNames(lines, criterion_keys)), breaks = criterion_keys, labels = ks, name = "criterion") +
    ggplot2::scale_shape_manual(values = shapes[seq_len(min(nlevels(d$G), length(shapes)))], name = "grades G", drop = FALSE) +
    .pr_labs(title = title, subtitle = sub, x = if (axis == "tau") expression(tau) else paste0("q_", x$q_criterion), y = NULL,
      caption = paste(if (axis == "tau") "Each grid point is a separate loss and solve." else
        "Each grid point is a separate solve under its error budget. Changing q changes the feasible set; changing tau changes the loss.",
        "For exact optima at fixed other settings, disclosure never falls as tau rises;",
        "solver rows keep their status and gap, so filled points do not establish exact monotonicity. Hollow = not optimal.")) +
    theme_postrank()
  if (!is.null(highlight)) p <- p + ggplot2::geom_vline(xintercept = highlight, linetype = "dashed", colour = "grey40")
  p
}

#' Plot the Cost of a Common Grade by Criterion
#'
#' One row per criterion with the stored commonality cost interval in risk
#' units: a hollow point at `cost_lower` and a segment to `cost_upper` when the
#' own-solve lower bound exists, with a zero reference line. The interval is
#' derived from the own-solve incumbent and lower bound and inherits their
#' numerical limitations; the own incumbent is not a certified minimum.
#'
#' @param x A `postrank_commonality_cost`.
#' @param ... Unused.
#' @return A `ggplot` object.
#' @seealso [postrank_commonality_cost()]
#' @concept visualization
#' @examples
#' if (requireNamespace("highs", quietly = TRUE)) {
#'   fit <- postrank(postrank_toy, weights = c(need_A = .6, need_B = .4), tau = .25,
#'     G_max = 3L, backend = "highs", fragility = FALSE)
#'   postrank_plot_commonality(postrank_commonality_cost(fit, backend = "highs"))
#' }
#' @export
postrank_plot_commonality <- function(x, ...) {
  .pr_assert(inherits(x, "postrank_commonality_cost"), "x must be a postrank_commonality_cost", "wrong_class", "$.x")
  d <- x$table; d$criterion_id <- factor(d$criterion_id, levels = rev(d$criterion_id))
  no_upper <- d$criterion_id[is.na(d$cost_upper)]
  s <- x$settings
  sub <- sprintf("tau %s | grade cap %s | protection = %s", format(s$tau), s$G_max, x$protection)
  if (length(no_upper)) sub <- paste0(sub, " | upper bound unavailable: ", paste(no_upper, collapse = ", "))
  ggplot2::ggplot(d, ggplot2::aes(y = .data$criterion_id)) +
    ggplot2::geom_vline(xintercept = 0, colour = "grey50") +
    ggplot2::geom_segment(data = d[!is.na(d$cost_upper), , drop = FALSE],
      ggplot2::aes(x = .data$cost_lower, xend = .data$cost_upper, yend = .data$criterion_id), colour = "#153653", linewidth = 0.8) +
    ggplot2::geom_point(ggplot2::aes(x = .data$cost_lower), shape = 21, fill = "white", colour = "#153653", size = 2.6) +
    ggplot2::scale_x_continuous(labels = scales::label_number(accuracy = 0.0001)) +
    .pr_labs(title = "Cost of a common grade by criterion", subtitle = sub, x = "commonality cost (risk units)", y = NULL,
      caption = "Cost compares the common action with the criterion family minimum. The interval is derived from the own-solve incumbent and lower bound and inherits their numerical limitations.") +
    theme_postrank()
}
