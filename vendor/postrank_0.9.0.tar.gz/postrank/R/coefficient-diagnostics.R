# Typed diagnostics concern conditional EXPECTED risks, never latent loss draws.
.pr_cf_history_layout <- function(index, history) {
  if (is.null(history)) return(list(reason = "missing_original_chain_history", rows = NULL))
  .pr_assert(is.list(history) && !is.data.frame(history) && length(history) > 0L,
    "chain_history must be explicit original retained-history records", "invalid_coefficient_history")
  .pr_cf_attrs(history, "names", "chain_history has hidden attributes")
  ids <- vapply(history, function(h) {
    .pr_cf_record(h, c("chain_id", "retained_iterations"))
    .pr_cf_numeric(h$chain_id, character()); .pr_safe_integer(h$chain_id, TRUE)
    .pr_assert(length(h$chain_id) == 1L, "history chain_id must be scalar", "invalid_coefficient_history")
    .pr_cf_numeric(h$retained_iterations, character()); .pr_safe_integer(h$retained_iterations, TRUE)
    .pr_assert(length(h$retained_iterations) > 0L && !anyDuplicated(h$retained_iterations) &&
      all(diff(h$retained_iterations) > 0), "retained history must be ordered and unique", "invalid_coefficient_history")
    as.numeric(h$chain_id)
  }, numeric(1))
  .pr_assert(!anyDuplicated(ids) && setequal(ids, index$chain_id),
    "history must cover exactly the original chains", "invalid_coefficient_history")
  rows <- lapply(seq_along(ids), function(c) {
    positions <- which(index$chain_id == ids[c])
    positions <- positions[order(index$iteration[positions])]
    .pr_assert(identical(as.numeric(index$iteration[positions]), as.numeric(history[[c]]$retained_iterations)),
      "source coordinates and retained history disagree", "invalid_coefficient_history")
    positions
  })
  lengths <- lengths(rows)
  reason <- if (length(ids) < 2L) "insufficient_original_chains" else if (length(unique(lengths)) != 1L)
    "unequal_chain_lengths" else if (any(lengths < 4L)) "insufficient_retained_iterations" else NULL
  if (is.null(reason)) {
    gaps <- lapply(history, function(h) diff(h$retained_iterations))
    if (any(vapply(gaps, function(g) length(unique(g)) != 1L, logical(1))) ||
        length(unique(vapply(gaps, function(g) g[1L], numeric(1)))) != 1L) reason <- "irregular_or_different_retained_spacing"
  }
  list(reason = reason, rows = if (is.null(reason)) do.call(cbind, rows) else NULL,
       chain_ids = ids, chain_lengths = lengths, original_history = history,
       history_structure_checked = TRUE, history_truth_verified = FALSE)
}

.pr_cf_risk_trace <- function(x, grade, settings, max_trace_bytes) {
  S <- length(x$source$components); K <- length(x$criterion_ids)
  required <- 8 * as.double(S) * (as.double(K) + 1)
  .pr_assert(required <= max_trace_bytes, "conditional-risk trace memory guard exceeded", "coefficient_trace_budget_exceeded")
  criterion <- matrix(0, S, K, dimnames = list(state = names(x$source$components), criterion = x$criterion_ids))
  weighted <- stats::setNames(numeric(S), names(x$source$components))
  M <- choose(length(grade), 2); disclosed <- outer(unname(grade), unname(grade), `<`); N <- sum(disclosed)
  for (s in seq_len(S)) {
    h <- x$source$components[[s]]
    projected <- .pr_cf_project_gaussian(list(kind = "gaussian_conditional", means = h$means,
      covariance = h$covariance, conditional_independence = x$source$conditional_independence))
    E <- vapply(seq_len(K), function(k) sum(projected$e[, , k][disclosed]), numeric(1))
    criterion[s, ] <- (E + settings$tau * (M - N)) / M
    weighted[s] <- (sum(settings$weights * E) + settings$tau * (M - N)) / M
  }
  list(quantity = "RB_conditional_expected_weighted_risk", values = weighted,
       criterion_values = criterion, state_index = x$source$state_index,
       weights = x$source$weights, weighted_mean = sum(x$source$weights * weighted),
       structural_constant_from_action = N == 0,
       interpretation = "Conditional expected risk given each shared hyperstate; not realized target loss draws or target-loss quantiles.")
}

#' Diagnose Conditional Expected Risks of Typed Coefficients
#'
#' Gaussian inputs have no invented MC trace or zero MCSE. Fixed finite
#' mixtures have weighted conditional-risk summaries, not Monte Carlo target
#' states. Hyperparameter MCMC may have descriptive conditional expected-risk
#' metrics through optional posterior functions. These concern hyperstate
#' integration, not realized target loss, target quantiles, or post-selection
#' guarantees.
#'
#' Metrics require explicit history matching all retained original source
#' coordinates, at least two chains and four iterations per chain, equal
#' lengths, and regular common spacing. There is no truncation, padding or
#' interpolation. History structure does not verify its truth, sampler
#' execution or convergence. For supplied fits the original primal is
#' independently revalidated against the same problem, and the released grade
#' must match the revalidated grade. The trace-memory guard bounds numeric
#' output buffers, not total process memory. Missing history, unavailable
#' optional libraries, short/unequal chains and raw `NA`/`NaN`/`Inf` metrics
#' retain explicit reasons. [postrank_diagnose()] dispatches typed inputs here
#' using default missing-history behavior; use this dedicated function to
#' supply history. Target pair-indicator traces, stability solves, cross-fit,
#' target MC-fragility and IID target coefficient bounds are unsupported.
#'
#' @param x Validated Gaussian or shared-state typed coefficients.
#' @param fit Optional same-input fit with validated problem/settings/grade.
#' @param grade Optional named fixed grade, consistent with `fit` when supplied.
#' @param settings Explicit weighted loss settings for a fixed grade without
#'   `fit`.
#' @param chain_history Original records with `chain_id` and ordered
#'   `retained_iterations`; required for eligible hyperparameter-MCMC
#'   conditional-risk metrics.
#' @param max_trace_bytes Operational bound on numeric conditional-risk output
#'   buffers.
#' @return A `postrank_coefficient_diagnostics` object, with explicit available
#'   or unavailable raw metric records, conditional expected-risk traces where
#'   defined, and scientific truth flags remaining `FALSE`. It is never a
#'   statistical certificate.
#' @seealso [postrank_diagnose()], [postrank_coefficient_capabilities()],
#'   [postrank_report()] for displaying prepared diagnostics without recomputation.
#' @examples
#' ids <- c("A", "B"); ks <- "k1"
#' means <- matrix(c(-.2, .4), 2, 1, dimnames = list(entity = ids, criterion = ks))
#' covariance <- array(.5, c(1, 1, 2),
#'   dimnames = list(criterion_i = ks, criterion_j = ks, entity = ids))
#' provenance <- list(producer_id = "documentation-example", producer_version = "1",
#'   posterior_id = "fixed-toy-gaussian-law", input_payload_sha256 = strrep("a", 64),
#'   source_sha256 = strrep("b", 64), config_sha256 = strrep("c", 64))
#' x <- postrank_gaussian_coefficients(means, covariance,
#'   "entities_given_shared_h", provenance)
#' d <- postrank_coefficient_diagnose(x, grade = c(A = 1L, B = 2L),
#'   settings = list(weights = c(k1 = 1), tau = .25, G_max = 2L))
#' d$evaluation$weighted_risk
#' d$diagnostics$mcse_mean$unavailable_reason
#' @concept coefficients
#' @export
postrank_coefficient_diagnose <- function(x, fit = NULL, grade = NULL, settings = NULL,
    chain_history = NULL, max_trace_bytes = 8 * 1024^2) {
  .pr_cf_diagnose(x, fit, grade, settings, NULL, NULL, chain_history, max_trace_bytes)
}

.pr_cf_diagnose <- function(x, fit = NULL, grade = NULL, settings = NULL, pairs = NULL,
    stability = NULL, chain_history = NULL, max_trace_bytes = 8 * 1024^2) {
  validate_postrank_coefficients(x)
  .pr_assert(is.null(pairs) && is.null(stability),
    "typed coefficients do not support target pair-indicator traces or stability solves", "unsupported_coefficient_diagnostic")
  .pr_assert(typeof(max_trace_bytes) %in% c("integer", "double") && length(max_trace_bytes) == 1L &&
    is.null(attributes(max_trace_bytes)) && is.finite(max_trace_bytes) && max_trace_bytes >= 0 &&
    max_trace_bytes == floor(max_trace_bytes), "max_trace_bytes must be a finite nonnegative integer", "invalid_coefficient_diagnostic")
  problem_identity <- NULL
  if (!is.null(fit)) {
    .pr_assert(inherits(fit, "postrank_fit"), "expected postrank_fit", "invalid_fit")
    .pr_validate_problem(fit$problem)
    .pr_assert(identical(fit$input_identity, x$input_identity) &&
      identical(fit$problem$input_identity, x$input_identity) && identical(fit$problem_identity, fit$problem$problem_identity),
      "fit and coefficient input/problem identity differ", "diagnostic_input_mismatch")
    .pr_assert(identical(fit$settings, fit$problem$settings), "fit settings changed", "stale_fit")
    if (!is.null(settings)) .pr_assert(identical(.pr_diagnostic_settings(settings, x, reference = fit$settings), fit$settings),
      "additional settings disagree with fit", "diagnostic_settings_mismatch")
    settings <- fit$settings; problem_identity <- fit$problem_identity
    if (!is.null(grade)) .pr_assert(!is.null(fit$grade) &&
      identical(canonical_postrank_grade(grade, x$entity_ids), fit$grade), "explicit grade disagrees with fit", "diagnostic_grade_mismatch")
    grade <- if (isTRUE(fit$incumbent_validated)) fit$grade else NULL
    if (isTRUE(fit$incumbent_validated)) {
      independently_checked <- validate_postrank_solution(fit$problem, fit$raw_solution, fit$solution_validation$tolerances)
      .pr_assert(isTRUE(independently_checked$valid) && !is.null(grade) &&
        identical(grade, independently_checked$grade) && identical(grade, fit$solution_validation$grade),
        "fit grade or primal changed after independent validation", "stale_fit")
    }
  } else if (!is.null(grade)) {
    grade <- canonical_postrank_grade(grade, x$entity_ids)
    .pr_assert(!is.null(settings), "fixed grade requires loss settings", "missing_diagnostic_settings")
    settings <- .pr_diagnostic_settings(settings, x, grade)
  } else .pr_assert(is.null(settings), "settings without a fixed grade are ambiguous", "invalid_diagnostic_settings")
  evaluation <- if (is.null(grade)) NULL else postrank_evaluate(grade, x, settings$weights, settings$tau)
  mixture <- identical(x$input_kind, "shared_hyperstate_mixture")
  mcmc <- mixture && identical(x$source$source_regime, "hyperparameter_mcmc")
  .pr_assert(is.null(chain_history) || mcmc, "chain history only applies to declared hyperparameter MCMC", "invalid_coefficient_history")
  trace <- NULL; layout <- NULL
  reason <- if (is.null(grade)) "no_fixed_grade" else if (!mixture) "analytic_Gaussian_no_hyperstate_MC_trace" else
    if (!mcmc) "fixed_finite_mixture_MC_not_used" else NULL
  if (mixture && !is.null(grade)) {
    trace <- .pr_cf_risk_trace(x, grade, settings, max_trace_bytes)
    .pr_assert(abs(trace$weighted_mean - evaluation$weighted_risk) <= 1e-12,
      "conditional-risk trace mean differs from public fixed-action evaluation", "coefficient_trace_projection_mismatch")
    if (mcmc) { layout <- .pr_cf_history_layout(x$source$state_index, chain_history); reason <- layout$reason }
  }
  metrics <- if (!is.null(reason)) .pr_unavailable_diagnostics(reason) else {
    matrix <- matrix(trace$values[layout$rows], nrow = nrow(layout$rows), ncol = ncol(layout$rows))
    .pr_mcmc_trace_metrics(matrix)
  }
  mcse <- metrics$mcse_mean
  out <- list(schema_version = "coefficient-diagnostics-0.1.0", input_identity = x$input_identity,
    problem_identity = problem_identity, input_kind = x$input_kind, grade = grade, settings = settings,
    evaluation = evaluation, conditional_risk_trace = trace, diagnostics = metrics,
    layout = layout, unavailable_reason = if (!is.null(reason)) reason else mcse$unavailable_reason,
    conditional_risk_mcse_available = isTRUE(mcse$available),
    conditional_risk_mcse_unavailable_reason = mcse$unavailable_reason,
    target_loss_trace = list(available = FALSE, reason = "no_latent_target_draws"),
    target_quantiles = list(available = FALSE, reason = "target_state_quantiles_not_implemented"),
    provenance = x$provenance, validation = x$validation, capabilities = x$capabilities,
    post_selection_descriptive = !is.null(fit), convergence_verified = FALSE,
    finite_sample_certificate = FALSE, numerical_certification = FALSE,
    interpretation = c("RB conditional-risk MCSE concerns integration over hyperstates, not target-loss dispersion.",
      "History structure and finite metrics do not establish actual sampling, stationarity or convergence.",
      "A structurally constant all-withheld risk does not diagnose target exploration."))
  class(out) <- c("postrank_coefficient_diagnostics", "list"); out
}
