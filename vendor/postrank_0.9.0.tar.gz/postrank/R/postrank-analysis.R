# The one-call path (Chapter 11) and its composite result postrank_analysis
# (Chapter 10). Legacy objects are nested unchanged; every added declaration summary,
# display cache, capability record and note lives in analysis$metadata.

.pr_analysis_fields <- c("input", "pairwise", "settings", "control", "problem", "fit", "evaluation", "report_card",
  "fragility", "crossfit", "diagnostics", "backend", "metadata", "extras", "timings", "schema_version",
  "provenance", "warnings")
.pr_extra_names <- c("report_card", "fragility", "crossfit", "diagnostics")
.pr_extra_fields <- c("requested", "supported", "available", "reason", "condition")

# Input kind and the capability table of Chapter 11.
.pr_input_kind <- function(x) {
  if (inherits(x, "postrank_coefficients")) return(x$input_kind)
  if (identical(x$input_kind, "exact_finite_posterior")) return("exact_finite_law")
  if (identical(x$dependence_mode, "joint_model")) return(paste0("joint_", x$joint_draws$sampling$regime))
  "criterionwise"
}
.pr_capabilities <- function(x) {
  kind <- .pr_input_kind(x); joint <- kind %in% c("joint_iid", "joint_mcmc")
  list(input_kind = kind, can_report_card = TRUE, can_fragility = joint, can_crossfit = joint, can_diagnostics = TRUE,
    interval_source = .pr_summary_source(x))
}

.pr_as_typed_control <- function(control) {
  if (inherits(control, "postrank_control")) { .pr_validate_control(control); return(control) }
  cc <- .pr_core_control(control, NULL)
  postrank_control(time_limit = cc$core$time_limit, threads = cc$core$threads, seed = cc$core$seed,
    absolute_risk_gap = cc$core$absolute_risk_gap, relative_gap = cc$core$relative_gap, strategy = cc$strategy,
    engine = cc$core$engine, verbose = cc$verbose, output = cc$core$output, tolerances = cc$core$tolerances)
}

.pr_declaration_summary <- function(x) {
  if (inherits(x, "postrank_coefficients"))
    return(list(status = "declared", source = "postrank_coefficients", kind = x$input_kind,
      conditional_independence = x$source$conditional_independence, provenance = x$provenance,
      note = "Declarations are recorded as supplied; they are not scientifically verified."))
  list(status = "declared", source = "postrank_draws", kind = .pr_input_kind(x),
    targets = lapply(x$targets, function(t) t[intersect(c("criterion_id", "estimand", "units", "source_transform"), names(t))]),
    context = x$context, identification = x$identification$note, tie_justification = x$tie_policy$justification,
    provenance = x$provenance[intersect(c("producer", "artifact_id", "created_at"), names(x$provenance))],
    note = "Declarations are recorded as supplied; they are not scientifically verified.")
}

.pr_extra_record <- function(requested, supported, available = FALSE, reason = NULL, condition = NULL)
  list(requested = isTRUE(requested), supported = isTRUE(supported), available = isTRUE(available),
    reason = reason, condition = condition)

#' Grade Entities from a Posterior in One Call
#'
#' Validates the input, aggregates (or passes through) the directional-error
#' coefficients, binds the policy, builds the problem, solves it **once**, and
#' then builds the supported extras. The result is a `postrank_analysis`
#' envelope that nests the unchanged legacy objects (`pairwise`, `problem`,
#' `fit`) next to the typed `settings` and `control`.
#'
#' **Backend.** `backend = NULL` resolves to `getOption("postrank.backend")`,
#' then to Gurobi. An unavailable backend is an error naming both remedies;
#' there is no fallback. Use `backend = "highs"` for a license-free run.
#'
#' **Without a validated incumbent** (for example a time limit before any
#' validated grade) the fit, its status, bounds and warnings are kept, while
#' `evaluation`, `report_card` and every grade-dependent extra are `NULL` with
#' reason `"no_validated_incumbent"`. An all-tie grade is a valid incumbent.
#'
#' **Extras** (capability-gated; `extras` records `requested`, `supported`,
#' `available`, `reason` and `condition` for each): the report card (default
#' on, every input kind); Monte Carlo fragility (default on, joint equal-weight
#' IID/MCMC draws only); cross-fit (off by default, two extra solves, joint
#' draws only); diagnostics (off by default; typed coefficients dispatch to
#' [postrank_coefficient_diagnose()]). An unexpected error in an extra keeps
#' the valid fit, records `reason = "extra_error"` with the condition, and adds
#' a warning. Core input, backend and solve errors still stop.
#'
#' @param x A validated `postrank_draws` or Gaussian/mixture
#'   `postrank_coefficients` object.
#' @param weights,tau,G_max The policy, when `settings` is not given.
#' @param ... Only `q`, `exact_G`, `objective`, `minimax_criteria` and
#'   `minimax_refine` (as in [postrank_settings()]).
#' @param settings A [postrank_settings()] object instead of the loose policy
#'   arguments; supplying both is a `settings_conflict` error.
#' @param backend `NULL`, `"gurobi"` or `"highs"`.
#' @param control A [postrank_control()] object or a bare control list.
#' @param report_card,fragility,crossfit,diagnostics Logical requests for the
#'   extras.
#' @param level Central interval level of the report card, in `(0, 1)`.
#' @return A `postrank_analysis` list containing `input`, `pairwise`, typed
#'   `settings` and `control`, `problem`, and the single solved `fit`.
#'   `evaluation` is the stored fixed-action evaluation; `report_card`,
#'   `fragility`, `crossfit` and `diagnostics` hold the prepared extras or
#'   `NULL`. Each entry of `extras` records `requested`, `supported`,
#'   `available`, `reason` and `condition`; inspect it before using an extra.
#'   `backend`, `timings`, `provenance` and `warnings` describe the run.
#'   `metadata` holds declaration/capability summaries and display caches;
#'   `schema_version` identifies this envelope. The nested legacy objects
#'   retain their own schemas. Prefer [get_grades()], [get_risk()] and
#'   [get_profile()] when only the action or its metrics are needed.
#'
#'   With no validated incumbent, `evaluation` and grade-dependent extras
#'   are `NULL`, not an all-tie action. An extra that fails (for example an
#'   unrepresentable posterior interval) is recorded as `extra_error` while
#'   the valid fit is retained. Core failures, including
#'   a `postrank_backend_unavailable` condition or `settings_conflict`, still
#'   stop the call.
#' @seealso [postrank_settings()], [postrank_control()], [get_grades()],
#'   [postrank_report_card()], [postrank_solve()]
#' @concept decision
#' @examples
#' if (requireNamespace("highs", quietly = TRUE)) {
#'   fit <- postrank(postrank_toy, weights = c(need_A = .6, need_B = .4), tau = .25,
#'     G_max = 3L, backend = "highs", control = postrank_control(time_limit = 10))
#'   get_grades(fit)
#'   get_risk(fit)
#' }
#' @export
postrank <- function(x, weights = NULL, tau = 0.25, G_max = 4L, ..., settings = NULL, backend = NULL,
                     control = postrank_control(), report_card = TRUE, fragility = TRUE, crossfit = FALSE,
                     diagnostics = FALSE, level = 0.90) {
  started <- proc.time()[["elapsed"]]
  dots <- list(...)
  allowed_dots <- c("q", "exact_G", "objective", "minimax_criteria", "minimax_refine")
  .pr_assert(!length(dots) || (!is.null(names(dots)) && all(nzchar(names(dots))) && all(names(dots) %in% allowed_dots)),
    paste("... may contain only", paste(allowed_dots, collapse = ", ")), "invalid_settings", "$...")
  for (f in c("report_card", "fragility", "crossfit", "diagnostics"))
    .pr_assert(is.logical(get(f)) && length(get(f)) == 1L && !is.na(get(f)), paste(f, "must be TRUE or FALSE"), "invalid_request", paste0("$.", f))
  level <- .pr_level(level)
  # Input.
  if (inherits(x, "postrank_coefficients")) validate_postrank_coefficients(x) else {
    .pr_assert(inherits(x, "postrank_draws"), "x must be a postrank_draws or postrank_coefficients object; see postrank_draws()",
      "invalid_input", "$")
    x <- as_postrank_draws(x)
  }
  # Policy.
  if (is.null(settings)) {
    .pr_assert(!is.null(weights), "weights are required unless settings is supplied", "invalid_weights", "$.weights")
    settings <- do.call(postrank_settings, c(list(weights = weights, tau = tau, G_max = G_max), dots))
  } else {
    .pr_settings_conflict(c(.pr_supplied(c("weights", "tau", "G_max")), names(dots)))
    .pr_validate_settings(settings)
  }
  ctrl <- .pr_as_typed_control(control)
  resolved <- .pr_resolve_backend(backend)
  t <- c(pairwise = NA_real_, build = NA_real_, solve = NA_real_, validate = NA_real_, extras = NA_real_)
  tick <- function() proc.time()[["elapsed"]]
  .pr_with_resolution(resolved, {
    s0 <- tick(); pw <- postrank_pairwise(x); t[["pairwise"]] <- tick() - s0
    s0 <- tick(); bound <- .pr_settings_bind(settings, pw); problem <- postrank_problem(pw, settings = bound$settings)
    t[["build"]] <- tick() - s0
    s0 <- tick(); fit <- postrank_solve(problem, backend = resolved$name, control = ctrl); t[["solve"]] <- tick() - s0
  })
  s0 <- tick()
  .pr_validate_problem(problem)
  .pr_assert(identical(fit$problem_identity, problem$problem_identity), "fit and problem identities disagree", "invalid_analysis")
  has_grade <- isTRUE(fit$incumbent_validated) && !is.null(fit$grade)
  evaluation <- if (has_grade) fit$evaluation else NULL
  t[["validate"]] <- tick() - s0
  caps <- .pr_capabilities(x)
  requested <- list(report_card = report_card, fragility = fragility, crossfit = crossfit, diagnostics = diagnostics)
  supported <- list(report_card = caps$can_report_card, fragility = caps$can_fragility, crossfit = caps$can_crossfit,
    diagnostics = caps$can_diagnostics)
  results <- stats::setNames(vector("list", 4L), .pr_extra_names)
  extras <- stats::setNames(vector("list", 4L), .pr_extra_names)
  warns <- c(fit$warnings, bound$settings$warnings)
  summaries <- NULL
  s0 <- tick()
  for (e in .pr_extra_names) {
    rec <- .pr_extra_record(requested[[e]], supported[[e]])
    if (!requested[[e]]) rec$reason <- "not_requested"
    else if (!has_grade) rec$reason <- "no_validated_incumbent"
    else if (!supported[[e]]) rec$reason <- "unsupported_input_kind"
    else {
      value <- tryCatch(.pr_with_resolution(resolved, switch(e,
        report_card = {
          summaries <- .pr_posterior_summaries(x, level)
          .pr_report_card_build(fit, summaries, "expected_rank")
        },
        fragility = postrank_mc_fragility(x, fit = fit),
        crossfit = postrank_crossfit(x, fit = fit, backend = resolved$name, control = ctrl),
        diagnostics = postrank_diagnose(x, fit = fit))),
        error = function(err) structure(list(class = class(err), code = if (is.null(err$code)) NA_character_ else err$code,
          message = conditionMessage(err)), class = "postrank_extra_failure"))
      if (inherits(value, "postrank_extra_failure")) {
        rec$reason <- "extra_error"; rec$condition <- unclass(value)
        msg <- sprintf("The %s extra failed and is unavailable (%s); the fit is kept.", e, value$message)
        warns <- c(warns, msg); warning(msg, call. = FALSE)
      } else { results[[e]] <- value; rec$available <- TRUE }
    }
    extras[[e]] <- rec
  }
  t[["extras"]] <- tick() - s0
  input_identity <- .pr_input_identity_of(x)
  display_cache <- if (is.null(summaries)) list() else list(list(key = list(input_identity = input_identity,
    level = summaries$level, method = summaries$source), means = summaries$means, lower = summaries$lower, upper = summaries$upper))
  out <- list(input = x, pairwise = pw, settings = bound$settings, control = ctrl, problem = problem, fit = fit,
    evaluation = evaluation, report_card = results$report_card, fragility = results$fragility,
    crossfit = results$crossfit, diagnostics = results$diagnostics,
    backend = list(name = fit$backend$name, wrapper_version = if (is.null(fit$backend$wrapper_version)) NA_character_ else fit$backend$wrapper_version,
      solver_version = if (is.null(fit$backend$solver_version)) NA_character_ else fit$backend$solver_version,
      resolution = fit$backend$resolution, channel = fit$backend$channel),
    metadata = list(declarations = .pr_declaration_summary(x), display_cache = display_cache,
      capabilities = caps[c("can_report_card", "can_fragility", "can_crossfit", "can_diagnostics", "interval_source")],
      notes = character()),
    extras = extras, timings = t, schema_version = "1",
    provenance = .pr_provenance("postrank", backend = resolved$name, backend_resolution = resolved$resolution,
      total_seconds = tick() - started),
    warnings = unique(c(warns, unlist(lapply(results, function(v) if (is.list(v)) v$warnings else NULL), use.names = FALSE))))
  class(out) <- c("postrank_analysis", "list")
  .pr_validate_analysis(out)
  out
}

# Cached report-card summaries of an analysis, keyed by input identity, level and method.
.pr_cached_summaries <- function(x, level) {
  for (entry in x$metadata$display_cache) {
    k <- entry$key
    if (identical(k$input_identity, .pr_input_identity_of(x$input)) && isTRUE(all.equal(k$level, level)) &&
        identical(k$method, .pr_summary_source(x$input)))
      return(list(means = entry$means, lower = entry$lower, upper = entry$upper, source = k$method, level = k$level,
        input_identity = k$input_identity))
  }
  NULL
}

.pr_validate_analysis <- function(x) {
  .pr_assert(inherits(x, "postrank_analysis") && identical(names(x), .pr_analysis_fields),
    "expected a postrank_analysis with its documented ordered fields", "invalid_analysis")
  input_identity <- .pr_input_identity_of(x$input)
  .pr_assert(identical(x$pairwise$input_identity, input_identity) && identical(x$problem$input_identity, input_identity) &&
    identical(x$fit$input_identity, input_identity), "input, pairwise, problem and fit identities disagree", "invalid_analysis")
  .pr_assert(identical(x$fit$problem_identity, x$problem$problem_identity), "fit and problem identities disagree", "invalid_analysis")
  .pr_validate_settings(x$settings); .pr_validate_control(x$control)
  has_grade <- isTRUE(x$fit$incumbent_validated) && !is.null(x$fit$grade)
  if (has_grade) .pr_assert(identical(x$evaluation$grade, x$fit$grade), "evaluation grade differs from the fit grade", "invalid_analysis")
  else .pr_assert(is.null(x$evaluation) && is.null(x$report_card) && is.null(x$fragility) && is.null(x$crossfit) &&
    is.null(x$diagnostics), "without a validated incumbent every grade-dependent result must be NULL", "invalid_analysis")
  .pr_assert(identical(names(x$extras), .pr_extra_names), "extras must record the four stages in order", "invalid_analysis")
  for (e in .pr_extra_names) {
    r <- x$extras[[e]]
    .pr_assert(identical(names(r), .pr_extra_fields), paste("extra record", e, "has unexpected fields"), "invalid_analysis")
    .pr_assert(identical(r$available, !is.null(x[[e]])), paste("extra", e, "availability disagrees with its value"), "invalid_analysis")
    if (r$available) .pr_assert(is.null(r$reason) && is.null(r$condition), paste("available extra", e, "carries a reason"), "invalid_analysis")
    else .pr_assert(is.character(r$reason) && length(r$reason) == 1L, paste("unavailable extra", e, "needs a reason"), "invalid_analysis")
    v <- x[[e]]
    if (!is.null(v) && !is.null(v$input_identity))
      .pr_assert(identical(v$input_identity, input_identity), paste("extra", e, "has a different input identity"), "invalid_analysis")
  }
  .pr_assert(identical(.pr_policy_key(.pr_settings_bind(x$settings, x$pairwise)$policy), .pr_policy_key(x$problem$settings)),
    "typed settings disagree with the problem's policy", "invalid_analysis")
  caps <- .pr_capabilities(x$input)
  for (e in .pr_extra_names) .pr_assert(identical(x$extras[[e]]$supported, isTRUE(caps[[paste0("can_", e)]])),
    paste("extra", e, "support disagrees with the capability table"), "invalid_analysis")
  if (!is.null(x$report_card)) .pr_assert(identical(x$report_card$grade_identity, x$fit$solution_identity$relation_identity) &&
    identical(x$report_card$input_identity, input_identity), "report card belongs to another grade or input", "invalid_analysis")
  .pr_assert(identical(names(x$timings), c("pairwise", "build", "solve", "validate", "extras")) && is.numeric(x$timings),
    "timings must record pairwise, build, solve, validate and extras", "invalid_analysis")
  .pr_assert(is.list(x$backend) && identical(names(x$backend), c("name", "wrapper_version", "solver_version", "resolution", "channel")),
    "backend record has unexpected fields", "invalid_analysis")
  .pr_assert(is.character(x$warnings) && is.list(x$provenance), "audit slots have unexpected types", "invalid_analysis")
  .pr_assert(identical(names(x$metadata), c("declarations", "display_cache", "capabilities", "notes")),
    "metadata must hold declarations, display_cache, capabilities and notes", "invalid_analysis")
  invisible(TRUE)
}
