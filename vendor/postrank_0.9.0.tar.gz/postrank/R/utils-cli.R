# Null default (base R >= 4.4 has %||%; defined here for R 4.1-4.3).
`%||%` <- function(x, y) if (is.null(x)) y else x

# Console helpers (Chapter 13 SPEC-13.1-13.4). Every formatter returns a character
# vector, has no side effect and recomputes nothing: it formats stored slots only.

.pr_cli_tier <- function(tier = NULL) {
  if (!is.null(tier)) {
    .pr_assert(length(tier) == 1L && !is.na(tier) && tier %in% 1:3, "tier must be 1, 2 or 3", "invalid_display", "$.tier")
    return(as.integer(tier))
  }
  if (isTRUE(getOption("knitr.in.progress"))) return(3L)
  if (cli::num_ansi_colors() > 1L && cli::is_dynamic_tty()) return(1L)
  2L
}
.pr_cli_width <- function(width = NULL) {
  if (is.null(width)) width <- getOption("width", 80L)
  .pr_assert(is.numeric(width) && length(width) == 1L && is.finite(width), "width must be a number", "invalid_display", "$.width")
  max(40L, as.integer(width))
}
.pr_cli_n_head <- function(n_head) {
  .pr_assert(is.numeric(n_head) && length(n_head) == 1L && is.finite(n_head) && n_head >= 1, "n_head must be a positive integer",
    "invalid_display", "$.n_head")
  as.integer(n_head)
}
.pr_cli_assert_class <- function(x, classes, formatter) {
  if (!inherits(x, classes)) .pr_abort(sprintf("%s() formats %s objects, not %s", formatter, paste(classes, collapse = " or "),
    class(x)[1L]), "wrong_class", "$.x")
  invisible(TRUE)
}

# Number policy (SPEC-13.3): risks/bounds 4 decimals; ratios/agreement 3; rates one-decimal
# percentages; gaps/tolerances/MCSE format(digits = 3); counts integer; NA verbatim.
.pr_fmt <- function(x, kind = c("risk", "ratio", "pct", "gap", "count", "num")) {
  kind <- match.arg(kind)
  if (is.null(x) || !length(x)) return("NA")
  vapply(x, function(v) {
    if (is.na(v)) return("NA")
    switch(kind,
      risk = formatC(v, digits = 4, format = "f", decimal.mark = "."),
      ratio = formatC(v, digits = 3, format = "f", decimal.mark = "."),
      pct = paste0(formatC(100 * v, digits = 1, format = "f", decimal.mark = "."), "%"),
      gap = if (v == 0) "0" else format(v, digits = 3, decimal.mark = ".", scientific = abs(v) < 1e-3),
      count = format(as.integer(round(v)), big.mark = ""),
      num = format(v, digits = 4, decimal.mark = "."))
  }, "")
}
.pr_cli_header <- function(class, phrase) paste0("<", class, ">  ", phrase)
.pr_cli_line <- function(...) paste0("  ", ...)
.pr_cli_pointer <- function(text) paste0("  i  ", text)
.pr_cli_warning_line <- function(w, width) {
  w <- unique(as.character(w)); w <- w[nzchar(w)]
  if (!length(w)) return(character())
  first <- paste0("  !  ", length(w), if (length(w) == 1L) " warning recorded: " else " warnings recorded; first: ", w[1L])
  if (nchar(first) > width) first <- paste0(substr(first, 1L, width - 3L), "...")
  first
}
# Wrap each line to the width; continuation lines are indented two more spaces.
.pr_cli_wrap <- function(lines, width) {
  unlist(lapply(lines, function(l) {
    if (nchar(l, type = "width") <= width) return(l)
    lead <- sub("^(\\s*(i  |!  )?).*$", "\\1", l)
    body <- substring(l, nchar(lead) + 1L)
    w <- strwrap(body, width = width - nchar(lead), exdent = 2L)
    c(paste0(lead, w[1L]), if (length(w) > 1L) paste0(strrep(" ", nchar(lead)), w[-1L]))
  }), use.names = FALSE)
}
# Tier 1 adds ANSI styling only; ansi_strip(tier 1) == tier 2 byte for byte (T-ux-07).
.pr_cli_style <- function(lines, tier) {
  if (!identical(tier, 1L)) return(lines)
  vapply(lines, function(l) {
    if (grepl("^<[A-Za-z_]+>", l)) {
      tok <- sub("^(<[A-Za-z_]+>).*$", "\\1", l); return(paste0(cli::style_bold(tok), substring(l, nchar(tok) + 1L)))
    }
    if (grepl("^  i  ", l)) return(cli::style_dim(l))
    if (grepl("^  !  ", l)) return(cli::col_yellow(l))
    if (grepl("status optimal", l, fixed = TRUE)) return(sub("optimal", cli::col_green("optimal"), l, fixed = TRUE))
    l
  }, "", USE.NAMES = FALSE)
}
.pr_cli_finish <- function(lines, width, tier) .pr_cli_style(.pr_cli_wrap(lines, width), tier)

# Contextual wording guard (SPEC-13.3): a lint aid for authored text, not a runtime filter.
# Flags misleading affirmative statements; allows negations and stored identifiers.
.pr_cli_guard <- function(text) {
  text <- tolower(paste(text, collapse = " "))
  text <- gsub("\\s+", " ", text)
  sentences <- unlist(strsplit(text, "(?<=[.;!?])\\s+", perl = TRUE))
  patterns <- c(unique_optimum = "\\bunique optim", no_error = "\\b(no error|error-free|without error)",
    certified = "\\bcertif(ied|icate)\\b", proves = "\\bprov(e|es|en|ed)\\b.*\\b(superior|optimal|better)\\b",
    guaranteed = "\\bguarantee[sd]?\\b")
  negation <- "\\b(not|never|without|cannot|isn't|is not|does not|unknown|false)\\b"
  hits <- character()
  for (s in sentences) for (nm in names(patterns)) {
    if (!grepl(patterns[[nm]], s, perl = TRUE)) next
    rest <- sub(patterns[[nm]], " ", s, perl = TRUE)   # the flagged phrase itself is not a negation
    if (!grepl(negation, rest, perl = TRUE)) hits <- c(hits, paste0(nm, ": ", trimws(s)))
  }
  unique(hits)
}
.pr_grade_sizes <- function(grade) {
  tab <- tabulate(unname(grade), nbins = max(grade))
  paste(tab, collapse = " / ")
}
.pr_members <- function(grade, entity_ids, width, max_n = 60L) {
  if (length(grade) > max_n) return(.pr_cli_line(sprintf("%d entities; membership in get_grades(x)", length(grade))))
  g <- grade[entity_ids]
  unlist(lapply(sort(unique(g)), function(k) {
    ids <- names(g)[g == k]
    prefix <- sprintf("  grade %d (%d): ", k, length(ids))
    budget <- 2L * width - nchar(prefix) - 12L
    used <- cumsum(nchar(ids) + 2L)
    keep <- max(1L, sum(used <= budget))
    text <- paste0(prefix, paste(ids[seq_len(keep)], collapse = ", "),
      if (keep < length(ids)) sprintf(" +%d more", length(ids) - keep) else "")
    .pr_cli_wrap(text, width)
  }), use.names = FALSE)
}
