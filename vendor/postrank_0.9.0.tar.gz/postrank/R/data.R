# Documentation of the bundled data (Chapter 14 DATA-14). Every object is built by a
# maintainer script in data-raw/ (not shipped) and saved as a fixed .rda; nothing is
# generated at installation or load time.

#' The 32-state IID toy posterior
#'
#' A small validated `postrank_draws` object: 32 IID states of three opaque
#' entities (`001`, `site-B`, `site C`) on two criteria (`need_A`, `need_B`)
#' from an explicitly specified independent Normal toy law. It is identical to
#' `read_postrank_draws(system.file("examples", "synthetic-iid.json", package = "postrank"))`.
#'
#' @format A `postrank_draws` object with S = 32, n = 3, K = 2 (the canonical
#'   `applied-0.1` joint equal-weight payload plus its validation receipt).
#' @source `data-raw/make-postrank-toy.R`, which calls
#'   `make_postrank_synthetic_input()` from `inst/examples/make-synthetic-input.R`
#'   (seed 20261019).
#' @concept data
#' @examples
#' postrank_toy$entity_ids
#' dim(postrank_toy$joint_draws$tensor$values)
"postrank_toy"

#' Canonical example posterior: 4000 IID draws for 30 sites and 3 criteria
#'
#' A sealed, strict `postrank_draws` object with all eight scientific
#' declarations. A synthetic dataset was generated from the pilot's A8 recipe
#' (K = 3, latent covariance `.4 I + .6 s s'` with `s = (1, 1, -1)`, cyclic
#' precision groups of ten sites) and passed through the module-A
#' known-Gaussian posterior; the resulting law (30 x 3 means, 3 x 3 x 30
#' covariances) was frozen and 4000 IID draws were generated from it once
#' (seed 20261024). The criteria are named `poverty`, `frl` and `snap` for
#' illustration only; the values are synthetic latent needs, not real measures.
#' The same law is shipped as [pr_example_gaussian].
#'
#' The criteria are in tension (`snap` is negatively related to the other two),
#' and the posteriors are imprecise. Under the illustrative policy
#' `weights = c(poverty = .5, frl = .25, snap = .25)`, `G_max = 4`, the validated
#' incumbent at `tau = .25` is the all-tie grade (every comparison withheld, risk
#' `tau`), and at `tau = .35` it discloses about 63% of the pairs in four
#' grades. (In the pilot's A8 reference cell, with equal weights, the joint rule
#' withheld every comparison in 59 of 60 datasets.) Both results ship as cached
#' assets for the vignettes.
#'
#' @format A `postrank_draws` object whose `joint_draws$tensor$values` is a
#'   4000 x 30 x 3 array (draw, entity `site001`-`site030`, criterion
#'   `poverty`, `frl`, `snap`); the remaining fields follow the legacy schema.
#' @source `data-raw/make-pr-example-law.R` (law stage, seed 20261023) and
#'   `data-raw/make-pr-example-draws.R` (draw stage, seed 20261024); the frozen
#'   law and configuration are `data-raw/pr-example-law.json` and
#'   `data-raw/pr-example-config.json`.
#' @concept data
#' @examples
#' dim(pr_example_draws$joint_draws$tensor$values)
#' pr_example_draws$criterion_ids
"pr_example_draws"

#' Canonical example law as typed Gaussian coefficients
#'
#' The frozen law behind [pr_example_draws] as a `postrank_coefficients`
#' object built by [postrank_gaussian_coefficients()], with the explicit
#' declaration `"entities_given_shared_h"` and the six strict provenance
#' fields (`input_payload_sha256` hashes the frozen law file, `source_sha256`
#' the law generator source and `config_sha256` the generation configuration).
#'
#' @format A `postrank_coefficients` object (`source$kind = "gaussian_conditional"`):
#'   `means` 30 x 3, `e` 30 x 30 x 3, `source$covariance` 3 x 3 x 30
#'   (criterion_i, criterion_j, entity), plus provenance, capabilities and
#'   identities.
#' @source `data-raw/make-pr-example-gaussian.R`.
#' @concept data
#' @examples
#' dim(pr_example_gaussian$e)
#' postrank_coefficient_capabilities(pr_example_gaussian)$weighted_expected_risk
"pr_example_gaussian"

#' Two-state Markov-chain diagnostic toy
#'
#' The methods book's MCMC diagnostic toy: four independent stationary
#' two-state Markov chains of 512 iterations (P(0 -> 1) = .012,
#' P(1 -> 0) = .048, stationary P(Z = 1) = .2, second eigenvalue .94), stored
#' chain by chain. State 0 gives sites A, B, C the targets (3, 2, 1) on `k1`
#' and (3, 1, 2) on `k2`; state 1 gives (1, 3, 2) and (1, 2, 3). The chain is
#' strongly autocorrelated and is not a converged run.
#'
#' Wrap it with the declarations stored in its `law` attribute:
#' `postrank_draws(pr_toy_mcmc, regime = "mcmc", chains = 4L, warmup_per_chain = 0L,
#' thin = 1L, declarations = attr(pr_toy_mcmc, "law")$declarations)`.
#'
#' @format A numeric array 2048 x 3 x 2 (draw, site `A`/`B`/`C`, criterion
#'   `k1`/`k2`) with attribute `law`: the transition matrix, the two states,
#'   seed and RNG kinds, the known identities (fixed grade (1, 2, 3) with
#'   weights (.6, .4), tau = .25: expected loss 4/15; known-law optimum
#'   (1, 2, 2) with risk 13/60; pooled pair mean 353/2048) and the full
#'   [postrank_declarations()] bundle.
#' @source `data-raw/make-pr-toy-mcmc.R`, a port of the methods book's
#'   `prototype/R/diagnostic-toy.R` (seed 20261019), verified against the
#'   archived trace.
#' @concept data
#' @examples
#' dim(pr_toy_mcmc)
#' mean(pr_toy_mcmc[, "A", "k1"] <= pr_toy_mcmc[, "B", "k1"])
"pr_toy_mcmc"

#' Pilot paired loss contrasts at the reference setting
#'
#' Paired realized-loss contrasts between the joint rule and each baseline (expected rank + cuts, composite + cuts) at the reference setting (equal weights, tau = .25, G_max = 4), per design cell, posterior arm and screening subset.
#'
#' Intervals are descriptive Normal 95% limits across independent datasets, not confirmatory tests. Losses are never pooled across tau or weights.
#'
#' The pilot is a simulation study: its summaries are evidence about the
#' studied designs, not evidence that any rule is better in general (claim limits in
#' `system.file("extdata", "pilot", "claim-limits.md", package = "postrank")`).
#'
#' @format A data frame with 52 rows and 23 columns:
#' \describe{
#'   \item{`cell_id`}{character; design cell (`A1`-`A8`, `B1`-`B4`; see [pilot_cells]).}
#'   \item{`scenario_id`}{character; 72-character setting key `setting:<sha256>`, resolved by [pilot_settings].}
#'   \item{`contrast_type`}{character; `Delta` = joint loss minus baseline loss, `Psi` = loss with the error covariance omitted minus loss with it correct, `I` = Psi of the joint rule minus Psi of the baseline.}
#'   \item{`baseline_id`}{character; the baseline compared (`expected_rank`, `composite`); empty for `Psi` rows.}
#'   \item{`method_id`}{the method of a `Psi` row; empty or `NA` otherwise.}
#'   \item{`arm_id`}{posterior arm (`known`, `hb`, `B4-omit`, `B4-correct`); `NA` for B4 contrasts, which pair both arms.}
#'   \item{`tau`}{numeric; withholding cost of the setting.}
#'   \item{`G_max`}{integer; grade cap of the setting.}
#'   \item{`subset`}{character; `raw` (every valid dataset) or `diagnostic_and_gap` (datasets passing the producer-diagnostic and solver-gap screens).}
#'   \item{`n_planned`}{integer; datasets planned.}
#'   \item{`n_complete_raw`}{integer; datasets with a complete raw result.}
#'   \item{`n_in_subset`}{integer; datasets in `subset`.}
#'   \item{`n_incomplete_raw`}{integer; datasets without a complete raw result.}
#'   \item{`n_excluded_or_missing`}{integer; planned datasets excluded by the screen or missing.}
#'   \item{`mean_contrast`}{numeric; mean paired contrast across datasets (for `Delta`, negative favors the common-grade rule).}
#'   \item{`sd_contrast`}{numeric; standard deviation of the contrast across datasets.}
#'   \item{`mcse`}{numeric; Monte Carlo standard error, `sd_contrast / sqrt(n_in_subset)`.}
#'   \item{`normal95_lower`}{numeric; descriptive Normal 95% lower limit, `mean_contrast - 1.96 mcse` (not a test).}
#'   \item{`normal95_upper`}{numeric; descriptive Normal 95% upper limit.}
#'   \item{`planned_lower`}{numeric; lower finite-roster completion bound over all planned datasets, a different quantity from the interval and never substituted for it.}
#'   \item{`planned_upper`}{numeric; upper finite-roster completion bound.}
#'   \item{`estimate_scope`}{character; what the row averages over (`entire_planned_finite_roster`, `conditional_common_valid_subset`).}
#'   \item{`independent_unit`}{character; the replicate unit (`unique_dataset_id`); arms, methods, criteria and pairs are not independent replicates.}
#' }
#' @source `pilot-v1-final-figures-v1/reference_deltas.csv` (13,085 bytes; SHA-256 `e5713f31293b329d11121257b9a29c36cf3ab916d1c578592d6501a7699c0b66`, as recorded in the archive manifest `pilot-figure-file-manifest-v1`), converted by `data-raw/make-pilot-tables.R`; column names, column order and row order kept.
#' @seealso `vignette("pilot-evidence", package = "postrank")`
#' @concept data
#' @examples
#' str(pilot_reference_deltas, give.attr = FALSE)
"pilot_reference_deltas"

#' Pilot display groups of the reference cells
#'
#' The display label of each cell/arm used by the reference figures.
#'
#' The pilot is a simulation study: its summaries are evidence about the
#' studied designs, not evidence that any rule is better in general (claim limits in
#' `system.file("extdata", "pilot", "claim-limits.md", package = "postrank")`).
#'
#' @format A data frame with 13 rows and 3 columns:
#' \describe{
#'   \item{`cell_id`}{character; design cell.}
#'   \item{`arm_id`}{character; posterior arm.}
#'   \item{`group_label`}{character; display label of the cell/arm (for example `A1`, `B4 / omit`), in display order.}
#' }
#' @source `pilot-v1-final-figures-v1/reference_groups.csv` (282 bytes; SHA-256 `32d866b3e6ba9b3fdfc824e42f545da8e5673df1876d0ed53deb22b532356423`, as recorded in the archive manifest `pilot-figure-file-manifest-v1`), converted by `data-raw/make-pilot-tables.R`; column names, column order and row order kept.
#' @seealso `vignette("pilot-evidence", package = "postrank")`
#' @concept data
#' @examples
#' str(pilot_reference_groups, give.attr = FALSE)
"pilot_reference_groups"

#' Pilot disclosure and all-withheld fractions at the reference setting
#'
#' Mean disclosed fraction N/M and the fraction of all-withheld actions by cell, posterior arm and method at the reference setting (12 cells x R = 60 datasets).
#'
#' An all-withheld action is an admissible decision with risk tau: a shared grade withholds the comparison and does not assert that the entities are equal. Intervals are descriptive; an unavailable value is `NA`, never 0.
#'
#' The pilot is a simulation study: its summaries are evidence about the
#' studied designs, not evidence that any rule is better in general (claim limits in
#' `system.file("extdata", "pilot", "claim-limits.md", package = "postrank")`).
#'
#' @format A data frame with 39 rows and 12 columns:
#' \describe{
#'   \item{`cell_id`}{character; design cell (see [pilot_cells]).}
#'   \item{`arm_id`}{character; posterior arm (`known`, `hb`, `B4-omit`, `B4-correct`).}
#'   \item{`method_id`}{character; `joint`, `expected_rank` or `composite`.}
#'   \item{`n_planned`}{integer; datasets planned.}
#'   \item{`n_valid`}{integer; datasets with a valid action.}
#'   \item{`mean`}{numeric; disclosed fraction N/M, mean across datasets.}
#'   \item{`mcse`}{numeric; its Monte Carlo standard error across datasets.}
#'   \item{`lower`}{numeric; descriptive Normal 95% lower limit.}
#'   \item{`upper`}{numeric; descriptive Normal 95% upper limit.}
#'   \item{`n_N_zero`}{integer; datasets whose action withheld every pair (N = 0).}
#'   \item{`all_withheld_fraction`}{numeric; `n_N_zero / n_valid`.}
#'   \item{`n_missing`}{integer; datasets without a value.}
#' }
#' @source `pilot-v1-final-figures-v1/reference_disclosure.csv` (4,391 bytes; SHA-256 `47b5c4c3920c8b471423cbe3ed398feeb154fa70454d7dd4c83fd93e7f501c51`, as recorded in the archive manifest `pilot-figure-file-manifest-v1`), converted by `data-raw/make-pilot-tables.R`; column names, column order and row order kept.
#' @seealso `vignette("pilot-evidence", package = "postrank")`
#' @concept data
#' @examples
#' str(pilot_reference_disclosure, give.attr = FALSE)
"pilot_reference_disclosure"

#' Pilot error-rate calibration at the reference setting
#'
#' Pooled and macro-averaged realized versus posterior-expected wrong-direction counts per criterion for the joint rule at the reference setting.
#'
#' Rows whose actions disclose nothing have no per-disclosed-pair value: the six `/N` columns are `NA` when `total_N == 0`, never 0, while the `/M` columns are defined (a zero numerator over a nonzero M).
#'
#' The pilot is a simulation study: its summaries are evidence about the
#' studied designs, not evidence that any rule is better in general (claim limits in
#' `system.file("extdata", "pilot", "claim-limits.md", package = "postrank")`).
#'
#' @format A data frame with 28 rows and 26 columns:
#' \describe{
#'   \item{`cell_id`}{character; design cell.}
#'   \item{`scenario_id`}{character; setting key (see [pilot_settings]).}
#'   \item{`arm_id`}{character; posterior arm.}
#'   \item{`method_id`}{character; `joint`.}
#'   \item{`subset`}{character; `raw`.}
#'   \item{`criterion_id`}{character; `criterion1`-`criterion3`.}
#'   \item{`n_planned`}{integer; datasets planned.}
#'   \item{`n_in_subset`}{integer; datasets in `subset`.}
#'   \item{`n_count_rows`}{integer; dataset rows carrying counts.}
#'   \item{`n_valid`}{integer; datasets with a valid action.}
#'   \item{`n_N_positive`}{integer; datasets that disclosed at least one pair (N > 0).}
#'   \item{`n_N_zero`}{integer; datasets that disclosed nothing (N = 0).}
#'   \item{`total_M`}{integer; sum over datasets of the number of pairs M.}
#'   \item{`total_N`}{integer; sum of disclosed pairs N.}
#'   \item{`total_D`}{integer; sum of realized wrong-direction disclosed pairs D on the criterion.}
#'   \item{`total_Ehat`}{numeric; sum of posterior expected wrong-direction disclosed pairs.}
#'   \item{`pooled_D_over_N`}{numeric; `total_D / total_N`; `NA` when `total_N == 0`.}
#'   \item{`pooled_Ehat_over_N`}{numeric; `total_Ehat / total_N`; `NA` when `total_N == 0`.}
#'   \item{`pooled_calibration_over_N`}{numeric; `(total_D - total_Ehat) / total_N`; `NA` when `total_N == 0`.}
#'   \item{`macro_D_over_N`}{numeric; mean of D/N over datasets with N > 0; `NA` when there are none.}
#'   \item{`macro_Ehat_over_N`}{numeric; mean of the expected count over N, over datasets with N > 0; `NA` when there are none.}
#'   \item{`macro_calibration_over_N`}{numeric; mean of (D minus expected count) / N over datasets with N > 0; `NA` when there are none.}
#'   \item{`macro_D_over_M`}{numeric; mean of D/M over valid datasets (defined when N = 0, with a zero numerator).}
#'   \item{`macro_Ehat_over_M`}{numeric; mean of the expected count over M.}
#'   \item{`macro_calibration_over_M`}{numeric; mean of (D minus expected count) / M.}
#'   \item{`mean_disclosure_rate`}{numeric; mean disclosed fraction N/M.}
#' }
#' @source `pilot-v1-final-figures-v1/reference_calibration.csv` (9,453 bytes; SHA-256 `311c6875a427511fd973c962ddd20e6723217b294a86d2aa5fc1723cff27eec0`, as recorded in the archive manifest `pilot-figure-file-manifest-v1`), converted by `data-raw/make-pilot-tables.R`; column names, column order and row order kept.
#' @seealso `vignette("pilot-evidence", package = "postrank")`
#' @concept data
#' @examples
#' str(pilot_reference_calibration, give.attr = FALSE)
"pilot_reference_calibration"

#' Pilot disclosure across S6 preference settings
#'
#' Mean disclosed-pair fraction in the S6 sensitivity panel (minority-criterion weight by tau, for each prioritized criterion) per cell and arm.
#'
#' Changing tau or the weights changes the loss itself: settings are not ranked by their raw losses.
#'
#' The pilot is a simulation study: its summaries are evidence about the
#' studied designs, not evidence that any rule is better in general (claim limits in
#' `system.file("extdata", "pilot", "claim-limits.md", package = "postrank")`).
#'
#' @format A data frame with 108 rows and 14 columns:
#' \describe{
#'   \item{`cell_id`}{character; design cell.}
#'   \item{`arm_id`}{character; posterior arm.}
#'   \item{`scenario_id`}{character; setting key (see [pilot_settings]).}
#'   \item{`priority_orientation`}{character; the criterion given the larger weight (`criterion1`, `criterion2`).}
#'   \item{`minority_weight`}{numeric; weight of the other criterion (.2, .25, .3).}
#'   \item{`tau`}{numeric; withholding cost.}
#'   \item{`G_max`}{integer; grade cap.}
#'   \item{`n_planned`}{integer; datasets planned.}
#'   \item{`n_valid`}{integer; datasets with a valid action.}
#'   \item{`mean`}{numeric; mean of `metric` across datasets.}
#'   \item{`mcse`}{numeric; its Monte Carlo standard error.}
#'   \item{`lower`}{numeric; descriptive Normal 95% lower limit.}
#'   \item{`upper`}{numeric; descriptive Normal 95% upper limit.}
#'   \item{`metric`}{character; the summarized quantity (`mean_disclosed_pair_fraction_among_valid_common_grade_actions`).}
#' }
#' @source `pilot-v1-final-figures-v1/S6_boundary.csv` (27,254 bytes; SHA-256 `f9268cc13202c841945cbbccfcfccb12ce70d139a5b5346947655a3238b934c5`, as recorded in the archive manifest `pilot-figure-file-manifest-v1`), converted by `data-raw/make-pilot-tables.R`; column names, column order and row order kept.
#' @seealso `vignette("pilot-evidence", package = "postrank")`
#' @concept data
#' @examples
#' str(pilot_S6_boundary, give.attr = FALSE)
"pilot_S6_boundary"

#' Pilot matched contrasts for the B4 omit/correct arms
#'
#' Contrasts between the B4 posterior arms that omit or correctly model the measurement-error covariance (Psi per method) and their method interactions (I per baseline), in the 23 columns of [pilot_reference_deltas].
#'
#' Psi is a posterior effect shared by the three rules, not a benefit of the decision rule; the correct-covariance HB arm is not an exact oracle.
#'
#' The pilot is a simulation study: its summaries are evidence about the
#' studied designs, not evidence that any rule is better in general (claim limits in
#' `system.file("extdata", "pilot", "claim-limits.md", package = "postrank")`).
#'
#' @format A data frame with 10 rows and 23 columns:
#' \describe{
#'   \item{`cell_id`}{character; design cell (`A1`-`A8`, `B1`-`B4`; see [pilot_cells]).}
#'   \item{`scenario_id`}{character; 72-character setting key `setting:<sha256>`, resolved by [pilot_settings].}
#'   \item{`contrast_type`}{character; `Delta` = joint loss minus baseline loss, `Psi` = loss with the error covariance omitted minus loss with it correct, `I` = Psi of the joint rule minus Psi of the baseline.}
#'   \item{`baseline_id`}{character; the baseline compared (`expected_rank`, `composite`); empty for `Psi` rows.}
#'   \item{`method_id`}{the method of a `Psi` row; empty or `NA` otherwise.}
#'   \item{`arm_id`}{posterior arm (`known`, `hb`, `B4-omit`, `B4-correct`); `NA` for B4 contrasts, which pair both arms.}
#'   \item{`tau`}{numeric; withholding cost of the setting.}
#'   \item{`G_max`}{integer; grade cap of the setting.}
#'   \item{`subset`}{character; `raw` (every valid dataset) or `diagnostic_and_gap` (datasets passing the producer-diagnostic and solver-gap screens).}
#'   \item{`n_planned`}{integer; datasets planned.}
#'   \item{`n_complete_raw`}{integer; datasets with a complete raw result.}
#'   \item{`n_in_subset`}{integer; datasets in `subset`.}
#'   \item{`n_incomplete_raw`}{integer; datasets without a complete raw result.}
#'   \item{`n_excluded_or_missing`}{integer; planned datasets excluded by the screen or missing.}
#'   \item{`mean_contrast`}{numeric; mean paired contrast across datasets (for `Delta`, negative favors the common-grade rule).}
#'   \item{`sd_contrast`}{numeric; standard deviation of the contrast across datasets.}
#'   \item{`mcse`}{numeric; Monte Carlo standard error, `sd_contrast / sqrt(n_in_subset)`.}
#'   \item{`normal95_lower`}{numeric; descriptive Normal 95% lower limit, `mean_contrast - 1.96 mcse` (not a test).}
#'   \item{`normal95_upper`}{numeric; descriptive Normal 95% upper limit.}
#'   \item{`planned_lower`}{numeric; lower finite-roster completion bound over all planned datasets, a different quantity from the interval and never substituted for it.}
#'   \item{`planned_upper`}{numeric; upper finite-roster completion bound.}
#'   \item{`estimate_scope`}{character; what the row averages over (`entire_planned_finite_roster`, `conditional_common_valid_subset`).}
#'   \item{`independent_unit`}{character; the replicate unit (`unique_dataset_id`); arms, methods, criteria and pairs are not independent replicates.}
#' }
#' @source `pilot-v1-final-figures-v1/B4_matched.csv` (3,379 bytes; SHA-256 `0fa1a540e25e17023533b2a35de05f914e5ba331880b2ccf969b01955fb0eb98`, as recorded in the archive manifest `pilot-figure-file-manifest-v1`), converted by `data-raw/make-pilot-tables.R`; column names, column order and row order kept.
#' @seealso `vignette("pilot-evidence", package = "postrank")`
#' @concept data
#' @examples
#' str(pilot_B4_matched, give.attr = FALSE)
"pilot_B4_matched"

#' Pilot criterion burden of the common grade
#'
#' Mean difference between the common grade's risk on each criterion and a criterion-only reference solution's risk at the reference setting.
#'
#' `true_minimum_asserted` is `FALSE`: the reference is a selected criterion-only solution with a recorded gap, not a true minimum. Negative differences are retained as recorded.
#'
#' The pilot is a simulation study: its summaries are evidence about the
#' studied designs, not evidence that any rule is better in general (claim limits in
#' `system.file("extdata", "pilot", "claim-limits.md", package = "postrank")`).
#'
#' @format A data frame with 56 rows and 18 columns:
#' \describe{
#'   \item{`cell_id`}{character; design cell.}
#'   \item{`arm_id`}{character; posterior arm.}
#'   \item{`scenario_id`}{character; setting key (see [pilot_settings]).}
#'   \item{`criterion_id`}{character; `criterion1`-`criterion3`.}
#'   \item{`evaluation_basis`}{character; `analytic_fixed_actions` (module-A exact Gaussian re-evaluation of the fixed actions) or `empirical` (posterior-draw coefficients).}
#'   \item{`subset`}{character; `raw` or `diagnostic_and_gap`.}
#'   \item{`n_planned`}{integer; datasets planned.}
#'   \item{`n_in_subset`}{integer; datasets in `subset`.}
#'   \item{`mean_difference`}{numeric; common-grade risk on the criterion minus the criterion-reference risk, mean across datasets.}
#'   \item{`mcse_across_datasets`}{numeric; its Monte Carlo standard error.}
#'   \item{`normal95_lower`}{numeric; descriptive Normal 95% lower limit.}
#'   \item{`normal95_upper`}{numeric; descriptive Normal 95% upper limit.}
#'   \item{`n_finite_reference_gaps`}{integer; datasets whose reference solve has a finite recorded gap.}
#'   \item{`reference_gap_min`}{integer; smallest recorded reference gap (every recorded value is 0, so the column is stored as integer).}
#'   \item{`reference_gap_max`}{numeric; largest recorded reference gap.}
#'   \item{`n_negative_differences`}{integer; datasets with a negative difference, retained as recorded.}
#'   \item{`true_minimum_asserted`}{logical; always `FALSE`: the reference is a selected criterion-only solution, not a true minimum.}
#'   \item{`reference_gap_basis`}{character; how the reference gap was computed.}
#' }
#' @source `pilot-v1-final-figures-v1/reference_commonality.csv` (19,406 bytes; SHA-256 `bb70cac66f2436910f1bc30570e97440cf348eb77d917a158ec0450f0be6b4bf`, as recorded in the archive manifest `pilot-figure-file-manifest-v1`), converted by `data-raw/make-pilot-tables.R`; column names, column order and row order kept.
#' @seealso `vignette("pilot-evidence", package = "postrank")`
#' @concept data
#' @examples
#' str(pilot_reference_commonality, give.attr = FALSE)
"pilot_reference_commonality"

#' Pilot HB producer diagnostic counts
#'
#' Counts of hierarchical-Bayes posterior arms by diagnostic outcome and host.
#'
#' The pilot is a simulation study: its summaries are evidence about the
#' studied designs, not evidence that any rule is better in general (claim limits in
#' `system.file("extdata", "pilot", "claim-limits.md", package = "postrank")`).
#'
#' @format A data frame with 3 rows and 6 columns:
#' \describe{
#'   \item{`host_id`}{character; `macbook`, `gcp`, `aws`.}
#'   \item{`n_planned_HB_arms`}{integer; planned hierarchical-Bayes arms on the host.}
#'   \item{`unflagged`}{integer; arms passing every producer diagnostic.}
#'   \item{`flagged`}{integer; arms flagged (in the pilot, all for a maximum Rhat above 1.01).}
#'   \item{`failed`}{integer; arms whose producer failed.}
#'   \item{`unestablished`}{integer; arms whose diagnostic status could not be established.}
#' }
#' @source `pilot-v1-final-figures-v1/HB_diagnostic_counts.csv` (138 bytes; SHA-256 `4e51a096c18bfddd5e9b3a2827f82fa2958c5c61dcb9611694b65068bf894e5f`, as recorded in the archive manifest `pilot-figure-file-manifest-v1`), converted by `data-raw/make-pilot-tables.R`; column names, column order and row order kept.
#' @seealso `vignette("pilot-evidence", package = "postrank")`
#' @concept data
#' @examples
#' str(pilot_HB_diagnostic_counts, give.attr = FALSE)
"pilot_HB_diagnostic_counts"

#' Pilot joint-rule gap acceptance counts
#'
#' Counts of planned joint actions whose reported gap met the acceptance threshold, had a finite but unaccepted gap, or had no bound, by host.
#'
#' A gap below the threshold is a numerical solver bound, not a certificate.
#'
#' The pilot is a simulation study: its summaries are evidence about the
#' studied designs, not evidence that any rule is better in general (claim limits in
#' `system.file("extdata", "pilot", "claim-limits.md", package = "postrank")`).
#'
#' @format A data frame with 3 rows and 5 columns:
#' \describe{
#'   \item{`host_id`}{character; `macbook`, `gcp`, `aws`.}
#'   \item{`n_planned_actions`}{integer; planned joint actions on the host.}
#'   \item{`gap_accepted`}{integer; actions whose reported gap met the pre-declared acceptance threshold (a solver value, not a certificate).}
#'   \item{`finite_unaccepted`}{integer; actions with a finite gap above the threshold.}
#'   \item{`unavailable`}{integer; actions without a bound.}
#' }
#' @source `pilot-v1-final-figures-v1/joint_certificate_counts.csv` (143 bytes; SHA-256 `f61ebae67700e6ab6e7997428bd8c570283d40bb5b9ef98bcfe6117ffd198f11`, as recorded in the archive manifest `pilot-figure-file-manifest-v1`), converted by `data-raw/make-pilot-tables.R`; column names, column order and row order kept.
#' @seealso `vignette("pilot-evidence", package = "postrank")`
#' @concept data
#' @examples
#' str(pilot_joint_certificate_counts, give.attr = FALSE)
"pilot_joint_certificate_counts"

#' Pilot computation attempt summary
#'
#' One row per dataset computation attempt with wall time, sampled peak memory and exported bytes, slimmed from the 17-column source table to seven columns; host directories, attempt identifiers and hashes are removed.
#'
#' Peak memory is a poll-sampled sum of worker and observable descendant resident memory, not a hard memory cap or guaranteed peak. Host timings are not a hardware comparison.
#'
#' The pilot is a simulation study: its summaries are evidence about the
#' studied designs, not evidence that any rule is better in general (claim limits in
#' `system.file("extdata", "pilot", "claim-limits.md", package = "postrank")`).
#'
#' @format A data frame with 720 rows and 7 columns:
#' \describe{
#'   \item{`label`}{character; dataset label `<cell>-r<replicate>`.}
#'   \item{`cell_id`}{character; design cell.}
#'   \item{`host_id`}{character; `macbook`, `gcp`, `aws`.}
#'   \item{`supervisor_wall_seconds`}{numeric; wall time of the attempt in seconds.}
#'   \item{`sampled_peak_worker_tree_rss_bytes`}{integer; poll-sampled peak resident memory of the worker tree in bytes (not a hard cap or guaranteed peak).}
#'   \item{`exported_bytes`}{integer; bytes of the exported result.}
#'   \item{`status`}{character; attempt status (`complete`).}
#' }
#' @source `pilot-v1-final-figures-v1/computation_attempts.csv` (476,424 bytes; SHA-256 `9badaa8f5aa06b90df8542be0ec235a6f2028ff0262d40569cf6a12bb2246fbb`, as recorded in the archive manifest `pilot-figure-file-manifest-v1`), converted by `data-raw/make-pilot-tables.R`; seven of 17 columns kept, rows unchanged.
#' @seealso `vignette("pilot-evidence", package = "postrank")`
#' @concept data
#' @examples
#' str(pilot_computation_attempts, give.attr = FALSE)
"pilot_computation_attempts"

#' Pilot decision settings lookup
#'
#' The 37 declared settings of the pilot (25 for K = 2, 12 for K = 3), keyed by the 72-character `scenario_id` used in the summary tables, with a readable `setting_key`.
#'
#' Derived by the maintainer from the pilot's action and sensitivity-membership tables, which are not shipped.
#'
#' The pilot is a simulation study: its summaries are evidence about the
#' studied designs, not evidence that any rule is better in general (claim limits in
#' `system.file("extdata", "pilot", "claim-limits.md", package = "postrank")`).
#'
#' @format A data frame with 37 rows and 12 columns:
#' \describe{
#'   \item{`scenario_id`}{character; the 72-character key used by the summaries.}
#'   \item{`setting_key`}{character; readable key `K=..|tau=..|G_max=..|w=..`.}
#'   \item{`K`}{integer; number of criteria.}
#'   \item{`tau`}{numeric; withholding cost.}
#'   \item{`G_max`}{integer; grade cap.}
#'   \item{`w_1`}{numeric; weight of criterion 1.}
#'   \item{`w_2`}{numeric; weight of criterion 2.}
#'   \item{`w_3`}{numeric; weight of criterion 3; `NA` for K = 2.}
#'   \item{`priority_orientation`}{character; S6 prioritized criterion; `NA` outside S6.}
#'   \item{`minority_weight`}{numeric; S6 minority weight; `NA` outside S6.}
#'   \item{`panels`}{character; comma-separated panels containing the setting (panels overlap).}
#'   \item{`is_reference`}{logical; the equal-weight tau = .25, G_max = 4 setting of each K.}
#' }
#' @source `data-raw/make-pilot-lookups.R`, from the pilot analysis tables `action_rows.csv` and `sensitivity_membership.csv` (not shipped).
#' @seealso `vignette("pilot-evidence", package = "postrank")`
#' @concept data
#' @examples
#' str(pilot_settings, give.attr = FALSE)
"pilot_settings"

#' Pilot design cells
#'
#' The 12 data-generating design cells of the pilot, each with R = 60 independent datasets of n = 30 entities.
#'
#' Module A uses the known-Gaussian posterior; module B the hierarchical-Bayes producer (B4 has two posterior arms on the same data).
#'
#' The pilot is a simulation study: its summaries are evidence about the
#' studied designs, not evidence that any rule is better in general (claim limits in
#' `system.file("extdata", "pilot", "claim-limits.md", package = "postrank")`).
#'
#' @format A data frame with 12 rows and 9 columns:
#' \describe{
#'   \item{`cell_id`}{character; `A1`-`A8`, `B1`-`B4`.}
#'   \item{`module`}{character; `A` (known-Gaussian posterior) or `B` (hierarchical-Bayes producer).}
#'   \item{`K`}{integer; number of criteria.}
#'   \item{`latent_correlation`}{character; latent correlation (K = 2) or the latent covariance recipe (K = 3).}
#'   \item{`precision_pattern`}{character; true measurement precisions of the entity groups.}
#'   \item{`latent_family`}{character; `normal` or `standardized_t5`.}
#'   \item{`error_correlation`}{numeric; measurement-error correlation (.5 in B4, else 0).}
#'   \item{`posterior_arms`}{character; comma-separated posterior arms.}
#'   \item{`n_datasets`}{integer; independent datasets (R = 60).}
#' }
#' @source `data-raw/make-pilot-lookups.R`, transcribed from the pilot's data-generating specification (`.pilot_dgp_spec()`) and design configuration.
#' @seealso `vignette("pilot-evidence", package = "postrank")`
#' @concept data
#' @examples
#' str(pilot_cells, give.attr = FALSE)
"pilot_cells"

#' Pilot headline numbers with source pointers
#'
#' Headline numbers of the completed pilot that appear only in its log prose (run counts, the 167 sensitivity cases and their breakdown, all-withheld mechanism counts, the B4 contrasts, coefficient-error envelopes, HB flags, wall minutes and audit scope), each with its unit and a pointer to the log lines it was transcribed from.
#'
#' The pilot-evidence vignette quotes these numbers through inline code rather than literals. They describe the pilot's finite roster: for example, 167 differing comparisons are a count, not a probability of improvement. The pointwise coefficient error, the weighted risk envelope and the observed fixed-action risk difference are different metrics and keep separate keys.
#'
#' The pilot is a simulation study: its summaries are evidence about the
#' studied designs, not evidence that any rule is better in general (claim limits in
#' `system.file("extdata", "pilot", "claim-limits.md", package = "postrank")`).
#'
#' @format A data frame with 97 rows and 4 columns:
#' \describe{
#'   \item{`key`}{character; unique name of the number.}
#'   \item{`value`}{numeric; the number as printed in the pilot logs.}
#'   \item{`unit`}{character; unit or denominator.}
#'   \item{`pointer`}{character; source pointer `[log:lines]` into the pilot logs and protocol.}
#' }
#' @source `data-raw/make-pilot-headline.R`, transcribed from the blueprint's
#'   pilot-evidence appendix with the original `[log:lines]` pointers; no value
#'   is recomputed. `system.file("extdata", "pilot", "source-register.json",
#'   package = "postrank")` maps the IDs to English source titles, dates when
#'   declared, versions and SHA-256 digests of the cited files. The original reports are not publicly
#'   available in this candidate: their `public_url` is `null`. A hash identifies
#'   source bytes; it is not a retrieval link or independent validation of a
#'   reported result. Bundled summaries support figure redraw, not regeneration
#'   of the full pilot experiment.
#' @seealso `vignette("pilot-evidence", package = "postrank")`
#' @concept data
#' @examples
#' str(pilot_headline, give.attr = FALSE)
"pilot_headline"
