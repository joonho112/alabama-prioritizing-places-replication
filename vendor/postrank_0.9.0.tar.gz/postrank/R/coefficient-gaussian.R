# Conditional Gaussian mathematical-law projection; no target draws or sampler.
.pr_cf_project_gaussian <- function(source) {
  .pr_cf_numeric(source$means)
  axes <- dimnames(source$means)
  .pr_assert(is.matrix(source$means) && identical(names(axes), c("entity", "criterion")),
    "Gaussian means require explicit entity/criterion axis roles", "invalid_coefficients")
  ids <- axes$entity; ks <- axes$criterion
  .pr_cf_ids(ids, 2L); .pr_cf_ids(ks)
  .pr_cf_gaussian_source(source, ids, ks)
  n <- length(ids); K <- length(ks)
  e <- array(NA_real_, c(n, n, K),
    dimnames = list(entity_i = ids, entity_j = ids, criterion = ks))
  for (k in seq_len(K)) for (i in seq_len(n)) for (j in seq_len(n)) {
    if (i == j) next
    vi <- source$covariance[k, k, i]; vj <- source$covariance[k, k, j]
    # sqrt(vi+vj) without overflowing the sum of two finite variances.
    sd_difference <- sqrt(max(vi, vj)) * sqrt(1 + min(vi, vj) / max(vi, vj))
    z <- (source$means[j, k] - source$means[i, k]) / sd_difference
    # Every direction is a direct lower-tail calculation: no 1-pnorm(z).
    e[i, j, k] <- stats::pnorm(z)
  }
  list(means = source$means, e = e)
}

#' Typed Coefficients from a Conditional Gaussian Law
#'
#' Defines an entity-conditionally-independent Gaussian mathematical law and
#' computes \eqn{P(\theta_{i,k} < \theta_{j,k})} for distinct entities.
#' Diagonals are `NA` sentinels.
#'
#' The difference variance is the sum of the two conditional marginal
#' variances. Both probability directions use the normal CDF directly, retaining
#' small tails without subtracting a large CDF from one. These are floating-point
#' analytic calculations, not rational or numerical certification.
#'
#' Supplied mathematical source values and provenance are declarations. This
#' constructor does not verify their relationship to actual data, a producer or
#' the scientific model. Source-values, jointness, convergence and certificate
#' flags remain false. It fabricates no target draws, sample sizes or draw IDs.
#' The candidate supports weighted expected risk and at-most-G problems; other
#' modes are governed by its explicit capability record.
#'
#' @param means Finite numeric matrix with dimension names
#'   `list(entity = entity_ids, criterion = criterion_ids)`. There must be at
#'   least two uniquely identified entities and one criterion. Targets must
#'   already be oriented higher-is-better.
#' @param covariance Finite positive definite conditional covariance array
#'   with dimension names `list(criterion_i = criterion_ids,
#'   criterion_j = criterion_ids, entity = entity_ids)`. No jitter or repair is
#'   applied.
#' @param conditional_independence Required explicit declaration
#'   `"entities_given_shared_h"`. There is no default. Shape or marginal
#'   means/covariances alone cannot establish independence across entities.
#' @param provenance Plain named list with `producer_id`, `producer_version`,
#'   `posterior_id`, `input_payload_sha256`, `source_sha256` and
#'   `config_sha256`, and optional `model_sha256`. Digest values are lowercase
#'   SHA-256 strings.
#' @return A sealed `postrank_coefficients` object, separate from posterior
#'   target draws and exact rational finite-law inputs. Means, source
#'   covariance, ordered axes, directional probabilities, provenance and derived
#'   capabilities are bound by its own content identity.
#' @seealso [validate_postrank_coefficients()], [postrank_mixture_coefficients()],
#'   [postrank_coefficient_capabilities()]
#' @examples
#' ids <- c("A", "B"); ks <- "k1"
#' means <- matrix(c(-.2, .4), 2, 1, dimnames = list(entity = ids, criterion = ks))
#' covariance <- array(.5, c(1, 1, 2),
#'   dimnames = list(criterion_i = ks, criterion_j = ks, entity = ids))
#' provenance <- list(producer_id = "documentation-example", producer_version = "1",
#'   posterior_id = "fixed-toy-gaussian-law", input_payload_sha256 = strrep("a", 64),
#'   source_sha256 = strrep("b", 64), config_sha256 = strrep("c", 64))
#' x <- postrank_gaussian_coefficients(means, covariance,
#'   "entities_given_shared_h", provenance)
#' x$e[, , "k1"]
#' postrank_coefficient_capabilities(x)$weighted_expected_risk
#' @concept coefficients
#' @export
postrank_gaussian_coefficients <- function(means, covariance, conditional_independence, provenance) {
  source <- list(kind = "gaussian_conditional", means = means, covariance = covariance,
                 conditional_independence = conditional_independence)
  .pr_cf_provenance(provenance)
  projected <- .pr_cf_project_gaussian(source)
  .pr_coefficient_assemble(source, projected$means, projected$e, provenance)
}
