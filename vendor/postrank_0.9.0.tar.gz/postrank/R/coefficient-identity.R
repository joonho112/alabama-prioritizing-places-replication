# Own typed-coefficient domain; never a legacy draw or pairwise hash.
.pr_cf_canonical <- function(x) {
  if(is.list(x)&&!is.data.frame(x)) {
    if(!is.null(names(x)))x<-x[sort(names(x),method="radix")]
    x<-lapply(x,.pr_cf_canonical)
  };x
}
.pr_coefficient_identity <- function(x) {
  content<-unclass(x);content[c("coefficient_identity","input_identity","pairwise_identity")]<-NULL
  digest::digest(list(domain="postrank-typed-coefficient-identity-v1",content=.pr_cf_canonical(content)),algo="sha256",serialize=TRUE,serializeVersion=2)
}
.pr_coefficient_seal <- function(x) {
  .pr_cf_structure(x,TRUE);id<-.pr_coefficient_identity(x)
  x$coefficient_identity<-id;x$input_identity<-id;x$pairwise_identity<-id
  .pr_cf_structure(x);x
}
.pr_coefficient_assemble <- function(source,means,e,provenance,capabilities=NULL) {
  ids<-rownames(means);ks<-colnames(means)
  caps<-.pr_cf_capabilities(source$kind,source$source_regime)
  if(!is.null(capabilities)) .pr_assert(.pr_cf_equal_record(capabilities,caps),"cannot override derived capabilities","invalid_coefficients")
  x<-list(schema_version="coefficient-0.1.0",input_kind=source$kind,entity_ids=ids,criterion_ids=ks,
          means=means,e=e,source=source,provenance=provenance,capabilities=caps,validation=.pr_cf_validation())
  class(x)<-c("postrank_coefficients","list");.pr_coefficient_seal(x)
}


# Exact axes/masks; float projection tolerance is distinct from byte identity.
.pr_cf_projection_match <- function(x,projection) {
  same_means <- identical(dimnames(x$means),dimnames(projection$means)) &&
    all(abs(x$means-projection$means)<=1e-12*pmax(1,abs(projection$means)))
  same_e <- identical(dimnames(x$e),dimnames(projection$e)) &&
    identical(is.na(x$e),is.na(projection$e)) &&
    all(abs(x$e[!is.na(x$e)]-projection$e[!is.na(projection$e)])<=1e-12)
  isTRUE(same_means)&&isTRUE(same_e)
}

#' Inspect Typed Conditional-Law Capabilities
#'
#' Distinguishes weighted expected risk and conditional-risk diagnostics from
#' unsupported target-draw operations and guarantees. This does not verify the
#' truth of scientific provenance or MCMC declarations.
#'
#' @param x A typed Gaussian or shared-state coefficient artifact.
#' @return The internally derived capability record after content validation,
#'   without upgrading scientific claims.
#' @seealso [postrank_gaussian_coefficients()], [postrank_mixture_coefficients()]
#' @examples
#' ids <- c("A", "B"); ks <- "k1"
#' means <- matrix(c(-.2, .4), 2, 1, dimnames = list(entity = ids, criterion = ks))
#' covariance <- array(.5, c(1, 1, 2),
#'   dimnames = list(criterion_i = ks, criterion_j = ks, entity = ids))
#' provenance <- list(producer_id = "documentation-example", producer_version = "1",
#'   posterior_id = "fixed-toy-gaussian-law", input_payload_sha256 = strrep("a", 64),
#'   source_sha256 = strrep("b", 64), config_sha256 = strrep("c", 64))
#' x <- postrank_gaussian_coefficients(means, covariance,
#'   "entities_given_shared_h", provenance)
#' str(postrank_coefficient_capabilities(x))
#' @concept coefficients
#' @export
postrank_coefficient_capabilities <- function(x) {
  validate_postrank_coefficients(x);x$capabilities
}
