# Separate opt-in domain. No legacy payload, class, default or identity is changed.
.pr_tie_utf8 <- function(x) {
  .pr_assert(!any(Encoding(x) == "bytes"),
    "byte-encoded strings cannot be represented as declared Unicode text", "invalid_tie_text")
  out <- tryCatch(enc2utf8(x), error = function(e)
    .pr_abort("text cannot be represented as UTF-8 without loss", "invalid_tie_text"))
  .pr_assert(all(is.na(out) | validUTF8(out)),
    "text cannot be represented as UTF-8 without loss", "invalid_tie_text")
  out
}

# Normalize encodings, never Unicode composition or code points. Attributes are
# traversed too: entity/criterion names and array dimnames belong to the seal.
.pr_tie_text_content <- function(x) {
  attrs <- attributes(x)
  if (is.character(x)) x <- .pr_tie_utf8(x)
  else if (is.list(x)) x <- lapply(x, .pr_tie_text_content)
  if (!is.null(attrs)) {
    attrs <- lapply(attrs, .pr_tie_text_content)
    names(attrs) <- .pr_tie_utf8(names(attrs))
    attributes(x) <- attrs
  }
  x
}

.pr_tie_sort_content <- function(x) {
  if (is.list(x) && !is.data.frame(x)) {
    attrs <- attributes(x)
    if (!is.null(names(x))) {
      x <- x[sort(names(x), method = "radix")]
      attrs$names <- names(x)
    }
    x <- lapply(x, .pr_tie_sort_content)
    attributes(x) <- attrs
  }
  x
}

.pr_tie_canonical <- function(x) .pr_tie_sort_content(.pr_tie_text_content(x))

# Callers remove only their own seal before passing semantic content here.
.pr_tie_identity <- function(x, domain) {
  .pr_string(domain, "$.identity_domain")
  digest::digest(list(domain = domain, content = .pr_tie_canonical(x)),
    algo = "sha256", serialize = TRUE, serializeVersion = 2)
}

.pr_tie_numeric_payload <- function(x) {
  if (is.integer(x)) { storage.mode(x) <- "double"; return(x) }
  if (is.list(x)) x <- lapply(x, .pr_tie_numeric_payload)
  x
}

.pr_tie_check_storage <- function(x, path = "$") {
  allowed <- if (is.list(x)) "names" else c("names", "dim", "dimnames")
  .pr_assert(all(names(attributes(x)) %in% allowed),
    "canonical payload has unsupported hidden attributes or classes", "invalid_tie_input", path)
  if (is.character(x)) .pr_tie_utf8(x)
  if (is.list(x)) for (i in seq_along(x))
    .pr_tie_check_storage(x[[i]], paste0(path, "[", i, "]"))
  invisible(TRUE)
}

.pr_tie_input_validation <- function() list(structure_checked = TRUE,
  declared_class_values_checked = TRUE, source_values_checked = FALSE,
  jointness_verified = FALSE, convergence_verified = FALSE,
  scientific_equality_verified = FALSE, finite_sample_certificate = FALSE,
  numerical_certification = FALSE)

.pr_tie_input_payload <- function(x) {
  if (inherits(x, "postrank_tie_draws")) {
    x <- unclass(x); x[c("input_identity", "validation")] <- NULL
  }
  x
}

.pr_tie_validate_exact <- function(x) {
  law <- x$finite_law; path <- "$.finite_law"
  .pr_fields(law, c("denominator", "value_representation", "states", "law_definition",
    "not_empirical_posterior_relabeling"), path = path)
  .pr_assert(identical(law$value_representation, "safe_integer"),
    "exact-law targets require safe_integer representation", path = path)
  .pr_assert(is.numeric(law$denominator) && is.null(dim(law$denominator)) &&
    length(law$denominator) == 1L, "denominator must be a scalar safe integer", path = path)
  .pr_safe_integer(law$denominator, TRUE, paste0(path, ".denominator"))
  .pr_string(law$law_definition, paste0(path, ".law_definition"))
  .pr_assert(identical(law$not_empirical_posterior_relabeling, TRUE),
    "exact law requires an explicit nonempirical declaration", "empirical_relabeling", path)
  .pr_records(law$states, paste0(path, ".states"))
  .pr_assert(length(law$states) > 0L, "finite law needs positive-mass states", path = path)
  .pr_assert(requireNamespace("gmp", quietly = TRUE),
    "exact finite-law validation requires optional package gmp", "missing_dependency", path)
  total <- gmp::as.bigz(0); maximum <- gmp::as.bigz("9007199254740991")
  ids <- character(length(law$states))
  for (s in seq_along(law$states)) {
    z <- law$states[[s]]; loc <- paste0(path, ".states[", s, "]")
    .pr_fields(z, c("state_id", "mass_numerator", "theta"), path = loc)
    .pr_string(z$state_id, paste0(loc, ".state_id")); ids[s] <- z$state_id
    .pr_assert(is.numeric(z$mass_numerator) && is.null(dim(z$mass_numerator)) &&
      length(z$mass_numerator) == 1L, "state mass must be scalar", path = loc)
    .pr_safe_integer(z$mass_numerator, TRUE, paste0(loc, ".mass_numerator"))
    total <- total + .pr_big_integer(z$mass_numerator)
    .pr_assert(total <= maximum, "exact mass sum exceeds safe-integer range", "unsafe_integer", loc)
    theta <- z$theta
    .pr_assert(is.numeric(theta) && is.matrix(theta) &&
      identical(dim(theta), c(length(x$entity_ids), length(x$criterion_ids))),
      "each exact state must retain an n by K numeric matrix", "invalid_shape", loc)
    .pr_safe_integer(theta, path = paste0(loc, ".theta"))
    .pr_assert(identical(dimnames(theta), list(entity = x$entity_ids, criterion = x$criterion_ids)),
      "exact state axes differ from declared order", "invalid_id", loc)
  }
  .pr_ids(ids, path = paste0(path, ".states.state_id"))
  .pr_assert(total == .pr_big_integer(law$denominator),
    "state masses do not sum exactly to denominator", "invalid_exact_mass", path)
  invisible(TRUE)
}

.pr_tie_source_matrices <- function(x) {
  ids <- x$entity_ids; ks <- x$criterion_ids
  out <- lapply(seq_along(ks), function(k) {
    if (identical(x$input_kind, "equal_weight_draws")) {
      a <- x$joint_draws$tensor$values
      matrix(a[, , k, drop = FALSE], nrow = dim(a)[1L], ncol = length(ids),
        dimnames = list(draw = dimnames(a)$draw, entity = ids))
    } else {
      a <- do.call(rbind, lapply(x$finite_law$states, function(s) s$theta[, k]))
      dimnames(a) <- list(state = vapply(x$finite_law$states, `[[`, character(1L), "state_id"), entity = ids)
      a
    }
  })
  names(out) <- ks; out
}

.pr_tie_exact_classes <- function(matrices, ids) {
  lapply(matrices, function(a) {
    labels <- character(length(ids))
    for (i in seq_along(ids)) {
      same <- which(vapply(seq_len(i), function(j) all(a[, i] == a[, j]), logical(1L)))
      labels[i] <- ids[same[1L]]
    }
    stats::setNames(labels, ids)
  })
}

.pr_tie_partition <- function(classes, ids, ks) {
  .pr_fields(classes, ks, path = "$.equality.criterion_classes")
  classes <- classes[ks]
  for (k in ks) {
    z <- classes[[k]]; path <- paste0("$.equality.criterion_classes.", k)
    .pr_assert(is.character(z) && is.null(dim(z)) && length(z) == length(ids) &&
      !anyNA(z) && all(grepl("(*UCP)\\S", z, perl = TRUE)) &&
      !is.null(names(z)) && !anyNA(names(z)) && !anyDuplicated(names(z)) && setequal(names(z), ids),
      "each criterion needs one nonblank class label per named entity", "invalid_equality_partition", path)
    classes[[k]] <- z[ids]
  }
  classes
}

.pr_tie_equality <- function(x) {
  z <- x$equality
  .pr_fields(z, c("basis", "justification", "criterion_classes"), path = "$.equality")
  .pr_string(z$justification, "$.equality.justification")
  exact <- identical(x$input_kind, "exact_finite_posterior")
  required_basis <- if (exact) "exact_finite_law" else "structural_declared"
  .pr_assert(identical(z$basis, required_basis),
    paste("equality basis must be", required_basis), "invalid_equality_basis", "$.equality.basis")
  matrices <- .pr_tie_source_matrices(x)
  if (exact) {
    derived <- .pr_tie_exact_classes(matrices, x$entity_ids)
    if (!is.null(z$criterion_classes)) {
      supplied <- .pr_tie_partition(z$criterion_classes, x$entity_ids, x$criterion_ids)
      for (k in x$criterion_ids) .pr_assert(identical(outer(supplied[[k]], supplied[[k]], `==`),
        outer(derived[[k]], derived[[k]], `==`)),
        "supplied exact-law partition differs from equality across all positive-mass states",
        "invalid_equality_partition", paste0("$.equality.criterion_classes.", k))
    }
    z$criterion_classes <- derived
  } else {
    z$criterion_classes <- .pr_tie_partition(z$criterion_classes, x$entity_ids, x$criterion_ids)
    for (k in x$criterion_ids) for (group in unique(z$criterion_classes[[k]])) {
      members <- which(z$criterion_classes[[k]] == group)
      if (length(members) > 1L) for (i in members[-1L])
        .pr_assert(all(matrices[[k]][, i] == matrices[[k]][, members[1L]]),
          "declared equal-class entities differ in a retained draw; no tolerance or jitter is used",
          "declared_equality_violated", paste0("$.equality.criterion_classes.", k))
    }
  }
  z
}

.pr_tie_validate_payload <- function(x) {
  .pr_tie_check_storage(x)
  fields <- c("schema_version", "input_kind", "dependence_mode", "requested_functional", "entity_ids",
    "criterion_ids", "targets", "context", "identification", "tie_policy", "provenance", "equality")
  .pr_fields(x, fields, c(fields, "joint_draws", "finite_law"))
  .pr_assert(identical(x$schema_version, "tie-aware-input-0.1"),
    "expected explicit tie-aware-input-0.1 schema", "unsupported_version")
  .pr_assert(identical(x$dependence_mode, "joint_model"),
    "tie-aware input currently requires joint_model", "unsupported_tie_input")
  .pr_assert(identical(x$requested_functional, "expected_rank_loss"),
    "only expected_rank_loss is supported", "unsupported_functional")
  .pr_ids(x$entity_ids, 2L, "$.entity_ids"); .pr_ids(x$criterion_ids, 1L, "$.criterion_ids")
  .pr_records(x$targets, "$.targets")
  .pr_assert(length(x$targets) == length(x$criterion_ids), "one target record is required per criterion")
  target_fields <- c("criterion_id", "estimand", "entity_population", "time_reference", "units",
    "source_transform", "identification_basis", "orientation")
  for (k in seq_along(x$targets)) {
    z <- x$targets[[k]]; path <- paste0("$.targets[", k, "]")
    .pr_fields(z, target_fields, path = path)
    for (f in target_fields) .pr_string(z[[f]], paste0(path, ".", f))
    .pr_assert(identical(z$orientation, "higher_priority"), "targets must be oriented higher_priority", path = path)
  }
  target_ids <- vapply(x$targets, `[[`, character(1L), "criterion_id")
  .pr_ids(target_ids)
  .pr_assert(setequal(target_ids, x$criterion_ids), "targets must cover each criterion exactly once")
  .pr_fields(x$context, c("cohort_id", "data_version", "data_conditioning", "model_summary"), path = "$.context")
  for (f in names(x$context)) .pr_string(x$context[[f]], paste0("$.context.", f))
  .pr_fields(x$identification, c("status", "note"), path = "$.identification")
  .pr_assert(identical(x$identification$status, "identified_declared"),
    "unresolved target identification", "unresolved_identification")
  .pr_string(x$identification$note, "$.identification.note")
  .pr_fields(x$tie_policy, c("rule", "declared", "justification", "observed_tie_action"), path = "$.tie_policy")
  .pr_assert(identical(x$tie_policy$rule, "equality_neutral") && identical(x$tie_policy$declared, TRUE) &&
    identical(x$tie_policy$observed_tie_action, "accept_declared_exact_equality"),
    "explicit equality-neutral genuine-tie declaration is required", "invalid_tie_policy", "$.tie_policy")
  .pr_string(x$tie_policy$justification, "$.tie_policy.justification")
  .pr_fields(x$provenance, c("producer", "artifact_id", "artifact_hash", "construction_note", "created_at"), path = "$.provenance")
  for (f in names(x$provenance)) .pr_string(x$provenance[[f]], paste0("$.provenance.", f))
  branches <- intersect(c("joint_draws", "finite_law"), names(x))
  .pr_assert(length(branches) == 1L, "exactly one joint input branch is required")
  if (identical(x$input_kind, "equal_weight_draws")) {
    .pr_assert(identical(branches, "joint_draws"), "equal-weight inputs require joint_draws")
    b <- x$joint_draws; path <- "$.joint_draws"
    .pr_fields(b, c("tensor", "origin", "sampling", "draw_index", "variable_map", "cross_criterion_joint_provenance"), path = path)
    .pr_validate_numeric_axes(b$tensor, c("draw", "entity", "criterion"),
      list(draw = NULL, entity = x$entity_ids, criterion = x$criterion_ids), paste0(path, ".tensor"))
    .pr_string(b$cross_criterion_joint_provenance, paste0(path, ".cross_criterion_joint_provenance"))
    .pr_validate_origin_map(b, x$entity_ids, x$criterion_ids, path)
    .pr_validate_history(b, b$tensor$shape$S, b$tensor$dimnames$draw, path)
  } else if (identical(x$input_kind, "exact_finite_posterior")) {
    .pr_assert(identical(branches, "finite_law"), "exact inputs require finite_law")
    .pr_tie_validate_exact(x)
  } else .pr_abort("unsupported tie-aware input kind", "unsupported_tie_input")
  invisible(TRUE)
}

#' Construct an Explicit Equality-Neutral Posterior Input
#'
#' Uses a separate input domain from the frozen tie-free constructors. The
#' canonical list retains the legacy target, provenance and joint-state metadata
#' shape, with `schema_version = "tie-aware-input-0.1"`, joint-model dependence,
#' and `tie_policy` declaring `equality_neutral`, `declared = TRUE` and
#' `observed_tie_action = "accept_declared_exact_equality"`.
#'
#' `equality` contains `basis`, nonblank `justification`, and
#' `criterion_classes`: a criterion-named list of character class labels named
#' by every entity. For IID/MCMC states, `basis = "structural_declared"` is
#' required. Every declared within-class equality is checked in every retained
#' draw. Classes are never inferred from coincident Monte Carlo values. For an
#' exact integer-state law, `basis = "exact_finite_law"` derives the complete
#' equality partition from all positive-mass states; `criterion_classes = NULL`
#' requests derivation, and a supplied partition must describe the same relation.
#'
#' All numerical equalities are exact. The declaration treats every retained
#' numeric tie as genuine: export rounded continuous draws at full precision
#' before using this constructor. No rounding, epsilon, jitter, provider removal
#' or inference of scientific equality is performed. Sampling-history checks do
#' not establish jointness, stationarity, convergence or a certificate.
#' Integer numeric storage is normalized losslessly to doubles for JSON identity
#' stability; safe-integer checks precede finite-law arithmetic. Criterionwise,
#' weighted approximate and variational inputs are unsupported.
#'
#' @param x A canonical named-list payload in the new domain, or an unchanged
#'   sealed `postrank_tie_draws` object.
#' @return A sealed `postrank_tie_draws`, without legacy class inheritance.
#' @seealso [validate_postrank_tie_draws()], [postrank_tie_pairwise()]
#' @concept tie-aware
#' @export
as_postrank_tie_draws <- function(x) {
  if (inherits(x, "postrank_tie_draws")) { validate_postrank_tie_draws(x); return(x) }
  .pr_assert(is.list(x) && identical(class(x), "list"), "expected a new canonical tie-aware payload", "invalid_tie_input")
  .pr_tie_check_storage(x)
  x <- .pr_tie_text_content(x)
  .pr_tie_validate_payload(x)
  x <- .pr_tie_numeric_payload(x)
  x$equality <- .pr_tie_equality(x)
  x$input_identity <- .pr_tie_identity(x, "postrank-tie-input-v1")
  x$validation <- .pr_tie_input_validation()
  class(x) <- c("postrank_tie_draws", "list")
  validate_postrank_tie_draws(x); x
}

#' Validate a Sealed Equality-Neutral Posterior Input
#'
#' Checks source metadata, exact numeric axes, declared sampling history, equality
#' evidence and the domain-specific content seal. Validation fails on mutations;
#' calling the constructor on a stale sealed object does not silently reseal it.
#' Presence and numerical consistency of declarations do not verify their
#' scientific truth. Legacy input classes and schemas are rejected.
#'
#' @param x A `postrank_tie_draws` from [as_postrank_tie_draws()].
#' @return Invisible `TRUE`; invalid or stale input raises a structured error.
#' @concept tie-aware
#' @export
validate_postrank_tie_draws <- function(x) {
  .pr_assert(identical(class(x), c("postrank_tie_draws", "list")),
    "expected separate postrank_tie_draws class", "invalid_tie_input")
  .pr_assert(identical(x$validation, .pr_tie_input_validation()),
    "unsupported input validation claims", "invalid_tie_input")
  payload <- .pr_tie_input_payload(x)
  .pr_tie_validate_payload(payload)
  .pr_assert(identical(payload$equality, .pr_tie_equality(payload)),
    "equality partition is not the normalized source partition", "invalid_equality_partition")
  .pr_assert(is.character(x$input_identity) && length(x$input_identity) == 1L &&
    identical(x$input_identity, .pr_tie_identity(payload, "postrank-tie-input-v1")),
    "tie-aware input changed after construction", "stale_tie_input_identity")
  invisible(TRUE)
}
