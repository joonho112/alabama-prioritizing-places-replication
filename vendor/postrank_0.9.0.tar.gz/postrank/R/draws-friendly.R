# Bookkeeping convenience over the strict input schemas (Chapter 11, PR-DEC-11-B).
# Every route ends in an unchanged strict constructor; the eight scientific
# declarations remain required and nothing is fabricated or added to a legacy
# payload or validation receipt.

.pr_declaration_fields <- c("targets", "context", "provenance", "origin", "identification_note",
  "tie_justification", "joint_generation", "sampling_provenance")
# Free-text scientific statements may not be generic placeholders.
.pr_placeholder_text <- c("unknown", "tbd", "todo", "na", "n/a", "none", "placeholder", "xxx", "-", "?", "missing", "not declared",
  "...", "\u2026", "tba", "fill in", "edit me")

.pr_declaration_text <- function(x, name) {
  .pr_builder_text(x, name)
  .pr_assert(!tolower(trimws(x)) %in% .pr_placeholder_text,
    paste0(name, " must state the actual declaration, not a placeholder such as \"", x, "\""),
    "placeholder_declaration", paste0("$.declarations.", name))
  x
}

#' Bundle Required Scientific Declarations for Draws
#'
#' Collects the eight scientific declarations that [postrank_draws()] (and the
#' strict [postrank_draws_from_array()]) require for an array of posterior
#' draws. All eight are required; there are no defaults. The bundle is an
#' argument container in exactly this field order, not a new scientific payload.
#' Completeness is checked; truth is not.
#'
#' The four narrative statements and the required descriptive fields of
#' `targets`, `context`, `provenance` and `origin` reject generic placeholders
#' such as `"unknown"`, `"TBD"` or `"..."` (`placeholder_declaration`).
#' `criterion_id` follows the ID rules; `fit_id` and `data_version` are not
#' subject to this token check, since labels such as `"none"` can be valid.
#' This additional lint belongs to this bundle and the friendly array route;
#' it does not change the legacy constructors or canonical metadata readers.
#' A copy-and-edit template of the eight declarations is shown in the README
#' and in `vignette("inputs-and-producers", package = "postrank")`.
#'
#' @param targets One record per criterion (a list of named lists or a data
#'   frame) with `criterion_id`, `estimand`, `entity_population`,
#'   `time_reference` and `units`; optional `source_transform` and
#'   `identification_basis`.
#' @param context Named list with `cohort_id`, `data_version`,
#'   `data_conditioning` and `model_summary`.
#' @param provenance Named list with `producer`, `artifact_id` and
#'   `construction_note`; optional `artifact_hash` and `created_at`.
#' @param origin Named list with `source_id`, `fit_id`, `model_id`,
#'   `source_format` and `source_artifact`; optional `source_hash`.
#' @param identification_note Why every target is identified.
#' @param tie_justification Why exact within-criterion ties between distinct
#'   entities have probability zero.
#' @param joint_generation How each draw holds one joint state of all entities
#'   and criteria.
#' @param sampling_provenance How the draws were produced.
#' @return A `postrank_declarations` object (a classed list with the eight
#'   fields in order).
#' @seealso [postrank_draws()], [postrank_draws_from_array()]
#' @concept input
#' @examples
#' decl <- postrank_declarations(
#'   targets = data.frame(criterion_id = c("need1", "need2"),
#'     estimand = "Illustrative latent need", entity_population = "Four example sites",
#'     time_reference = "Example year", units = "standardized units"),
#'   context = list(cohort_id = "example", data_version = "1",
#'     data_conditioning = "Simulated values for illustration",
#'     model_summary = "Independent standard Normal draws"),
#'   provenance = list(producer = "help example", artifact_id = "example-array",
#'     construction_note = "Generated in the help page"),
#'   origin = list(source_id = "example", fit_id = "none", model_id = "normal",
#'     source_format = "R array", source_artifact = "help example"),
#'   identification_note = "Targets are defined directly by the simulation.",
#'   tie_justification = "Continuous draws; exact ties have probability zero.",
#'   joint_generation = "Each draw holds all sites and criteria from one state.",
#'   sampling_provenance = "IID draws from the stated Normal law.")
#' names(decl)
#' @export
postrank_declarations <- function(targets, context, provenance, origin, identification_note,
                                  tie_justification, joint_generation, sampling_provenance) {
  absent <- setdiff(.pr_declaration_fields, .pr_supplied(.pr_declaration_fields))
  if (length(absent)) .pr_abort(paste("missing required scientific declarations:", paste(absent, collapse = ", "),
    "(they are not inferred or filled with placeholders)"), "missing_declarations", "$.declarations")
  out <- list(targets = targets, context = context, provenance = provenance, origin = origin,
    identification_note = identification_note, tie_justification = tie_justification,
    joint_generation = joint_generation, sampling_provenance = sampling_provenance)
  nulls <- names(out)[vapply(out, is.null, TRUE)]
  if (length(nulls)) .pr_abort(paste("NULL scientific declarations:", paste(nulls, collapse = ", ")),
    "missing_declarations", "$.declarations")
  .pr_validate_declarations(structure(out, class = c("postrank_declarations", "list")))
}

.pr_validate_declarations <- function(x) {
  .pr_assert(inherits(x, "postrank_declarations") && is.list(x) && identical(names(x), .pr_declaration_fields),
    "declarations must be a postrank_declarations bundle with the eight fields in order", "invalid_declarations",
    "$.declarations")
  for (f in c("identification_note", "tie_justification", "joint_generation", "sampling_provenance"))
    .pr_declaration_text(x[[f]], f)
  targets <- x$targets
  if (is.data.frame(targets)) targets <- lapply(seq_len(nrow(targets)), function(r) as.list(targets[r, , drop = FALSE]))
  .pr_assert(is.list(targets) && length(targets) >= 1L, "targets needs one record per criterion", "invalid_builder_input", "$.declarations.targets")
  for (t in targets) {
    t <- lapply(t, function(v) if (is.factor(v)) as.character(v) else v)
    req <- c("criterion_id", "estimand", "entity_population", "time_reference", "units")
    .pr_builder_record(t, req, "targets")
    for (f in req[-1]) .pr_declaration_text(t[[f]], paste0("targets$", f))
  }
  records <- list(context = c("cohort_id", "data_version", "data_conditioning", "model_summary"),
    provenance = c("producer", "artifact_id", "construction_note"),
    origin = c("source_id", "fit_id", "model_id", "source_format", "source_artifact"))
  for (nm in names(records)) {
    r <- .pr_builder_record(x[[nm]], records[[nm]], nm)
    # Identifiers such as fit_id may legitimately read "none"; descriptive statements may not be placeholders.
    for (f in setdiff(records[[nm]], c("fit_id", "data_version"))) .pr_declaration_text(r[[f]], paste0(nm, "$", f))
  }
  x
}

.pr_as_declarations <- function(declarations) {
  if (inherits(declarations, "postrank_declarations")) return(.pr_validate_declarations(declarations))
  .pr_assert(is.list(declarations) && !is.data.frame(declarations) && !is.null(names(declarations)),
    "declarations must come from postrank_declarations()", "invalid_declarations", "$.declarations")
  missing_fields <- setdiff(.pr_declaration_fields, names(declarations))
  if (length(missing_fields)) .pr_abort(paste("missing required scientific declarations:", paste(missing_fields, collapse = ", ")),
    "missing_declarations", "$.declarations")
  extra <- setdiff(names(declarations), .pr_declaration_fields)
  .pr_assert(!length(extra), paste("unknown declaration fields:", paste(extra, collapse = ", ")), "invalid_declarations", "$.declarations")
  do.call(postrank_declarations, declarations[.pr_declaration_fields])
}

.pr_conflict <- function(args, route) {
  if (length(args)) .pr_abort(paste0("these arguments do not apply to ", route, " input: ", paste(args, collapse = ", ")),
    "input_metadata_conflict", "$")
  invisible(TRUE)
}

#' Construct Posterior Draws with Required Declarations
#'
#' A bookkeeping front end to the strict input constructors. Every route ends
#' in an unchanged strict constructor, so the result is an ordinary validated
#' `postrank_draws` object with no added fields:
#'
#' * a numeric `S x n x K` array (draw, entity, criterion) with an explicit
#'   `regime` and the full [postrank_declarations()] bundle goes to
#'   [postrank_draws_from_array()]. IID draws take no chain layout; MCMC draws
#'   need `chains`, `warmup_per_chain` and `thin` (use `thin = 1L` for no
#'   thinning), stored chain by chain.
#' * a named list of `S_k x n` matrices (one per criterion, different `S_k`
#'   allowed) needs complete canonical criterionwise `metadata` with one
#'   declared block per criterion; the matrix values are inserted into those
#'   blocks and [as_postrank_draws()] validates the result. No cross-criterion
#'   joint state is inferred.
#' * a `posterior` `draws_array`, `draws_df` or `draws_matrix` is converted by
#'   `posterior::as_draws_array()` and mapped by [as_postrank_posterior()],
#'   which needs canonical joint `metadata`, explicit `source_coordinates` and
#'   `variables` mapping records.
#' * an existing `postrank_draws` object is revalidated and returned unchanged.
#'
#' **Validation by route.** The friendly numeric-array route applies the
#' additional placeholder-token lint of [postrank_declarations()] before the
#' strict constructor. Direct [postrank_draws_from_array()] calls, existing
#' objects, canonical JSON read/write, matrix-list metadata and the
#' `posterior` metadata bridge preserve the legacy declaration-presence and
#' structural checks; they do not apply that additional token lint. Passing
#' one of those routes does not imply that a bundle's text lint was run.
#' No route verifies the scientific truth of a declaration, jointness or
#' convergence, and no route invents missing declarations.
#'
#' Arguments that do not belong to the detected route (for example
#' `declarations` together with `metadata`) raise `input_metadata_conflict`.
#'
#' For array input only, `orientation` may be a criterion-named vector of
#' `"higher"`/`"lower"`. A `"lower"` criterion is negated exactly once before
#' construction, and the negation is appended to that target's
#' `source_transform`; the oriented payload is sealed with its own identity.
#' Missing declarations are errors: they are never set to `NULL`, `"unknown"`
#' or a false claim of jointness.
#'
#' @param x A numeric array, a named list of matrices, a `posterior` draws
#'   object or a `postrank_draws` object.
#' @param regime For arrays, `"iid"` or `"mcmc"` (required).
#' @param chains,warmup_per_chain,thin For MCMC arrays, the declared chain
#'   layout (all required); leave unset for IID draws.
#' @param entity_ids,criterion_ids Optional IDs for array axes without
#'   dimnames; they may not contradict existing dimnames.
#' @param orientation `"higher"` (default: larger values mean higher
#'   priority) or, for arrays, a criterion-named vector of `"higher"`/`"lower"`.
#' @param declarations A [postrank_declarations()] bundle (array input).
#' @param variables Variable-mapping records (`posterior` input).
#' @param metadata Canonical `applied-0.1` metadata (matrix-list and
#'   `posterior` input).
#' @param source_coordinates Source coordinate records (`posterior` input).
#' @return A validated `postrank_draws` object.
#' @seealso [postrank_declarations()], [postrank_draws_from_array()],
#'   [as_postrank_draws()], [as_postrank_posterior()]
#' @concept input
#' @examples
#' set.seed(1)
#' values <- array(stats::rnorm(200 * 4 * 2), c(200, 4, 2),
#'   dimnames = list(NULL, c("A", "B", "C", "D"), c("need1", "need2")))
#' decl <- postrank_declarations(
#'   targets = data.frame(criterion_id = c("need1", "need2"),
#'     estimand = "Illustrative latent need", entity_population = "Four example sites",
#'     time_reference = "Example year", units = "standardized units"),
#'   context = list(cohort_id = "example", data_version = "1",
#'     data_conditioning = "Simulated values for illustration",
#'     model_summary = "Independent standard Normal draws"),
#'   provenance = list(producer = "help example", artifact_id = "example-array",
#'     construction_note = "Generated in the help page"),
#'   origin = list(source_id = "example", fit_id = "none", model_id = "normal",
#'     source_format = "R array", source_artifact = "help example"),
#'   identification_note = "Targets are defined directly by the simulation.",
#'   tie_justification = "Continuous draws; exact ties have probability zero.",
#'   joint_generation = "Each draw holds all sites and criteria from one state.",
#'   sampling_provenance = "IID draws from the stated Normal law.")
#' draws <- postrank_draws(values, regime = "iid", declarations = decl)
#' draws$entity_ids
#' @export
postrank_draws <- function(x, regime = NULL, chains = NULL, warmup_per_chain = NULL, thin = NULL,
                           entity_ids = NULL, criterion_ids = NULL, orientation = "higher", declarations = NULL,
                           variables = NULL, metadata = NULL, source_coordinates = NULL) {
  supplied <- .pr_supplied(c("regime", "chains", "warmup_per_chain", "thin", "entity_ids", "criterion_ids",
    "orientation", "declarations", "variables", "metadata", "source_coordinates"))
  non_default_orientation <- !identical(orientation, "higher")
  if (inherits(x, "postrank_draws")) {
    .pr_conflict(supplied[supplied != "orientation" | non_default_orientation], "an existing postrank_draws")
    return(as_postrank_draws(x))
  }
  if (inherits(x, c("draws_array", "draws_df", "draws_matrix", "draws"))) {
    .pr_conflict(intersect(supplied, c("regime", "chains", "warmup_per_chain", "thin", "entity_ids", "criterion_ids",
      "declarations")), "posterior draws (the layout and declarations come from metadata)")
    .pr_assert(!non_default_orientation, "posterior metadata must already be oriented higher-priority",
      "input_metadata_conflict", "$.orientation")
    .pr_assert(!is.null(metadata) && !is.null(variables) && !is.null(source_coordinates),
      "posterior draws need canonical joint metadata, variables mapping records and source_coordinates",
      "missing_metadata", "$.metadata")
    .pr_assert(requireNamespace("posterior", quietly = TRUE),
      "the optional posterior package is required for posterior draws input", "missing_dependency")
    return(as_postrank_posterior(posterior::as_draws_array(x), variable_map = variables, metadata = metadata,
      source_coordinates = source_coordinates))
  }
  if (is.array(x) && is.numeric(x) && length(dim(x)) == 3L)
    return(.pr_draws_from_array_route(x, regime, chains, warmup_per_chain, thin, entity_ids, criterion_ids,
      orientation, declarations, supplied))
  if (is.list(x) && !is.data.frame(x) && length(x) && all(vapply(x, function(m) is.matrix(m) && is.numeric(m), TRUE)))
    return(.pr_draws_from_matrices(x, metadata, supplied, non_default_orientation))
  .pr_abort("x must be a numeric S x n x K array, a named list of S_k x n matrices, posterior draws or postrank_draws",
    "unsupported_source", "$")
}

.pr_draws_from_array_route <- function(x, regime, chains, warmup_per_chain, thin, entity_ids, criterion_ids,
                                       orientation, declarations, supplied) {
  .pr_conflict(intersect(supplied, c("variables", "metadata", "source_coordinates")), "array")
  .pr_assert(!is.null(regime), "array input needs an explicit regime: \"iid\" or \"mcmc\"", "missing_regime", "$.regime")
  .pr_assert(is.character(regime) && length(regime) == 1L && regime %in% c("iid", "mcmc"),
    "regime must be \"iid\" or \"mcmc\"", "invalid_builder_input", "$.regime")
  if (is.null(declarations)) .pr_abort(paste("array input needs the eight scientific declarations from postrank_declarations():",
    paste(.pr_declaration_fields, collapse = ", ")), "missing_declarations", "$.declarations")
  d <- .pr_as_declarations(declarations)
  # Only dim/dimnames are values; any other attribute (such as pr_toy_mcmc's "law") is
  # documentation and never enters the sealed payload.
  attributes(x) <- list(dim = dim(x), dimnames = dimnames(x))
  dn <- dimnames(x); if (is.null(dn)) dn <- vector("list", 3L)
  for (axis in list(list(2L, entity_ids, "entity_ids"), list(3L, criterion_ids, "criterion_ids"))) {
    ids <- axis[[2L]]
    if (is.null(ids)) next
    .pr_ids(as.character(ids), path = paste0("$.", axis[[3L]]))
    .pr_assert(length(ids) == dim(x)[axis[[1L]]], paste(axis[[3L]], "length must match the array axis"),
      "input_metadata_conflict", paste0("$.", axis[[3L]]))
    .pr_assert(is.null(dn[[axis[[1L]]]]) || identical(as.character(dn[[axis[[1L]]]]), as.character(ids)),
      paste(axis[[3L]], "contradicts the array dimnames"), "input_metadata_conflict", paste0("$.", axis[[3L]]))
    dn[[axis[[1L]]]] <- as.character(ids)
  }
  dimnames(x) <- dn
  criteria <- as.character(dn[[3L]])
  targets <- d$targets
  if (is.data.frame(targets)) targets <- lapply(seq_len(nrow(targets)), function(r)
    lapply(as.list(targets[r, , drop = FALSE]), function(v) if (is.factor(v)) as.character(v) else v))
  if (!identical(orientation, "higher")) {
    .pr_assert(is.character(orientation) && !is.null(names(orientation)) && !anyDuplicated(names(orientation)) &&
      all(names(orientation) %in% criteria) && all(orientation %in% c("higher", "lower")),
      "orientation must be \"higher\" or a criterion-named vector of \"higher\"/\"lower\"", "invalid_orientation",
      "$.orientation")
    lower <- names(orientation)[orientation == "lower"]
    tid <- vapply(targets, function(t) as.character(t$criterion_id), "")
    for (k in lower) {
      x[, , k] <- -x[, , k]
      j <- match(k, tid)
      .pr_assert(!is.na(j), paste("no target record for criterion", k), "invalid_builder_input", "$.declarations.targets")
      old <- if (is.null(targets[[j]]$source_transform)) "identity" else targets[[j]]$source_transform
      targets[[j]]$source_transform <- paste0(old, "; then negated once by postrank_draws(orientation = \"lower\") ",
        "so that larger values mean higher priority")
    }
  }
  postrank_draws_from_array(x, regime = regime, chains = chains, targets = targets, context = d$context,
    provenance = d$provenance, origin = d$origin, identification_note = d$identification_note,
    tie_justification = d$tie_justification, joint_generation = d$joint_generation,
    sampling_provenance = d$sampling_provenance, warmup_per_chain = warmup_per_chain, thin = thin)
}

.pr_draws_from_matrices <- function(x, metadata, supplied, non_default_orientation) {
  .pr_conflict(intersect(supplied, c("regime", "chains", "warmup_per_chain", "thin", "entity_ids", "criterion_ids",
    "declarations", "variables", "source_coordinates")), "matrix-list (criterionwise) metadata-driven")
  .pr_assert(!non_default_orientation, "criterionwise metadata must already be oriented higher-priority",
    "input_metadata_conflict", "$.orientation")
  .pr_assert(is.list(metadata) && identical(metadata$dependence_mode, "criterionwise_expected_only") &&
    is.list(metadata$criterion_blocks), "matrix-list input needs complete canonical criterionwise metadata",
    "missing_metadata", "$.metadata")
  .pr_assert(!is.null(names(x)) && !anyDuplicated(names(x)) && setequal(names(x), metadata$criterion_ids),
    "the matrix list must be named by exactly the metadata criterion_ids", "input_metadata_conflict", "$")
  blocks <- metadata$criterion_blocks
  for (b in seq_along(blocks)) {
    k <- blocks[[b]]$criterion_id; m <- x[[k]]
    .pr_assert(ncol(m) == length(metadata$entity_ids) &&
      (is.null(colnames(m)) || identical(colnames(m), metadata$entity_ids)),
      paste("matrix", k, "columns must be the metadata entity_ids in order"), "input_metadata_conflict", "$")
    slots <- vapply(blocks[[b]]$draw_index, function(z) z$slot_id, "")
    .pr_assert(nrow(m) == length(slots) && (is.null(rownames(m)) || identical(rownames(m), slots)),
      paste("matrix", k, "rows must match the declared draw_index"), "input_metadata_conflict", "$")
    storage.mode(m) <- "double"
    dimnames(m) <- list(draw = slots, entity = metadata$entity_ids)
    matrix_record <- list(axis_order = c("draw", "entity"), shape = list(S = nrow(m), n = ncol(m)),
      dimnames = dimnames(m), values = m)
    # Canonical block order: criterion_id, matrix, origin, sampling, draw_index, variable_map.
    if ("matrix" %in% names(blocks[[b]])) blocks[[b]]$matrix <- matrix_record
    else {
      at <- match("criterion_id", names(blocks[[b]]))
      blocks[[b]] <- append(blocks[[b]], list(matrix = matrix_record), after = if (is.na(at)) 0L else at)
    }
  }
  metadata$criterion_blocks <- blocks
  as_postrank_draws(metadata)
}
