.pr_payload <- function(x) {
  if (inherits(x, "postrank_draws")) {
    x <- unclass(x); x$schema_version <- x$input_schema_version
    x$input_schema_version <- NULL; x$validation <- NULL
  }
  x
}
.pr_identity <- function(x) digest::digest(x, algo = "sha256", serialize = TRUE)

#' Validate Posterior Inputs Without Inferring Correctness
#' @param x Canonical named-list payload or postrank_draws object.
#' @param source Reserved source audit argument; use explicit producer adapters.
#' @return A validation receipt with errors and independent check flags.
#' @concept input
#' @export
validate_postrank_draws <- function(x, source = NULL) {
  payload <- .pr_payload(x)
  issue <- tryCatch({.pr_validate_common(payload); NULL}, error = function(e) e)
  valid <- is.null(issue)
  receipt <- list(valid = valid, schema_checked = FALSE,
    semantic_checks_completed = if (valid) sprintf("DC%02d", 1:15) else character(),
    source_values_checked = FALSE, jointness_verified = FALSE, convergence_verified = FALSE,
    eligible_functional = if (valid) "expected_rank_loss" else NA_character_,
    input_identity = .pr_identity(payload), validator_version = "0.1.0",
    check_results = list(schema = "not_checked", semantics = if (valid) "passed" else "failed",
                         source_values = "not_checked", jointness = "not_checked", convergence = "not_checked"),
    issues = if (valid) list() else list(list(code = if (is.null(issue$code)) "invalid_input" else issue$code,
      path = if (is.null(issue$path)) "$" else issue$path, message = conditionMessage(issue), severity = "error")),
    limitations = c("Scientific declarations are checked for presence, not truth.",
      "R semantic checks do not execute a general Draft 2020-12 schema validator."))
  if (!is.null(source)) .pr_abort("source audit requires the explicit posterior adapter", "unsupported_source_audit")
  if (valid && inherits(x, "postrank_draws") && isTRUE(x$validation$source_values_checked) &&
      identical(x$validation$input_identity, receipt$input_identity)) {
    receipt$source_values_checked <- TRUE; receipt$check_results$source_values <- "passed"
    receipt$source_audit <- x$validation$source_audit
  }
  class(receipt) <- c("postrank_validation", "list"); receipt
}

#' Construct Validated Canonical Posterior Draws
#' @param x A canonical applied-0.1 named-list payload.
#' @return A postrank_draws object with unchanged values and declared order.
#' @concept input
#' @export
as_postrank_draws <- function(x) {
  receipt <- validate_postrank_draws(x)
  if (!receipt$valid) {
    e <- receipt$issues[[1L]]; .pr_abort(e$message, e$code, e$path)
  }
  payload <- .pr_payload(x); payload$input_schema_version <- payload$schema_version
  payload$schema_version <- "0.1.0"; payload$validation <- receipt
  class(payload) <- c("postrank_draws", "list"); payload
}
