#' Evaluate Grades Under the Separate Equality-Neutral Loss
#'
#' Scores a fixed common-grade action using the declared posterior law and
#' \code{tie_aware_v1}. No legacy object or loss is reinterpreted.
#'
#' @param grade Positive integer numeric vector named in declared entity order.
#'   Labels are canonicalized without changing any pairwise relation.
#' @param pairwise A sealed \code{postrank_tie_pairwise} object.
#' @param weights Nonnegative finite criterion-named weights summing to one,
#'   naming every criterion exactly once; automatic normalization is not used.
#' @param tau Cost for withholding a distinct comparison in \code{(0, 0.5]}.
#'
#' @return A \code{postrank_tie_evaluation} list. Counts \code{E} (also
#'   \code{Eb}), \code{D_k}, \code{T_k}, and \code{H_k} give criterion-specific
#'   expected wrong, disclosed-distinct, total-distinct and withheld-distinct
#'   counts. \code{D} and \code{T} are their weighted distinct-count summaries.
#'   \code{N} is the raw number of disclosed unordered pairs, with
#'   \code{disclosure_rate = N/M}. \code{D_over_T} and
#'   \code{distinct_disclosure_rate} are the weighted distinct-opportunity
#'   disclosure ratio. \code{D_k_over_T_k}, \code{E_over_D} and
#'   \code{E_over_N} retain the distinct and raw denominators separately;
#'   zero-denominator ratios are \code{NA}.
#'
#'   \code{criterion_risk} and \code{criterion_baseline} contain criterion
#'   risks and all-withhold baselines. \code{weighted_risk} and
#'   \code{primary_risk} are the weighted risk. \code{all_withhold_risk}
#'   (also \code{R0}) is the weighted all-withhold baseline.
#'   \code{weighted_raw_objective} (also \code{raw_Z}) equals
#'   \code{sum(weights * E) - tau * D}. The result records settings, identities,
#'   and \code{guard_satisfied}/\code{guard_classes}.
#'
#' @details
#' Criterion risk is evaluated directly from disclosed wrong-event mass and
#' withheld distinct-event mass. The evaluator does not obtain risk by trusting
#' a solver objective or its offset. Ratios are ratios of posterior expected
#' counts, not expectations of draw-specific realized ratios. A smaller risk is
#' conditional on the supplied posterior and loss; it does not certify external
#' accuracy, construct validity or policy benefit.
#'
#' A full active-profile class is obtained by intersecting verified criterion
#' equality partitions over positive-weight criteria. This function reports
#' whether the supplied action obeys that guard; it deliberately also scores
#' actions violating the guard for descriptive comparison. It does not solve or
#' check a G_max family. Only a solver's separately validated guarded action may
#' be released as a feasible tie-aware solution.
#'
#' @concept tie-aware
#' @export
postrank_tie_evaluate <- function(grade, pairwise, weights, tau) {
  settings <- .pr_tie_loss_settings(pairwise, weights, tau)
  g <- canonical_postrank_grade(grade, pairwise$entity_ids)
  n <- length(g)
  K <- length(pairwise$criterion_ids)
  M <- choose(n, 2)
  x <- outer(unname(g), unname(g), `<`)
  h <- outer(unname(g), unname(g), `==`) & upper.tri(x)
  dimnames(x) <- dimnames(h) <- list(entity_i = pairwise$entity_ids, entity_j = pairwise$entity_ids)
  N <- sum(x)
  named_count <- function(fun) stats::setNames(vapply(seq_len(K), fun, numeric(1L)), pairwise$criterion_ids)
  E <- named_count(function(k) sum(pairwise$b[, , k][x]))
  D_k <- named_count(function(k) sum(pairwise$d[, , k][x]))
  T_k <- named_count(function(k) sum(pairwise$d[, , k][upper.tri(x)]))
  H_k <- named_count(function(k) sum(pairwise$d[, , k][h]))
  D <- sum(settings$weights * D_k)
  T <- sum(settings$weights * T_k)
  criterion_risk <- (E + settings$tau * H_k) / M
  criterion_baseline <- settings$tau * T_k / M
  risk <- sum(settings$weights * criterion_risk)
  baseline <- sum(settings$weights * criterion_baseline)
  raw <- sum(settings$weights * E) - settings$tau * D
  ratio <- function(numerator, denominator) {
    out <- numerator / denominator
    out[denominator == 0] <- NA_real_
    out
  }
  guard <- .pr_tie_guard(pairwise, settings$weights)
  out <- list(schema_version = "tie-evaluation-0.1.0", loss = "tie_aware_v1",
    grade = g, G = length(unique(g)), M = M, N = N, x = x,
    disclosure_rate = N / M, abstention_rate = (M - N) / M,
    E = E, Eb = E, D_k = D_k, T_k = T_k, H_k = H_k, D = D, T = T,
    E_over_M = E / M, E_over_N = ratio(E, N), E_over_D = ratio(E, D_k),
    D_k_over_T_k = ratio(D_k, T_k), D_over_T = if (T == 0) NA_real_ else D / T,
    distinct_disclosure_rate = if (T == 0) NA_real_ else D / T,
    criterion_risk = criterion_risk, criterion_baseline = criterion_baseline,
    weighted_risk = risk, primary_risk = risk, all_withhold_risk = baseline, R0 = baseline,
    weighted_raw_objective = raw, raw_Z = raw,
    guard_satisfied = .pr_tie_guard_satisfied(g, guard), guard_classes = guard$classes,
    guard = guard, settings = settings,
    input_identity = pairwise$input_identity, pairwise_identity = pairwise$pairwise_identity)
  class(out) <- c("postrank_tie_evaluation", "list")
  out
}
