# The entity-level report card (Chapter 10 postrank_report_card). Summaries are
# computed once here from the declared input law; views only read the stored table.

.pr_report_card_fields <- c("data", "level", "interval_source", "secondary_order", "settings", "grade_identity",
  "input_identity", "schema_version", "provenance", "warnings")

.pr_fit_of <- function(x) {
  if (inherits(x, "postrank_analysis")) return(x$fit)
  .pr_assert(inherits(x, "postrank_fit"), "expected a postrank_fit or postrank_analysis", "invalid_fit")
  x
}
.pr_input_identity_of <- function(x) if (inherits(x, "postrank_coefficients")) x$coefficient_identity else x$validation$input_identity

#' Entity-Level Report Card with Posterior Intervals
#'
#' One row per entity, sorted by grade (1 = highest priority) and then by a
#' stable secondary key: the entity's grade, its counts of entities it is
#' disclosed above, below and tied with (`n_above + n_below + n_withheld =
#' n - 1`), and for every criterion the posterior mean, a central interval and
#' the expected rank \eqn{1 + \sum_{j \ne i} e_{ij,k}}. The intervals summarize
#' the declared input law (see [postrank_posterior_means()] for the rules per
#' input kind); they are not recomputed by any figure.
#'
#' The source law resolves from `draws`, then the analysis input, then a typed
#' coefficient object stored in the fit's problem. An explicit `draws` must have
#' the fit's input identity. A fit built from a bare pairwise object has no
#' posterior means, so `draws` is required (`missing_posterior_source`).
#' Without a validated grade the call fails with `no_validated_incumbent`.
#'
#' @param x A `postrank_fit` or `postrank_analysis` with a validated grade.
#' @param draws Optional source law (`postrank_draws` or
#'   `postrank_coefficients`) with the same input identity.
#' @param level Central interval level in `(0, 1)`; default `0.90`.
#' @param order Secondary sort key within a grade: `"expected_rank"` (the
#'   weighted expected rank, default), `"mean"` (the weighted posterior mean,
#'   larger first) or `"label"` (entity ID).
#' @return A `postrank_report_card` object; its `data` slot is the table.
#' @seealso [postrank()], [postrank_posterior_means()]
#' @concept reporting
#' @examples
#' if (requireNamespace("highs", quietly = TRUE)) {
#'   fit <- postrank(postrank_toy, weights = c(need_A = .6, need_B = .4), tau = .25,
#'     G_max = 3L, backend = "highs", fragility = FALSE)
#'   card <- postrank_report_card(fit, level = .8)
#'   card$data
#' }
#' @export
postrank_report_card <- function(x, draws = NULL, level = 0.90, order = c("expected_rank", "mean", "label")) {
  order <- match.arg(order); level <- .pr_level(level)
  fit <- .pr_fit_of(x)
  if (!isTRUE(fit$incumbent_validated) || is.null(fit$grade))
    .pr_abort("a report card needs a validated grade; this fit has no validated incumbent", "no_validated_incumbent", "$.fit")
  src <- if (!is.null(draws)) draws else if (inherits(x, "postrank_analysis")) x$input else
    if (inherits(fit$problem$pairwise, "postrank_coefficients")) fit$problem$pairwise else NULL
  if (is.null(src)) .pr_abort(paste("this fit was built from a pairwise object and carries no posterior law;",
    "supply draws = the postrank_draws or postrank_coefficients it came from"), "missing_posterior_source", "$.draws")
  .pr_assert(identical(.pr_input_identity_of(src), fit$input_identity),
    "draws must be the input the fit was computed from (input identities differ)", "diagnostic_input_mismatch", "$.draws")
  summaries <- if (inherits(x, "postrank_analysis")) .pr_cached_summaries(x, level) else NULL
  if (is.null(summaries)) summaries <- .pr_posterior_summaries(src, level)
  .pr_report_card_build(fit, summaries, order)
}

.pr_report_card_build <- function(fit, summaries, order) {
  pw <- fit$problem$pairwise; ids <- pw$entity_ids; ks <- pw$criterion_ids; n <- length(ids)
  g <- fit$grade[ids]
  w <- fit$problem$settings$weights[ks]
  er <- vapply(ks, function(k) 1 + rowSums(pw$e[, , k], na.rm = TRUE), numeric(n))
  er <- matrix(er, n, length(ks), dimnames = list(ids, ks))
  above <- vapply(seq_len(n), function(i) sum(g[i] < g[-i]), 1L)
  below <- vapply(seq_len(n), function(i) sum(g[i] > g[-i]), 1L)
  tied <- vapply(seq_len(n), function(i) sum(g[i] == g[-i]), 1L)
  df <- data.frame(entity_id = ids, grade = as.integer(g), sort_rank = NA_integer_, n_above = as.integer(above),
    n_below = as.integer(below), n_withheld = as.integer(tied), stringsAsFactors = FALSE)
  for (k in ks) {
    df[[paste0("mean_", k)]] <- unname(summaries$means[ids, k])
    df[[paste0("lower_", k)]] <- unname(summaries$lower[ids, k])
    df[[paste0("upper_", k)]] <- unname(summaries$upper[ids, k])
    df[[paste0("expected_rank_", k)]] <- unname(er[ids, k])
  }
  key <- switch(order,
    expected_rank = as.numeric(er[ids, , drop = FALSE] %*% w),
    mean = -as.numeric(summaries$means[ids, ks, drop = FALSE] %*% w),
    label = rep(0, n))
  o <- order(df$grade, key, match(ids, sort(ids, method = "radix")), method = "radix")
  df <- df[o, , drop = FALSE]; df$sort_rank <- seq_len(n); rownames(df) <- NULL
  .pr_assert(all(df$n_above + df$n_below + df$n_withheld == n - 1L), "relation counts must sum to n - 1", "invalid_report_card")
  out <- list(data = df, level = summaries$level, interval_source = summaries$source, secondary_order = order,
    settings = .pr_settings_from_problem(fit$problem),
    grade_identity = fit$solution_identity$relation_identity, input_identity = fit$input_identity,
    schema_version = "1", provenance = .pr_provenance("postrank_report_card"), warnings = character())
  class(out) <- c("postrank_report_card", "list")
  .pr_validate_report_card(out)
  out
}

.pr_validate_report_card <- function(x) {
  .pr_assert(inherits(x, "postrank_report_card") && identical(names(x), .pr_report_card_fields),
    "expected a postrank_report_card with its documented ordered fields", "invalid_report_card")
  d <- x$data
  .pr_assert(is.data.frame(d) && identical(names(d)[1:6], c("entity_id", "grade", "sort_rank", "n_above", "n_below", "n_withheld")),
    "report card table has unexpected leading columns", "invalid_report_card")
  for (k in names(x$settings$weights)) {
    lo <- d[[paste0("lower_", k)]]; up <- d[[paste0("upper_", k)]]
    .pr_assert(!is.null(lo) && !is.null(up) && all(lo <= up), paste("interval columns invalid for", k), "invalid_report_card")
  }
  .pr_assert(x$interval_source %in% c("draws_equal_tail", "exact_finite_law", "gaussian_analytic", "mixture_analytic", "unavailable"),
    "unknown interval_source", "invalid_report_card")
  invisible(TRUE)
}
