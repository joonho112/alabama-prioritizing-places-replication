#' Canonicalize Grades Preserving All Public Relations
#' @param grade Positive integer numeric vector named in entity order.
#' @param entity_ids Ordered opaque entity IDs.
#' @return Named consecutive integer grades; smaller means higher priority.
#' @concept decision
#' @export
canonical_postrank_grade <- function(grade,entity_ids) {
  .pr_ids(entity_ids,2L,"$.entity_ids")
  .pr_assert(typeof(grade)%in%c("integer","double")&&is.null(dim(grade))&&length(grade)==length(entity_ids)&&
    identical(names(grade),entity_ids),"grades must be numeric and named in declared entity order","invalid_grade")
  .pr_safe_integer(grade,TRUE,"$.grade")
  stats::setNames(as.integer(match(grade,sort(unique(grade)))),entity_ids)
}
.pr_loss_settings <- function(pairwise,weights,tau) {
  .pr_assert(typeof(weights)%in%c("integer","double")&&is.null(dim(weights))&&length(weights)==length(pairwise$criterion_ids)&&
    !anyNA(weights)&&all(is.finite(weights))&&all(weights>=0)&&!is.null(names(weights))&&
    !anyDuplicated(names(weights))&&setequal(names(weights),pairwise$criterion_ids),
    "weights must be a nonnegative finite named vector covering criteria exactly once","invalid_weights")
  .pr_assert(abs(sum(weights)-1)<=1e-12,"weights must sum to one; automatic normalization is not used","invalid_weights")
  .pr_assert(typeof(tau)%in%c("integer","double")&&is.null(dim(tau))&&length(tau)==1L&&is.finite(tau)&&tau>0&&tau<=.5,
    "tau must satisfy 0 < tau <= 0.5","invalid_tau")
  list(weights=weights[pairwise$criterion_ids],tau=as.numeric(tau),weight_sum=sum(weights),weight_sum_tolerance=1e-12)
}
