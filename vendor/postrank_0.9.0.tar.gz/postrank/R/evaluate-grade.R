#' Evaluate Common Grades Under Directional-Error Loss
#' @param grade Positive integer vector named in declared entity order.
#' @param pairwise A postrank_pairwise or typed postrank_coefficients object. Typed inputs support weighted expected risk only.
#' @param weights Nonnegative criterion-named rank-loss weights summing to one.
#' @param tau Abstention cost in (0, 0.5].
#' @param settings Optional [postrank_settings()] object supplying the weights,
#'   tau, objective and minimax criteria; an alternative to the loose arguments
#'   (explicitly supplying both is a `settings_conflict` error).
#' @param objective Weighted or minimax expected risk.
#' @param minimax_criteria Optional nonempty criterion subset for minimax.
#' @return An unclassed list with `schema_version`, the canonical `grade`,
#'   occupied grade count `G`, total unordered pairs `M`, disclosed pairs `N`,
#'   and the directed disclosure matrix `x`. `disclosure_rate` is `N/M` and
#'   `abstention_rate` is `(M-N)/M`. Criterion-named vectors `E`, `E_over_M`,
#'   `E_over_N` and `criterion_risk` give expected errors and normalized loss.
#'   `weighted_risk`, `minimax_risk` and `primary_risk` distinguish the weighted,
#'   largest selected-criterion and requested-objective risks; `objective` and
#'   `minimax_criteria` identify the choice. `weighted_raw_objective` is
#'   `sum(weights * E) - tau * N`. `settings` stores the loss settings, and
#'   `input_identity`/`pairwise_identity` identify the coefficients.
#' @details Smaller grades mean higher priority. Equal grades abstain. For
#'   all-tie, E/N is NA and risk is tau. These are expected directional losses,
#'   not simultaneous guarantees or proof of latent equality. This function
#'   scores the supplied action; it does not solve or check membership in a
#'   grade-cap, exact-grade or error-budget constrained action family.
#'   [postrank_compare()] records that membership separately.
#' @examples
#' pw <- postrank_pairwise(postrank_toy)
#' all_tie <- stats::setNames(rep(1L, length(pw$entity_ids)), pw$entity_ids)
#' ev <- postrank_evaluate(all_tie, pw, weights = c(need_A = .6, need_B = .4),
#'   tau = .25)
#' ev[c("G", "N", "M", "primary_risk", "E_over_N")]
#' stopifnot(ev$N == 0, all(is.na(ev$E_over_N)), ev$primary_risk == .25)
#' @concept decision
#' @export
postrank_evaluate <- function(grade, pairwise, weights = NULL, tau = NULL, objective = c("weighted", "minimax"),
                              minimax_criteria = NULL, settings = NULL) {
  if (is.null(settings)) return(.pr_evaluate_core(grade, pairwise, weights, tau, objective, minimax_criteria))
  .pr_settings_conflict(.pr_supplied(c("weights", "tau", "objective", "minimax_criteria")))
  .pr_validate_pairwise(pairwise)
  p <- .pr_settings_bind(settings, pairwise)$policy
  .pr_evaluate_core(grade, pairwise, p$weights, p$tau, p$objective, p$minimax_criteria)
}

# Unchanged 0.0.1.9003 (C3) body, moved behind the public adapter (freeze manifest: moved_from postrank_evaluate).
.pr_evaluate_core <- function(grade,pairwise,weights,tau,objective=c("weighted","minimax"),minimax_criteria=NULL) {
  .pr_validate_pairwise(pairwise);settings<-.pr_loss_settings(pairwise,weights,tau)
  objective<-match.arg(objective)
  .pr_cf_problem_scope(pairwise,objective,minimax_criteria=minimax_criteria)
  if(objective=="weighted") .pr_assert(is.null(minimax_criteria),"minimax_criteria requires minimax objective","invalid_minimax_criteria")
  selected<-if(is.null(minimax_criteria))pairwise$criterion_ids else minimax_criteria
  .pr_assert(is.character(selected)&&is.null(dim(selected))&&length(selected)>0L&&!anyNA(selected)&&
    !anyDuplicated(selected)&&all(selected%in%pairwise$criterion_ids),"invalid minimax criterion subset","invalid_minimax_criteria")
  g<-canonical_postrank_grade(grade,pairwise$entity_ids);n<-length(g);K<-length(pairwise$criterion_ids)
  x<-outer(unname(g),unname(g),`<`)
  dimnames(x)<-list(entity_i=pairwise$entity_ids,entity_j=pairwise$entity_ids)
  M<-choose(n,2);N<-sum(x)
  E<-stats::setNames(vapply(seq_len(K),function(k)sum(pairwise$e[,,k][x]),numeric(1L)),pairwise$criterion_ids)
  Rk<-(E+settings$tau*(M-N))/M
  R<-(sum(settings$weights*E)+settings$tau*(M-N))/M
  list(schema_version="0.1.0",grade=g,G=length(unique(g)),M=M,N=N,x=x,
    disclosure_rate=N/M,abstention_rate=(M-N)/M,E=E,E_over_M=E/M,
    E_over_N=if(N==0)stats::setNames(rep(NA_real_,K),pairwise$criterion_ids) else E/N,
    criterion_risk=Rk,weighted_risk=R,minimax_risk=max(Rk[selected]),
    primary_risk=if(objective=="weighted")R else max(Rk[selected]),objective=objective,
    minimax_criteria=if(objective=="minimax")selected else NULL,weighted_raw_objective=sum(settings$weights*E)-settings$tau*N,
    settings=settings,input_identity=pairwise$input_identity,pairwise_identity=pairwise$pairwise_identity)
}
