synthetic-iid.json is a new, complete applied-0.1 software example.
It contains 32 IID states, three opaque entity IDs and two labeled criteria.
The law is an explicitly specified independent Normal toy target, not a fit
to observed data, a Stan result, an Alabama result or an upstream oracle copy.

make-synthetic-input.R defines make_postrank_synthetic_input() without running
it on source(). The function preserves the caller's RNG state. The fixed
generator chooses S=32, seed=20261019, alpha=.05 and allocations .025/.025
before generation. It returns every metadata field and original draw ID.

Regenerate in an installed postrank session:
  source(system.file("examples", "make-synthetic-input.R", package="postrank"))
  payload <- make_postrank_synthetic_input()
  write_postrank_draws(payload, "a-new-path.json")

The shipped JSON was written with postrank's 17-digit lossless JSON emitter.
Validation confirms input structure and values, not scientific model validity,
jointness or convergence. See vignette("inputs-and-producers", package="postrank").
