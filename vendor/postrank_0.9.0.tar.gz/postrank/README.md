
<!-- README.md is generated from README.Rmd. Please edit that file. -->

# postrank

postrank turns posterior uncertainty about several criteria into **one
common integer grade** per entity. It seeks the grade that minimizes a
declared loss: a weighted posterior probability of wrong-direction
comparisons for the pairs it orders, plus a cost `tau` for each pair it
leaves unordered. The package fits no model; it starts from posterior
draws or posterior coefficients that you already have.

## Installation

postrank 0.9.0 is a GitHub release candidate; it is not on CRAN. Once
the author has published the repository and its `v0.9.0` tag:

``` r
# install.packages("remotes")
remotes::install_github("joonho112/postrank@v0.9.0")
```

Solving needs a mixed-integer backend. The backend is the explicit
`backend` argument, otherwise `getOption("postrank.backend")`, otherwise
`"gurobi"` (the licensed Gurobi optimizer through its R package). HiGHS
is an explicit alternative: pass `backend = "highs"` after
`install.packages("highs")`, or set
`options(postrank.backend = "highs")`. If the selected backend is
unavailable the call stops with both remedies; postrank never switches
solvers silently. Installation, loading, the bundled data, stored-result
views and the cached documentation need no backend.

## Example

`pr_example_draws` holds 4,000 joint posterior draws for 30 sites on
three criteria, with all eight required scientific declarations. The
criteria names are illustrative; the values are synthetic draws from a
frozen known law.

``` r
library(postrank)
a35 <- postrank(pr_example_draws, weights = c(poverty = .5, frl = .25, snap = .25),
  tau = .35, G_max = 4L, backend = "highs")
a35
```

The output below is that call’s result, read from a sealed cache built
by the maintainer. Cached asset `analysis_30x3_tau35`: built by the
maintainer with postrank 0.9.0 and the explicitly selected highs backend
(version 1.12.0.3) at 2026-10-25T15:08:47Z; 1 solve, recorded status
optimal. Reading it here solves nothing.

    #> <postrank_analysis>  30 entities in 4 grades (2 / 14 / 12 / 2)
    #>   risk 0.3226   disclosed 276/435 pairs (63.4%)
    #>   status optimal   gap 5.55e-17 (requested <= 1e-08)   backend highs (staged)
    #>   error per disclosed pair: poverty 0.136, frl 0.172, snap 0.784
    #>   extras: report_card available; fragility available; crossfit not requested;
    #>     diagnostics not requested
    #>   grade 1 (2): site003, site010
    #>   grade 2 (14): site005, site008, site011, site012, site014, site017, site019,
    #>     site021, site023, site025, site027, site028, site029, site030
    #>   grade 3 (12): site001, site002, site004, site006, site013, site015, site016,
    #>     site018, site020, site022, site024, site026
    #>   grade 4 (2): site007, site009
    #>   i  summary(x) shows declarations, provenance and timings; get_grades(x),
    #>        get_profile(x).

``` r
a35$report_card
#> <postrank_report_card>  30 entities in 4 grades (2 / 14 / 12 / 2)
#>   posterior means; 90.0% central intervals (draws_equal_tail) in x$data
#>    grade entity_id above below withheld poverty  frl     snap   
#>    1     site003   28    0      1       0.8681   0.8613  -0.4259
#>    1     site010   28    0      1       0.7571   0.9066  -0.3359
#>    2     site029   14    2     13       1.002    0.7277  -1.241 
#>    2     site028   14    2     13       0.9412   1.01    -1.544 
#>    2     site027   14    2     13       0.6985   0.803   -1.305 
#>    2     site019   14    2     13       0.4937   0.06341 -0.4777
#>    2     site017   14    2     13       -0.3137  0.1485  0.884  
#>    2     site012   14    2     13       0.1923   0.3362  -0.4804
#>    2     site008   14    2     13       -0.04795 0.4555  -0.1457
#>    2     site025   14    2     13       0.1094   0.2929  -0.3563
#>   Showing 10 of 30 entities; full table in x$data.
#>   i  as.data.frame(x) returns the full table.
```

With the same posterior and `tau = .25` the validated incumbent
withholds every comparison (risk exactly `tau`; cached asset
`analysis_30x3`): at that cost the solver found no division of these
imprecisely measured, conflicting criteria worth its price. Changing
`tau` changes the loss, so the two settings are not ranked by their
risks.

## What the grade means

Grade 1 is the highest-priority block; larger target values mean higher
priority, and only the order and equality of grade labels matter. A
shared grade withholds the comparison of its members; it does not assert
that they are equal. The procedure seeks the grade with the smallest
declared weighted wrong-direction loss plus withholding cost, and
reports the validated incumbent with the solver’s bound and gap;
withholding every comparison, with risk `tau`, is a legitimate action.

## Gallery

<p>

<img src="man/figures/README-report-card.png" width="24%" alt="Report card">
<img src="man/figures/README-relations.png" width="24%" alt="Pair relations">
<img src="man/figures/README-frontier.png" width="24%" alt="Tau frontier">
<img src="man/figures/README-commonality.png" width="24%" alt="Criterion burden">
</p>

The report card, the pair relations, the `tau` frontier and the
criterion burden of the common grade: four of the six shipped `ggplot2`
figures, drawn from stored results.

## Your own draws

Supply an `S x n x K` array of draws (draw, entity, criterion) and the
eight declarations; every statement below must be replaced with the
facts of your analysis.

``` r
decl <- postrank_declarations(
  targets = data.frame(criterion_id = c("need1", "need2"), estimand = "...",
    entity_population = "...", time_reference = "...", units = "..."),
  context = list(cohort_id = "...", data_version = "...", data_conditioning = "...", model_summary = "..."),
  provenance = list(producer = "...", artifact_id = "...", construction_note = "..."),
  origin = list(source_id = "...", fit_id = "...", model_id = "...", source_format = "...", source_artifact = "..."),
  identification_note = "...", tie_justification = "...",
  joint_generation = "...", sampling_provenance = "...")
draws <- postrank_draws(theta, regime = "iid", declarations = decl)
fit <- postrank(draws, weights = c(need1 = .5, need2 = .5), tau = .25, G_max = 4L)
```

The friendly array route applies placeholder-token lint through
`postrank_declarations()`. Direct legacy constructors, canonical JSON,
existing objects and metadata-based producer routes retain their
structural and declaration-presence checks without that additional text
lint. None of these checks verifies scientific truth; see the input
vignette for the route contract.

For reusable console captures, prefer `format(x, width = 72, tier = 2)`.
The 24 class-specific `format_postrank_*_cli()` wrappers return the same
lines, and none is deprecated in this release. Use accessors and
structured result slots for calculations, rather than parsing display
text.

## Where next

- `vignette("quickstart", package = "postrank")`: from posterior draws
  to a common grade in seven steps.
- `vignette("inputs-and-producers", package = "postrank")`: strict
  inputs, declarations and external producers.
- `vignette("baselines-and-the-cost-of-a-common-grade", package = "postrank")`:
  baselines and criterion burden.
- `vignette("pilot-evidence", package = "postrank")`: what 720 simulated
  datasets did and did not show.

## Citation

`citation("postrank")` gives the package entry and the method it builds
on: Kline, P., Rose, E. K., & Walters, C. R. (2024). A discrimination
report card. *American Economic Review*, 114(8), 2472-2525.
<https://doi.org/10.1257/aer.20230700>

## Scope

Posterior models are fitted by external producers; postrank validates
their structure and declarations, not their scientific truth. Solver
bounds and gaps are numerical statements under recorded tolerances, not
certificates, and the number of optimal grades is not enumerated. The
pilot summaries shipped with the package describe a finite simulation
roster and support only the claims listed in its vignette.


## Opt-in tie-aware mode

The separate `postrank_tie_*` API supports genuine exact ties while preserving
legacy 0.9 input schemas, defaults, hashes and cached results. Its initial scope
is **weighted at-most-G with a full active-profile same-grade guard**, using a
label-MIP. It does not fit a posterior model.

For criterion k, declaring i above j costs `P(theta_i < theta_j)`; withholding
costs `tau * P(theta_i != theta_j)`. Thus equality is neutral under both actions.
At zero tie mass this is the original loss. The all-withhold benchmark is R0,
which can be below tau. Evaluation reports raw disclosure N/M, distinct
opportunity D/T and strict expected errors E/D separately; zero denominators
are NA. These are posterior expected-count ratios, not external accuracy.

```r
source <- read_postrank_tie_draws(system.file(
  "examples", "synthetic-tie-aware.json", package = "postrank", mustWork = TRUE))
pw <- postrank_tie_pairwise(source)
problem <- postrank_tie_problem(pw, c(S = .25, C = .75), tau = .1, G_max = 2L)
if (requireNamespace("highs", quietly = TRUE)) {
  fit <- postrank_tie_solve(problem, backend = "highs",
    control = list(time_limit = 15, threads = 1L, seed = 1304L))
  fit$grade
  fit$evaluation[c("primary_risk", "R0", "N", "D", "D_over_T")]
  fit$objective[c("risk_lower_bound", "risk_upper_bound", "risk_absolute_gap")]
}
```

The bundled example is a complete two-state software law. For joint IID/MCMC
input, declare criterion-specific structural equality partitions and their
scientific justification in the new canonical input schema. The constructor
checks their numerical consistency in every retained draw but cannot verify
the scientific declaration. It never merges classes from finite sampled
coincidences, applies a numerical tolerance to equality, jitters targets, drops
providers or turns rounded continuous output into a verified posterior atom.
Exact finite-law partitions are derived from all positive-mass states.

Only positive-weight criteria define the active-profile guard. Same C alone
does not require the same grade when S differs. All provider IDs and the
original M are retained. The guard preserves a weighted at-most-G optimum
under the stated family; it does not guarantee a unique optimum or unchanged
funding when occupied grade counts change.

Staged solving, q, minimax, exact-G, typed Gaussian/mixture inputs, legacy
baselines/reports/plots, MC diagnostics and uniform IID/regret/protection
certificates are unavailable in this initial mode. New objects have distinct
classes and seals and are rejected by legacy consumers. Ordinary RDS preserves
these objects and their seals; the dedicated JSON reader/writer handles only
the new canonical input schema. Solver-reported bounds are subject to
floating-point tolerances and are not numerical certificates.
